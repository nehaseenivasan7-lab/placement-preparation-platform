/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        college: {
          navy: '#0a192f',
          gold: '#c5a059',
          blue: '#1e3a8a',
        },
      },
    },
  },
  plugins: [],
}
