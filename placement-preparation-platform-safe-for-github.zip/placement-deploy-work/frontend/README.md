# NEC Placement Preparation Platform - Frontend

React + Vite JavaScript SPA for National Engineering College, Kovilpatti.

## Features
- Dedicated portals for Junior (2nd Year), Pre-Final (3rd Year), Senior Mentors, and Placement Cell Admins
- Practice Studio with Aptitude, Coding, and Technical CS question banks
- Company Playbooks, Interview Experiences, and Mock Interview / GD labs
- Real-time Google Authentication & JWT session persistence
- MongoDB Compass synchronization
