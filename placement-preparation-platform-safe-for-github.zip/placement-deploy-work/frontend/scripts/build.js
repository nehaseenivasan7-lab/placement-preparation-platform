/**
 * Custom build verification script for frontend
 */
import { execSync } from 'child_process';

console.log('[Build]: Verifying and bundling frontend JavaScript application...');
try {
  execSync('vite build', { stdio: 'inherit' });
  console.log('[Build Success]: Frontend built into dist/ directory.');
} catch (error) {
  console.error('[Build Failed]:', error.message);
  process.exit(1);
}
