import React from 'react';
import {
  Compass,
  Building2,
  Code2,
  BookOpen,
  Calendar,
  Users2,
  BarChart3,
  ShieldCheck,
  Award,
} from 'lucide-react';

export const Sidebar = ({ activeTab, onSelectTab, role }) => {
  // Navigation menus customized by user role
  const getMenuItems = () => {
    if (role === 'junior') {
      return [
        { id: 'journey', label: 'Placement Journey', icon: Compass },
        { id: 'careers', label: 'Career Explorer', icon: Building2 },
        { id: 'skills', label: 'Skill Builder', icon: BookOpen },
        { id: 'coding_basics', label: 'Coding Basics', icon: Code2 },
        { id: 'aptitude_starter', label: 'Aptitude Starter', icon: Award },
        { id: 'progress', label: 'My Learning Progress', icon: BarChart3 },
      ];
    }

    if (role === 'admin') {
      return [
        { id: 'overview', label: 'Admin Command Center', icon: ShieldCheck },
        { id: 'drives', label: 'Manage Placement Drives', icon: Calendar },
        { id: 'students', label: 'Student Readiness Monitor', icon: Users2 },
        { id: 'companies', label: 'Company Database', icon: Building2 },
      ];
    }

    if (role === 'senior') {
      return [
        { id: 'mentor', label: 'Senior Mentorship Hub', icon: Users2 },
        { id: 'playbooks', label: 'Company Playbooks', icon: Building2 },
        { id: 'interview_exp', label: 'Interview Experiences', icon: BookOpen },
        { id: 'question_bank', label: 'Question Bank Curator', icon: Code2 },
      ];
    }

    // Pre-final (Default)
    return [
      { id: 'playbooks', label: 'Company Playbook', icon: Building2 },
      { id: 'practice', label: 'Practice Studio', icon: Code2 },
      { id: 'experiences', label: 'Interview Experiences', icon: BookOpen },
      { id: 'challenges', label: 'Daily Challenges', icon: Award },
      { id: 'analytics', label: 'Readiness Analytics', icon: BarChart3 },
    ];
  };

  const menuItems = getMenuItems();

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 border-b border-slate-800">
        <span className="text-[10px] font-bold tracking-wider uppercase text-blue-400 block mb-1">
          Active Workspace
        </span>
        <p className="text-xs font-semibold text-slate-200 capitalize">
          {role === 'junior'
            ? 'Junior Foundation (2nd Year)'
            : role === 'senior'
            ? 'Senior Mentor Suite'
            : role === 'admin'
            ? 'Placement Admin Console'
            : 'Pre-Final Placement Hub (3rd Year)'}
        </p>
      </div>

      <nav className="p-3 space-y-1 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer text-left ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 text-[11px] text-slate-400">
        <p className="font-semibold text-slate-300">National Engineering College</p>
        <p className="text-[10px] text-slate-500">Kovilpatti, Tamil Nadu</p>
      </div>
    </aside>
  );
};
