import React, { useState } from 'react';
import { Eye, EyeOff, Database, User as UserIcon, ChevronDown, Key } from 'lucide-react';
import { api } from '../services/api';
import { DEFAULT_GOOGLE_ACCOUNTS, GOOGLE_CLIENT_ID } from '../config/googleAuth';

export const AuthModal = ({ onLoginSuccess, onOpenCompass }) => {
  const [username, setUsername] = useState('24104009');
  const [password, setPassword] = useState('123');
  const [role, setRole] = useState('pre_final');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Google OAuth Modal (Matching Image 2)
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [googleView, setGoogleView] = useState('chooser'); // chooser | password | custom | client_id
  const [selectedAcc, setSelectedAcc] = useState(null);
  const [customEmail, setCustomEmail] = useState('');
  const [googlePass, setGooglePass] = useState('123');
  const [showGooglePass, setShowGooglePass] = useState(false);
  const [googleClientId, setGoogleClientId] = useState(() => {
    return localStorage.getItem('necpp_google_client_id') || GOOGLE_CLIENT_ID;
  });
  const [clientIdInput, setClientIdInput] = useState('');

  const handleUsernameChange = (val) => {
    setUsername(val);
    const clean = val.trim().toLowerCase();
    if (clean === 'admin@nec.edu.in' || clean.includes('admin')) setRole('admin');
    else if (clean.startsWith('sen')) setRole('senior');
    else if (clean.startsWith('251')) setRole('junior');
    else if (clean.startsWith('241')) setRole('pre_final');
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    const res = await api.login(username, password, role);
    setLoading(false);

    if (res.success) {
      onLoginSuccess(res.user, res.token);
    } else {
      setErrorMsg(res.message || 'Login failed.');
    }
  };

  const handleSelectAccount = async (acc) => {
    setSelectedAcc(acc);
    if (acc.status === 'Signed out') {
      setCustomEmail(acc.email);
      setGooglePass('123');
      setGoogleView('password');
    } else {
      setLoading(true);
      const res = await api.googleLogin(acc.email, acc.name);
      setLoading(false);
      if (res.success) {
        setShowGoogleModal(false);
        onLoginSuccess(res.user, res.token);
      }
    }
  };

  const handleGoogleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const email = selectedAcc ? selectedAcc.email : customEmail;
    const name = selectedAcc ? selectedAcc.name : email.split('@')[0];
    const res = await api.googleLogin(email, name);
    setLoading(false);
    if (res.success) {
      setShowGoogleModal(false);
      onLoginSuccess(res.user, res.token);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Top Header */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 bg-blue-100/80 px-2 py-0.5 rounded">
            NEC Campus Placement Portal
          </span>
          <button
            onClick={onOpenCompass}
            className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded hover:bg-emerald-100 cursor-pointer"
          >
            <Database className="w-3 h-3 text-emerald-600" />
            <span>MongoDB Atlas</span>
          </button>
        </div>

        <div className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-xl font-black text-slate-900 tracking-tight">Student & Faculty Sign In</h2>
            <p className="text-xs text-slate-500 mt-1">National Engineering College • Placement Preparation Platform</p>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Username / Roll Number</label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                placeholder="e.g. 24104009, 25104001, SEN001, admin@nec.edu.in"
                className="w-full px-4 py-2.5 bg-[#eef3fb] border border-[#d6e3f8] focus:border-blue-500 focus:bg-white text-slate-800 font-medium rounded-lg text-sm outline-none transition"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">Password</label>
                <span className="text-[10px] text-slate-400">Default: 123</span>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full px-4 py-2.5 bg-[#eef3fb] border border-[#d6e3f8] focus:border-blue-500 focus:bg-white text-slate-800 font-medium rounded-lg text-sm outline-none transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-[#1b66f1] hover:bg-[#1556d1] disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition cursor-pointer"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>

            {/* Google OAuth Button */}
            <div className="pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setGoogleView('chooser');
                  setShowGoogleModal(true);
                }}
                className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-700 font-semibold rounded-lg border border-slate-300 transition cursor-pointer flex items-center justify-center gap-2 text-xs"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* ORIGINAL GOOGLE OAUTH MODAL (MATCHING IMAGE 2) */}
      {showGoogleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-[440px] bg-[#131314] text-[#e3e3e3] rounded-3xl shadow-2xl border border-[#2f3033] p-6 sm:p-8 font-sans">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span className="text-sm font-medium text-[#e3e3e3]">Sign in with Google</span>
              </div>
              <button
                onClick={() => setShowGoogleModal(false)}
                className="text-[#9aa0a6] hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {googleView === 'chooser' && (
              <div className="mt-6">
                <h2 className="text-2xl font-normal text-white">Choose an account</h2>
                <p className="text-sm text-[#8ab4f8] mt-1 hover:underline cursor-pointer">
                  to continue to EL Project
                </p>

                <div className="mt-6 divide-y divide-[#2f3033] border-t border-b border-[#2f3033]">
                  {DEFAULT_GOOGLE_ACCOUNTS.map((acc, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleSelectAccount(acc)}
                      className="py-3.5 px-2 flex items-center justify-between hover:bg-[#202124] rounded-xl cursor-pointer transition"
                    >
                      <div className="flex items-center gap-3.5 min-w-0">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold text-xs shrink-0"
                          style={{ backgroundColor: acc.avatarColor }}
                        >
                          {acc.avatarLetter}
                        </div>
                        <div className="truncate">
                          <p className="text-sm font-medium text-white truncate">{acc.name}</p>
                          <p className="text-xs text-[#9aa0a6] truncate">{acc.email}</p>
                        </div>
                      </div>
                      {acc.status && <span className="text-xs text-[#9aa0a6]">{acc.status}</span>}
                    </div>
                  ))}

                  <div
                    onClick={() => {
                      setCustomEmail('');
                      setGoogleView('custom');
                    }}
                    className="py-3.5 px-2 flex items-center gap-3.5 hover:bg-[#202124] rounded-xl cursor-pointer transition text-[#e3e3e3]"
                  >
                    <div className="w-8 h-8 rounded-full border border-[#5f6368] flex items-center justify-center text-[#e3e3e3]">
                      <UserIcon className="w-4 h-4 text-[#bdc1c6]" />
                    </div>
                    <span className="text-sm font-medium">Use another account</span>
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between text-xs text-[#9aa0a6]">
                  <div className="flex items-center gap-1">
                    <span>English (United States)</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex items-center gap-4">
                    <a href="#help" className="hover:underline">Help</a>
                    <a href="#privacy" className="hover:underline">Privacy</a>
                    <a href="#terms" className="hover:underline">Terms</a>
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-[#2f3033] flex items-center justify-between text-[11px] text-[#9aa0a6]">
                  <div className="flex items-center gap-1.5 truncate mr-2">
                    <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="font-mono text-[10px] truncate max-w-[200px]">
                      {googleClientId.startsWith('YOUR_') ? 'Client ID: Not set' : googleClientId}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setClientIdInput(googleClientId.startsWith('YOUR_') ? '' : googleClientId);
                      setGoogleView('client_id');
                    }}
                    className="px-2.5 py-1 rounded bg-[#202124] hover:bg-[#303134] text-[#8ab4f8] text-[11px] font-medium border border-[#3c4043] transition cursor-pointer shrink-0"
                  >
                    Edit Client ID
                  </button>
                </div>
              </div>
            )}

            {googleView === 'password' && (
              <form onSubmit={handleGoogleSubmit} className="mt-6 space-y-5">
                <div>
                  <h2 className="text-2xl font-normal text-white">Welcome</h2>
                  <p className="text-xs text-[#9aa0a6] mt-1">{selectedAcc ? selectedAcc.email : customEmail}</p>
                </div>
                <input
                  type={showGooglePass ? 'text' : 'password'}
                  required
                  placeholder="Enter your password"
                  value={googlePass}
                  onChange={(e) => setGooglePass(e.target.value)}
                  className="w-full px-4 py-3 bg-[#1e1f20] border border-[#5f6368] focus:border-[#8ab4f8] text-white rounded-md text-sm outline-none"
                />
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setGoogleView('chooser')}
                    className="text-xs text-[#8ab4f8] hover:underline cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-[#8ab4f8] text-[#001d35] font-medium rounded-full text-xs cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </form>
            )}

            {googleView === 'custom' && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setGoogleView('password');
                }}
                className="mt-6 space-y-5"
              >
                <div>
                  <h2 className="text-2xl font-normal text-white">Sign in with Google</h2>
                  <p className="text-sm text-[#8ab4f8] mt-1">to continue to EL Project</p>
                </div>
                <input
                  type="email"
                  required
                  placeholder="Email or phone"
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-[#1e1f20] border border-[#5f6368] focus:border-[#8ab4f8] text-white rounded-md text-sm outline-none"
                />
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setGoogleView('chooser')}
                    className="text-xs text-[#8ab4f8] hover:underline cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-[#8ab4f8] text-[#001d35] font-medium rounded-full text-xs cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </form>
            )}

            {googleView === 'client_id' && (
              <div className="mt-6 space-y-4">
                <h2 className="text-xl font-normal text-white">Configure Google Client ID</h2>
                <input
                  type="text"
                  placeholder="xxxx.apps.googleusercontent.com"
                  value={clientIdInput}
                  onChange={(e) => setClientIdInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#1e1f20] border border-[#5f6368] text-white font-mono text-xs rounded-md"
                />
                <div className="flex justify-between">
                  <button
                    onClick={() => setGoogleView('chooser')}
                    className="text-xs text-[#8ab4f8] hover:underline cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (clientIdInput.trim()) {
                        setGoogleClientId(clientIdInput.trim());
                        localStorage.setItem('necpp_google_client_id', clientIdInput.trim());
                        setGoogleView('chooser');
                      }
                    }}
                    className="px-5 py-2 bg-[#8ab4f8] text-[#001d35] font-medium rounded-full text-xs cursor-pointer"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
