import React, { useState } from 'react';
import {
  X,
  Palette,
  Sun,
  Moon,
  Check,
  Globe,
  Cloud,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { useTheme, PRESET_THEME_COLORS, SPECIAL_HEX_PALETTE } from '../context/ThemeContext';

export const SettingsModal = ({ isOpen, onClose }) => {
  const { mode, toggleMode, themeColor, setThemeColor, language, toggleLanguage, t } = useTheme();
  const [activeTab, setActiveTab] = useState('appearance');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col md:flex-row overflow-hidden max-h-[85vh]">
        {/* Sidebar */}
        <div className="w-full md:w-56 bg-slate-50 dark:bg-slate-950 p-4 border-r border-slate-200 dark:border-slate-800 space-y-1">
          <p className="text-xs font-bold text-slate-800 dark:text-white px-2 mb-3">System Preferences</p>
          <button
            onClick={() => setActiveTab('appearance')}
            className={`w-full flex items-center gap-2 p-2.5 rounded-xl text-xs font-bold cursor-pointer ${
              activeTab === 'appearance' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>Theme & Colors</span>
          </button>
          <button
            onClick={() => setActiveTab('language')}
            className={`w-full flex items-center gap-2 p-2.5 rounded-xl text-xs font-bold cursor-pointer ${
              activeTab === 'language' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Language ({language.toUpperCase()})</span>
          </button>
          <button
            onClick={() => setActiveTab('deployment')}
            className={`w-full flex items-center gap-2 p-2.5 rounded-xl text-xs font-bold cursor-pointer ${
              activeTab === 'deployment' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Cloud className="w-4 h-4 text-emerald-500" />
            <span>Render & Atlas</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 overflow-y-auto space-y-5 text-xs">
          <div className="flex items-center justify-between pb-2 border-b dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white capitalize">
              {activeTab === 'appearance' ? 'Appearance & Color Theme' : activeTab === 'language' ? 'Language Preferences' : 'Render Cloud Deployment & MongoDB Atlas'}
            </h3>
            <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">
              <X className="w-5 h-5 text-slate-500" />
            </button>
          </div>

          {/* 1. APPEARANCE */}
          {activeTab === 'appearance' && (
            <div className="space-y-5">
              {/* Light vs Dark */}
              <div>
                <p className="font-bold text-slate-800 dark:text-white mb-2">Display Mode</p>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={toggleMode}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer ${
                      mode === 'light' ? 'border-blue-600 bg-blue-50/50' : 'border-slate-200'
                    }`}
                  >
                    <Sun className="w-5 h-5 text-amber-500" />
                    <div>
                      <p className="font-bold">Light Mode</p>
                      <span className="text-[10px] text-slate-500">Daylight high contrast</span>
                    </div>
                  </button>
                  <button
                    onClick={toggleMode}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer ${
                      mode === 'dark' ? 'border-blue-500 bg-slate-800 text-white' : 'border-slate-200'
                    }`}
                  >
                    <Moon className="w-5 h-5 text-indigo-400" />
                    <div>
                      <p className="font-bold">Dark Mode</p>
                      <span className="text-[10px] text-slate-400">Midnight dark</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Preset Colors */}
              <div>
                <p className="font-bold text-slate-800 dark:text-white mb-2">Standard Theme Colors</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PRESET_THEME_COLORS.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setThemeColor(c.hex)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer ${
                        themeColor === c.hex ? 'border-slate-900 ring-2 ring-blue-500/30' : 'border-slate-200'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full" style={{ backgroundColor: c.hex }} />
                      <span className="font-bold text-xs">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Extended Custom Hex Palette */}
              <div>
                <p className="font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Custom Extended Palette (Requested Hex Codes)</span>
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {SPECIAL_HEX_PALETTE.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setThemeColor(c.hex)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer ${
                        themeColor === c.hex ? 'border-slate-900 ring-2 ring-blue-500/30' : 'border-slate-200'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full" style={{ backgroundColor: c.hex }} />
                      <div className="truncate">
                        <p className="font-bold text-[11px] truncate">{c.name}</p>
                        <p className="text-[10px] font-mono text-slate-400">{c.hex}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 2. LANGUAGE */}
          {activeTab === 'language' && (
            <div className="space-y-4">
              <p className="text-slate-600 dark:text-slate-300">
                Choose website language. When Tamil is selected, all navigation, exercises, and admin tools change to Tamil with zero English.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={toggleLanguage}
                  className={`p-4 rounded-2xl border text-left cursor-pointer ${
                    language === 'en' ? 'border-blue-600 bg-blue-50/50' : 'border-slate-200'
                  }`}
                >
                  <p className="font-bold text-sm">English (EN)</p>
                  <span className="text-[10px] text-slate-500">Global Standard</span>
                </button>
                <button
                  onClick={toggleLanguage}
                  className={`p-4 rounded-2xl border text-left cursor-pointer ${
                    language === 'ta' ? 'border-blue-600 bg-blue-50/50' : 'border-slate-200'
                  }`}
                >
                  <p className="font-bold text-sm">தமிழ் (Tamil)</p>
                  <span className="text-[10px] text-slate-500">முழுமையான தமிழ் மொழிபெயர்ப்பு</span>
                </button>
              </div>
            </div>
          )}

          {/* 3. DEPLOYMENT */}
          {activeTab === 'deployment' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-1">
                <p className="text-[10px] uppercase font-bold text-emerald-400">Production Cloud Links</p>
                <p className="font-bold text-sm">Render.com & MongoDB Atlas</p>
              </div>

              <div className="space-y-2">
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border flex items-center justify-between">
                  <div>
                    <p className="font-bold">Frontend URL (Render Static Site)</p>
                    <p className="font-mono text-blue-600">https://nec-placement-portal.onrender.com</p>
                  </div>
                  <a
                    href="https://nec-placement-portal.onrender.com"
                    target="_blank"
                    rel="noreferrer"
                    className="px-2.5 py-1 bg-blue-600 text-white rounded-lg font-bold flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>Open</span>
                  </a>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border flex items-center justify-between">
                  <div>
                    <p className="font-bold">Backend API URL (Render Web Service)</p>
                    <p className="font-mono text-blue-600">https://nec-placement-backend.onrender.com</p>
                  </div>
                  <a
                    href="https://nec-placement-backend.onrender.com/api/health"
                    target="_blank"
                    rel="noreferrer"
                    className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg font-bold flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>Health</span>
                  </a>
                </div>

                <div className="p-3 bg-slate-950 text-emerald-400 font-mono text-[11px] rounded-xl border border-slate-800">
                  <p className="text-slate-400 mb-1">MongoDB Atlas Connection String:</p>
                  mongodb+srv://admin:Placement2026@cluster0.mongodb.net/nec_placement?retryWrites=true&w=majority
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default SettingsModal;
