import React, { useState } from 'react';
import { LogOut, Settings, Globe, Database, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { SettingsModal } from './SettingsModal';

export const Header = ({ user, onLogout, onOpenCompassModal }) => {
  const { themeColor, mode, toggleMode, language, toggleLanguage, t } = useTheme();
  const [showSettings, setShowSettings] = useState(false);

  return (
    <>
      <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 flex items-center justify-between sticky top-0 z-20 shadow-2xs">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl text-white font-bold flex items-center justify-center text-sm shadow-xs transition-colors"
            style={{ backgroundColor: themeColor }}
          >
            NEC
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-800 dark:text-white leading-tight">
              {t('National Engineering College')}
            </h1>
            <p className="text-[11px] text-slate-500">Placement Preparation Ecosystem</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Toggle English / Tamil"
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span className="uppercase text-[11px] font-bold">{language === 'ta' ? 'தமிழ்' : 'EN'}</span>
          </button>

          {/* Light / Dark Mode Toggle */}
          <button
            onClick={toggleMode}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Toggle Light / Dark Mode"
          >
            {mode === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setShowSettings(true)}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Theme Settings & Palette"
          >
            <Settings className="w-4 h-4 text-slate-600 dark:text-slate-300" />
          </button>

          {/* MongoDB Atlas / Compass Button */}
          {onOpenCompassModal && (
            <button
              onClick={onOpenCompassModal}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold hover:bg-emerald-100 transition cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>MongoDB Atlas</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            </button>
          )}

          {user ? (
            <div className="flex items-center gap-2.5 pl-2 border-l border-slate-200 dark:border-slate-800">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-800 dark:text-white">{user.name}</p>
                <p className="text-[10px] text-slate-500 capitalize">{user.role?.replace('_', ' ')}</p>
              </div>
              <button
                onClick={onLogout}
                className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : null}
        </div>
      </header>

      {/* Settings Modal */}
      <SettingsModal isOpen={showSettings} onClose={() => setShowSettings(false)} />
    </>
  );
};
export default Header;
