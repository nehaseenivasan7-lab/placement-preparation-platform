import React, { createContext, useContext, useState, useEffect } from 'react';

export const PRESET_THEME_COLORS = [
  { id: 'blue', name: 'Royal Blue', hex: '#1e40af', desc: 'Campus Navy' },
  { id: 'green', name: 'Emerald Green', hex: '#15803d', desc: 'Fresh Green' },
  { id: 'orange', name: 'Amber Orange', hex: '#ea580c', desc: 'Vibrant Amber' },
  { id: 'red', name: 'Crimson Red', hex: '#dc2626', desc: 'Dynamic Crimson' },
  { id: 'gray', name: 'Slate Gray', hex: '#4b5563', desc: 'Slate Gray' },
  { id: 'purple', name: 'Royal Purple', hex: '#7e22ce', desc: 'Academic Violet' },
  { id: 'maroon', name: 'Deep Maroon', hex: '#881337', desc: 'University Maroon' },
  { id: 'pink', name: 'Hot Pink', hex: '#db2777', desc: 'Vibrant Rose' },
];

export const SPECIAL_HEX_PALETTE = [
  { id: '#B08401', name: 'Gold Mustard', hex: '#B08401' },
  { id: '#D49E8D', name: 'Dusty Peach', hex: '#D49E8D' },
  { id: '#683B2B', name: 'Deep Terracotta', hex: '#683B2B' },
  { id: '#4A6163', name: 'Slate Teal', hex: '#4A6163' },
  { id: '#F17A7E', name: 'Coral Rose', hex: '#F17A7E' },
  { id: '#E43D12', name: 'Fiery Crimson', hex: '#E43D12' },
  { id: '#00CEC8', name: 'Vibrant Cyan', hex: '#00CEC8' },
  { id: '#A1CCA6', name: 'Sage Mint', hex: '#A1CCA6' },
  { id: '#097C87', name: 'Ocean Teal', hex: '#097C87' },
  { id: '#FFCFD2', name: 'Pastel Blossom', hex: '#FFCFD2' },
];

export const TAMIL_DICTIONARY = {
  // Navigation & Actions
  'Dashboard': 'தகவல் பலகை',
  'Workspace': 'பணியிடம்',
  'Home': 'முகப்பு',
  'Settings': 'அமைப்புகள்',
  'Notifications': 'அறிவிப்புகள்',
  'Profile': 'சுயவிவரம்',
  'Logout': 'வெளியேறு',
  'Login': 'உள்நுழைய',
  'Save': 'சேமிக்க',
  'Cancel': 'ரத்து செய்',
  'Submit': 'சமர்ப்பி',
  'Search': 'தேடுக',
  'Practice': 'பயிற்சி செய்',
  'Learn': 'கற்க',
  'Solve': 'தீர்க்கவும்',
  'Run Code': 'நிரலை இயக்கு',
  'Check Answer': 'பதிலைச் சரிபார்',
  'Explanation': 'விளக்கம்',
  'Passed': 'வெற்றி பெற்றது',
  'Failed': 'தோல்வி அடைந்தது',
  
  // Roles
  'Student': 'மாணவர்',
  'Junior': 'இளநிலை மாணவர் (2ஆம் ஆண்டு)',
  'Senior': 'மூத்த வழிகாட்டி',
  'Admin': 'நிர்வாகி',

  // Modes & Colors
  'Light Mode': 'பகல் முறைமை (Light)',
  'Dark Mode': 'இரவு முறைமை (Dark)',
  'Display Mode': 'காட்சி முறைமை',
  'Color Theme': 'வண்ண தீம்',
  'Standard Theme Colors': 'நிலையான வண்ண தீம்கள்',
  'Custom Extended Palette': 'விருப்ப விரிவாக்கப்பட்ட வண்ணங்கள்',
  'Royal Blue': 'ராஜ நீலம்',
  'Emerald Green': 'மரகத பச்சை',
  'Amber Orange': 'அம்பர் ஆரஞ்சு',
  'Crimson Red': 'கருஞ்சிவப்பு',
  'Slate Gray': 'சாம்பல் சாம்பல்',
  'Royal Purple': 'அரசு ஊதா',
  'Deep Maroon': 'அடர்ந்த மெரூன்',
  'Hot Pink': 'இளஞ்சிவப்பு',

  // Junior Practice
  'Junior Placement Roadmap & Practice Studio': 'இளநிலை வேலைவாய்ப்பு வழிகாட்டி & பயிற்சி அரங்கம்',
  'Beginner Coding Problems': 'தொடக்க நிலை நிரலாக்க வினாக்கள்',
  'Variables & Logic: Check Even or Odd': 'மாறிகள் & தர்க்கம்: இரட்டை அல்லது ஒற்றை எண்',
  'Loops: FizzBuzz Classic': 'மடக்குகள்: ஃபிஸ்பஸ் கிளாசிக்',
  'Functions: Prime Number Checker': 'செயல்பாடுகள்: பகா எண் சரிபார்ப்பு',
  'Arrays: Reverse Array In-Place': 'வரிசைகள்: தலைகீழ் வரிசை மாற்றம்',
  'Interactive Git Terminal Simulator': 'ஊடாடும் கிட் முனையப் போலி',
  'Interactive SQL Query Studio': 'ஊடாடும் எஸ்கியூஎல் வினவல் கூடம்',
  'Ask a Senior': 'மூத்த வழிகாட்டியிடம் கேளுங்கள்',
  'Daily Challenges': 'தினசரி சவால்கள்',
  'Learning Planner': 'கற்றல் திட்டமிடுபவர்',

  // Admin Center
  'Admin Command Center': 'நிர்வாக கட்டுப்பாட்டு மையம்',
  'Send Email Broadcast': 'அறிவிப்பு மின்னஞ்சல் அனுப்பு',
  'Send Direct Message': 'நேரடி தனிப்பட்ட செய்தி அனுப்பு',
  'Live Activity Monitor': 'நேரலை மாணவர் பயிற்சி கண்காணிப்பாளர்',
  'Book Live Sessions': 'நேரலை அமர்வுகளை முன்பதிவு செய்',
  'Manage Drives': 'வேலைவாய்ப்பு முகாம்களை நிர்வகி',
  'Export Cohort CSV': 'மாணவர் பட்டியல் கோப்பைப் பதிவிறக்கு',
};

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const [mode, setMode] = useState(() => localStorage.getItem('nec_mode') || 'light');
  const [themeColor, setThemeColorState] = useState(() => localStorage.getItem('nec_color') || '#1e40af');
  const [language, setLanguage] = useState(() => localStorage.getItem('nec_lang') || 'en');

  const setThemeColor = (color) => {
    setThemeColorState(color);
    localStorage.setItem('nec_color', color);
  };

  const toggleMode = () => {
    const nextMode = mode === 'dark' ? 'light' : 'dark';
    setMode(nextMode);
    localStorage.setItem('nec_mode', nextMode);
  };

  const toggleLanguage = () => {
    const nextLang = language === 'ta' ? 'en' : 'ta';
    setLanguage(nextLang);
    localStorage.setItem('nec_lang', nextLang);
  };

  // Sync DOM with mode and theme color
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-mode', mode);
    if (mode === 'dark') {
      root.classList.add('dark');
      document.body?.classList.add('dark');
    } else {
      root.classList.remove('dark');
      document.body?.classList.remove('dark');
    }

    root.style.setProperty('--theme-color', themeColor);
    root.style.setProperty('--primary', themeColor);
    root.style.setProperty('--theme-hover', themeColor);
    root.style.setProperty('--theme-light', themeColor + '1f');
  }, [mode, themeColor]);

  // Pervasive Tamil DOM Translation Engine
  useEffect(() => {
    if (language !== 'ta' || typeof document === 'undefined') return;

    const translateNode = (node) => {
      if (node.nodeType === Node.TEXT_NODE && node.nodeValue) {
        const raw = node.nodeValue.trim();
        if (raw && /[a-zA-Z]/.test(raw)) {
          if (TAMIL_DICTIONARY[raw]) {
            node.nodeValue = node.nodeValue.replace(raw, TAMIL_DICTIONARY[raw]);
            return;
          }
          let replaced = node.nodeValue;
          let changed = false;
          for (const [eng, tam] of Object.entries(TAMIL_DICTIONARY)) {
            if (replaced.includes(eng)) {
              replaced = replaced.split(eng).join(tam);
              changed = true;
            }
          }
          if (changed) {
            node.nodeValue = replaced;
          }
        }
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        if (['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE'].includes(node.tagName)) return;
        node.childNodes.forEach(translateNode);
      }
    };

    translateNode(document.body);

    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        m.addedNodes.forEach(translateNode);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    return () => observer.disconnect();
  }, [language]);

  const t = (keyOrText, fallback) => {
    if (!keyOrText) return '';
    if (language !== 'ta') return fallback || keyOrText;
    if (TAMIL_DICTIONARY[keyOrText]) return TAMIL_DICTIONARY[keyOrText];
    let replaced = keyOrText;
    for (const [eng, tam] of Object.entries(TAMIL_DICTIONARY)) {
      if (replaced.includes(eng)) {
        replaced = replaced.split(eng).join(tam);
      }
    }
    return replaced || fallback || keyOrText;
  };

  return (
    <ThemeContext.Provider
      value={{
        mode,
        toggleMode,
        themeColor,
        setThemeColor,
        language,
        toggleLanguage,
        isTamil: language === 'ta',
        t,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    return {
      mode: 'light',
      toggleMode: () => {},
      themeColor: '#1e40af',
      setThemeColor: () => {},
      language: 'en',
      toggleLanguage: () => {},
      isTamil: false,
      t: (k, f) => f || k,
    };
  }
  return ctx;
}
