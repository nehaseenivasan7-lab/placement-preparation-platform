import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { AppRoutes } from './routes/AppRoutes';
import { getStoredUser, saveAuthSession, clearAuthSession } from './store/authStore';
import { Database, CheckCircle2, Copy } from 'lucide-react';
import './App.css';

export function App() {
  const [user, setUser] = useState(getStoredUser());
  const [activeTab, setActiveTab] = useState('overview');
  const [showCompassModal, setShowCompassModal] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (user?.role === 'junior') setActiveTab('journey');
    else if (user?.role === 'admin') setActiveTab('overview');
    else if (user?.role === 'senior') setActiveTab('mentor');
    else setActiveTab('playbooks');
  }, [user]);

  const handleLoginSuccess = (userData, token) => {
    saveAuthSession(userData, token);
    setUser(userData);
  };

  const handleLogout = () => {
    clearAuthSession();
    setUser(null);
  };

  const copyCompassUri = () => {
    navigator.clipboard?.writeText('mongodb://localhost:27017/nec_placement');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!user) {
    return (
      <>
        <AuthModal
          onLoginSuccess={handleLoginSuccess}
          onOpenCompass={() => setShowCompassModal(true)}
        />
        {/* MongoDB Compass Connection Modal */}
        {showCompassModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
              <div className="flex items-center gap-2 text-emerald-800">
                <Database className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold">MongoDB Compass Connection</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Connect your local MongoDB Compass application to the NEC Placement Ecosystem database with real-time data persistence.
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Compass Connection URI</p>
                <div className="flex items-center justify-between font-mono text-xs bg-white p-2 rounded border border-slate-300">
                  <span className="truncate">mongodb://localhost:27017/nec_placement</span>
                  <button
                    onClick={copyCompassUri}
                    className="ml-2 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded text-xs flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
              <div className="text-[11px] text-slate-500 space-y-1">
                <p><strong>Database Name:</strong> nec_placement</p>
                <p><strong>Collections:</strong> users, drives, companies, practices, applications</p>
              </div>
              <button
                onClick={() => setShowCompassModal(false)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header
        user={user}
        onLogout={handleLogout}
        onOpenCompassModal={() => setShowCompassModal(true)}
      />

      <div className="flex flex-1">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          role={user.role}
        />

        <main className="flex-1 overflow-y-auto">
          <AppRoutes
            user={user}
            activeTab={activeTab}
            onNavigate={setActiveTab}
          />
        </main>
      </div>

      {/* MongoDB Compass Connection Modal */}
      {showCompassModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-emerald-800">
              <Database className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-bold">MongoDB Compass Connection</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Connect your local MongoDB Compass application to the NEC Placement Ecosystem database with real-time data persistence.
            </p>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Compass Connection URI</p>
              <div className="flex items-center justify-between font-mono text-xs bg-white p-2 rounded border border-slate-300">
                <span className="truncate">mongodb://localhost:27017/nec_placement</span>
                <button
                  onClick={copyCompassUri}
                  className="ml-2 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 space-y-1">
              <p><strong>Database Name:</strong> nec_placement</p>
              <p><strong>Collections:</strong> users, drives, companies, practices, applications</p>
            </div>
            <button
              onClick={() => setShowCompassModal(false)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg text-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
