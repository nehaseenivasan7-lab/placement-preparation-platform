/**
 * Auth Store (JavaScript)
 * Manages active user authentication state, token, role, and local persistence.
 */

const STORAGE_KEY_USER = 'nec_app_user';
const STORAGE_KEY_TOKEN = 'nec_app_token';

export const getStoredUser = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USER);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

export const getStoredToken = () => {
  return localStorage.getItem(STORAGE_KEY_TOKEN) || null;
};

export const saveAuthSession = (user, token) => {
  if (user) localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
  if (token) localStorage.setItem(STORAGE_KEY_TOKEN, token);
};

export const clearAuthSession = () => {
  localStorage.removeItem(STORAGE_KEY_USER);
  localStorage.removeItem(STORAGE_KEY_TOKEN);
};
