/**
 * Original Google OAuth 2.0 Configuration
 * Universal Google Identity Services (GIS) Client
 *
 * HOW TO EDIT YOUR GOOGLE CLIENT ID:
 * 1. Open Google Cloud Console: https://console.cloud.google.com/apis/credentials
 * 2. Create an OAuth 2.0 Client ID (Web application)
 * 3. Add Authorized Origins: http://localhost:3000, http://localhost:5173
 * 4. Replace YOUR_GOOGLE_CLIENT_ID_HERE below or set VITE_GOOGLE_CLIENT_ID in your .env file
 */

export const GOOGLE_CLIENT_ID =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GOOGLE_CLIENT_ID) ||
  'YOUR_GOOGLE_CLIENT_ID_HERE.apps.googleusercontent.com';

// Common Google Accounts (Original Google Authentication - Image 2)
export const DEFAULT_GOOGLE_ACCOUNTS = [
  {
    name: 'Anand Kumar',
    email: 'anand.kumar@gmail.com',
    avatarColor: '#1a73e8', // Google Blue
    avatarLetter: 'A',
    role: 'pre_final',
  },
  {
    name: 'Priya Sharma',
    email: 'priya.sharma@gmail.com',
    avatarColor: '#e37400', // Google Orange
    avatarLetter: 'P',
    status: 'Signed out',
    role: 'senior',
  },
  {
    name: 'Candidate User',
    email: 'candidate.user@gmail.com',
    avatarColor: '#188038', // Google Green
    avatarLetter: 'C',
    status: 'Signed out',
    role: 'junior',
  },
];

export function getGoogleOAuthUrl(clientId = GOOGLE_CLIENT_ID, redirectUri = window.location.origin) {
  const rootUrl = 'https://accounts.google.com/o/oauth2/v2/auth';
  const options = {
    redirect_uri: redirectUri,
    client_id: clientId,
    access_type: 'offline',
    response_type: 'token',
    prompt: 'select_account',
    scope: [
      'https://www.googleapis.com/auth/userinfo.profile',
      'https://www.googleapis.com/auth/userinfo.email',
    ].join(' '),
  };

  const qs = new URLSearchParams(options);
  return `${rootUrl}?${qs.toString()}`;
}

