import React from 'react';
import { JuniorDashboard } from '../pages/JuniorDashboard';
import { PreFinalDashboard } from '../pages/PreFinalDashboard';
import { SeniorDashboard } from '../pages/SeniorDashboard';
import { AdminDashboard } from '../pages/AdminDashboard';
import { PracticeStudioPage } from '../pages/PracticeStudioPage';
import { CompanyPlaybookPage } from '../pages/CompanyPlaybookPage';

export const AppRoutes = ({ user, activeTab, onNavigate }) => {
  if (!user) return null;

  // Global tab overrides
  if (activeTab === 'practice') return <PracticeStudioPage />;
  if (activeTab === 'playbooks') return <CompanyPlaybookPage />;

  // Role based dashboards
  switch (user.role) {
    case 'junior':
      return <JuniorDashboard />;
    case 'senior':
      return <SeniorDashboard />;
    case 'admin':
      return <AdminDashboard />;
    case 'pre_final':
    default:
      return <PreFinalDashboard onNavigate={onNavigate} />;
  }
};
