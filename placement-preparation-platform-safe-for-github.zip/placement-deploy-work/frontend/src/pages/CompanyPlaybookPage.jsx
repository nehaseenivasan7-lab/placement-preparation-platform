import React from 'react';
import { Building2, ExternalLink } from 'lucide-react';

export const CompanyPlaybookPage = () => {
  const companies = [
    {
      name: 'Zoho Corporation',
      ctc: '₹8.4 - 12.0 LPA',
      rounds: '5 Rounds (Aptitude, Basic Coding, Advanced Coding, Tech, HR)',
      focus: 'C/Java Pointers, Recursion, OOP System Design, Zero external libraries',
    },
    {
      name: 'TCS (Digital & Ninja)',
      ctc: '₹3.6 - 9.0 LPA',
      rounds: '3 Rounds (NQT Cognitive & Advanced Coding, Tech, Managerial)',
      focus: 'Speed math, Advanced DSA, SQL, DBMS, Cloud fundamentals',
    },
    {
      name: 'Accenture',
      ctc: '₹4.5 - 6.5 LPA',
      rounds: '4 Rounds (Cognitive, Coding, AI Communication Assessment, Tech Interview)',
      focus: 'Critical thinking, Pseudocode debugging, Conversational fluency',
    },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-800">Company Playbooks</h2>
        <p className="text-xs text-slate-500">
          In-depth recruitment strategies, syllabus breakdown, and round patterns
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {companies.map((c, i) => (
          <div key={i} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-base">{c.name}</h3>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {c.ctc}
              </span>
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Hiring Rounds</p>
              <p className="text-xs text-slate-700 mt-0.5">{c.rounds}</p>
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Core Technical Focus</p>
              <p className="text-xs text-slate-700 mt-0.5">{c.focus}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
