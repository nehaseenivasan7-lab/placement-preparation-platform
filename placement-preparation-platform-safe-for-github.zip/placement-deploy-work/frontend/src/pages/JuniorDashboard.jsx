import React, { useState, useEffect } from 'react';
import {
  Code2,
  Award,
  Terminal,
  Database,
  Flame,
  MessageSquare,
  Calendar,
  Compass,
  Building2,
  CheckCircle2,
  Play,
  RotateCcw,
  Clock,
  Send,
  Sparkles,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const JuniorDashboard = () => {
  const { t, themeColor } = useTheme();
  const [activeTab, setActiveTab] = useState('coding_basics');

  // ================= 1. CODING PLAYGROUND =================
  const codingProblems = [
    {
      id: 0,
      title: '1. Variables & Logic: Check Even or Odd',
      difficulty: 'Easy',
      description: 'Write a function isEven(n) returning true if n is even, false if odd without % 2.',
      starterCode: 'function isEven(n) {\n  // Your code here\n  return (n & 1) === 0;\n}',
      testCases: [
        { input: 24, expected: 'true' },
        { input: 17, expected: 'false' },
        { input: 0, expected: 'true' },
      ],
    },
    {
      id: 1,
      title: '2. Loops: FizzBuzz Classic',
      difficulty: 'Easy',
      description: 'Write fizzBuzz(n) returning "Fizz" if divisible by 3, "Buzz" if by 5, "FizzBuzz" if both.',
      starterCode: 'function fizzBuzz(n) {\n  if (n % 15 === 0) return "FizzBuzz";\n  if (n % 3 === 0) return "Fizz";\n  if (n % 5 === 0) return "Buzz";\n  return String(n);\n}',
      testCases: [
        { input: 15, expected: 'FizzBuzz' },
        { input: 9, expected: 'Fizz' },
      ],
    },
    {
      id: 2,
      title: '3. Functions: Prime Checker',
      difficulty: 'Medium',
      description: 'Write isPrime(n) to verify if an integer n > 1 is a prime number.',
      starterCode: 'function isPrime(n) {\n  if (n <= 1) return false;\n  for (let i = 2; i * i <= n; i++) {\n    if (n % i === 0) return false;\n  }\n  return true;\n}',
      testCases: [
        { input: 29, expected: 'true' },
        { input: 49, expected: 'false' },
      ],
    },
    {
      id: 3,
      title: '4. Arrays: Reverse In-Place',
      difficulty: 'Easy',
      description: 'Write a function reverseArray(arr) that reverses the elements of an array.',
      starterCode: 'function reverseArray(arr) {\n  return arr.reverse();\n}',
      testCases: [
        { input: [1, 2, 3], expected: '[3,2,1]' },
      ],
    },
  ];

  const [selectedCodingProblem, setSelectedCodingProblem] = useState(0);
  const [userCode, setUserCode] = useState(codingProblems[0].starterCode);
  const [codeOutput, setCodeOutput] = useState(null);
  const [codingSolved, setCodingSolved] = useState({});

  useEffect(() => {
    setUserCode(codingProblems[selectedCodingProblem].starterCode);
    setCodeOutput(null);
  }, [selectedCodingProblem]);

  const handleRunCode = () => {
    const prob = codingProblems[selectedCodingProblem];
    const logs = [`🚀 Running test cases for ${prob.title}...`];
    prob.testCases.forEach((tc, idx) => {
      logs.push(`✓ Test Case ${idx + 1}: Passed (Expected: ${tc.expected})`);
    });
    logs.push(`🎉 All ${prob.testCases.length} Test Cases Passed Successfully! (+25 XP)`);
    setCodeOutput({ pass: true, logs });
    setCodingSolved((prev) => ({ ...prev, [selectedCodingProblem]: true }));
  };

  // ================= 2. APTITUDE QUIZ =================
  const aptitudeQuestions = [
    {
      id: 0,
      topic: 'Percentages & Speed Math',
      question: 'If price increases by 25%, by what % must consumption be reduced so expenditure remains unchanged?',
      options: ['20%', '25%', '15%', '16.66%'],
      correct: 0,
      explanation: '[R / (100 + R)] * 100 = [25 / 125] * 100 = 20%.',
    },
    {
      id: 1,
      topic: 'Logical Reasoning',
      question: 'Find next number in the series: 2, 6, 12, 20, 30, ?',
      options: ['40', '42', '44', '48'],
      correct: 1,
      explanation: 'Differences are +4, +6, +8, +10, +12. 30 + 12 = 42.',
    },
    {
      id: 2,
      topic: 'Time & Work',
      question: 'A finishes work in 12 days, B in 24 days. Working together, how many days will they take?',
      options: ['6 days', '8 days', '10 days', '16 days'],
      correct: 1,
      explanation: '1/12 + 1/24 = 3/24 = 1/8. Answer is 8 days.',
    },
  ];

  const [selectedAptOptions, setSelectedAptOptions] = useState({});
  const [aptSubmitted, setAptSubmitted] = useState({});
  const [aptTimer, setAptTimer] = useState(60);

  useEffect(() => {
    const t = setInterval(() => setAptTimer((p) => (p > 0 ? p - 1 : 60)), 1000);
    return () => clearInterval(t);
  }, []);

  // ================= 3. GIT SIMULATOR =================
  const [gitLogs, setGitLogs] = useState([
    'Welcome to NEC Junior Git Terminal Simulator!',
    'Try typing: git init, git add ., or git commit -m "First commit"',
  ]);
  const [gitInput, setGitInput] = useState('');

  const handleGitSubmit = (e) => {
    e.preventDefault();
    if (!gitInput.trim()) return;
    const cmd = gitInput.trim();
    const newLogs = [...gitLogs, `$ ${cmd}`];

    if (cmd === 'git init') {
      newLogs.push('Initialized empty Git repository in /workspace/project/.git/');
    } else if (cmd === 'git add .') {
      newLogs.push('Staged all modified files for commit.');
    } else if (cmd.startsWith('git commit')) {
      newLogs.push('[main (root-commit) 7a8b9c] ' + (cmd.split('-m')[1] || 'Initial commit'));
      newLogs.push(' 2 files changed, 24 insertions(+)');
    } else if (cmd === 'git status') {
      newLogs.push('On branch main. Nothing to commit, working tree clean.');
    } else {
      newLogs.push(`Command '${cmd}' executed. Try 'git init', 'git add .', 'git commit -m "msg"'.`);
    }

    setGitLogs(newLogs);
    setGitInput('');
  };

  // ================= 4. SQL QUERY STUDIO =================
  const [sqlQuery, setSqlQuery] = useState('SELECT name, department, cgpa FROM students WHERE cgpa >= 8.5;');
  const [sqlExecuted, setSqlExecuted] = useState(true);

  // ================= 5. DAILY CHALLENGES =================
  const [challenges, setChallenges] = useState([
    { id: 1, title: 'Count Vowels & Consonants', xp: 25, completed: false },
    { id: 2, title: 'Solve Train Platform Problem', xp: 20, completed: false },
    { id: 3, title: 'Practice 60-Second Elevator Pitch', xp: 30, completed: false },
  ]);

  // ================= 6. ASK A SENIOR =================
  const [seniorQuestions, setSeniorQuestions] = useState([
    {
      id: 1,
      student: 'Junior (25104001)',
      question: 'When should a 2nd year student start solving LeetCode problems?',
      reply: 'Priya Dharshini (Zoho MTS): Master basic array and string loops in 3rd sem, then start LeetCode Easy problems in 4th sem. Practice consistently!',
    },
    {
      id: 2,
      student: 'Junior (25104002)',
      question: 'What is the minimum CGPA required for Tier-1 companies visiting NEC?',
      reply: 'Karthik Raja (TCS Digital): Maintain strictly 8.0+ CGPA with zero active backlogs to ensure eligibility for 95%+ of companies.',
    },
  ]);
  const [newQText, setNewQText] = useState('');

  const handlePostQuestion = (e) => {
    e.preventDefault();
    if (!newQText.trim()) return;
    setSeniorQuestions([
      {
        id: Date.now(),
        student: 'Junior (You)',
        question: newQText,
        reply: 'Senior Mentor: Thanks for asking! In 2nd year, focus on DSA basics and logic building 45 minutes daily.',
      },
      ...seniorQuestions,
    ]);
    setNewQText('');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 text-xs">
      {/* Top Banner */}
      <div
        className="p-6 rounded-3xl text-white shadow-md"
        style={{ background: `linear-gradient(135deg, ${themeColor} 0%, #0f172a 100%)` }}
      >
        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 bg-amber-400/20 px-2.5 py-0.5 rounded-full border border-amber-300/30">
          Junior Foundation Hub • 2nd Year (Batch 2028)
        </span>
        <h2 className="text-2xl font-black mt-2">{t('Junior Placement Roadmap & Practice Studio')}</h2>
        <p className="text-xs text-blue-100 mt-1 max-w-2xl leading-relaxed">
          {t('Learn coding fundamentals, speed aptitude, interactive Git, SQL, and connect with placed seniors.')}
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center gap-1.5 overflow-x-auto scrollbar-none">
        {[
          { id: 'coding_basics', label: 'Coding Basics', icon: Code2 },
          { id: 'aptitude_starter', label: 'Aptitude Starter', icon: Award },
          { id: 'skills', label: 'Git & SQL Lab', icon: Terminal },
          { id: 'challenges', label: 'Daily Challenges', icon: Flame },
          { id: 'ask_senior', label: 'Ask a Senior', icon: MessageSquare },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              style={{ backgroundColor: isActive ? themeColor : undefined }}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. CODING PLAYGROUND */}
      {activeTab === 'coding_basics' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-4 space-y-2">
            <h3 className="font-bold text-slate-800 dark:text-white text-sm mb-2">Practice Problems</h3>
            {codingProblems.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedCodingProblem(p.id)}
                className={`w-full p-3 rounded-xl text-left border transition flex items-center justify-between cursor-pointer ${
                  selectedCodingProblem === p.id
                    ? 'border-blue-500 bg-blue-50 dark:bg-slate-800 text-blue-950 dark:text-white font-bold'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700'
                }`}
              >
                <div>
                  <p className="text-xs">{p.title}</p>
                  <span className="text-[10px] text-slate-400">{p.difficulty}</span>
                </div>
                {codingSolved[p.id] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
              </button>
            ))}
          </div>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                {codingProblems[selectedCodingProblem].title}
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                {codingProblems[selectedCodingProblem].difficulty}
              </span>
            </div>
            <p className="text-slate-600 dark:text-slate-300 text-xs">
              {codingProblems[selectedCodingProblem].description}
            </p>

            <textarea
              rows={6}
              value={userCode}
              onChange={(e) => setUserCode(e.target.value)}
              className="w-full p-3 font-mono text-xs bg-slate-950 text-emerald-400 rounded-xl outline-none leading-relaxed"
            />

            <div className="flex items-center justify-between">
              <button
                onClick={handleRunCode}
                className="px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-xs"
                style={{ backgroundColor: themeColor }}
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run Code & Verify Tests</span>
              </button>
              {codingSolved[selectedCodingProblem] && (
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Solved (+25 XP)</span>
                </span>
              )}
            </div>

            {codeOutput && (
              <div className="p-4 bg-slate-900 rounded-2xl font-mono text-xs text-emerald-400 space-y-1">
                {codeOutput.logs.map((log, i) => (
                  <p key={i}>{log}</p>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. APTITUDE STARTER */}
      {activeTab === 'aptitude_starter' && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Speed Math & Logic Starter</h3>
            <div className="flex items-center gap-2 font-mono text-amber-700 bg-amber-50 px-3 py-1 rounded-xl border border-amber-200">
              <Clock className="w-4 h-4" />
              <span>{aptTimer}s left</span>
            </div>
          </div>

          <div className="space-y-4">
            {aptitudeQuestions.map((q) => (
              <div key={q.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3">
                <p className="font-bold text-slate-800 dark:text-slate-200">{q.id + 1}. {q.question}</p>
                <div className="grid grid-cols-2 gap-2">
                  {q.options.map((opt, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedAptOptions({ ...selectedAptOptions, [q.id]: idx })}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer ${
                        selectedAptOptions[q.id] === idx ? 'bg-blue-900 text-white' : 'bg-white text-slate-700'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setAptSubmitted({ ...aptSubmitted, [q.id]: true })}
                  className="px-4 py-1.5 rounded-lg bg-blue-900 text-white font-bold cursor-pointer"
                  style={{ backgroundColor: themeColor }}
                >
                  Check Answer
                </button>
                {aptSubmitted[q.id] && (
                  <p className="text-xs text-slate-600 font-medium">💡 Formula: {q.explanation}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. GIT & SQL LAB */}
      {activeTab === 'skills' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Git Terminal */}
          <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800 text-white space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="font-bold">Interactive Git Simulator</span>
            </div>
            <div className="h-44 overflow-y-auto font-mono text-[11px] space-y-1">
              {gitLogs.map((l, i) => (
                <p key={i} className={l.startsWith('$') ? 'text-amber-300 font-bold' : 'text-emerald-400'}>{l}</p>
              ))}
            </div>
            <form onSubmit={handleGitSubmit} className="flex gap-2 pt-2 border-t border-slate-800 font-mono">
              <span className="text-emerald-400">$</span>
              <input
                type="text"
                placeholder="git init, git add ., git commit -m '...'"
                value={gitInput}
                onChange={(e) => setGitInput(e.target.value)}
                className="flex-1 bg-transparent text-white outline-none"
              />
            </form>
          </div>

          {/* SQL Query Studio */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Database className="w-4 h-4 text-blue-600" />
              <span className="font-bold text-slate-900 dark:text-white">Interactive SQL Studio</span>
            </div>
            <textarea
              rows={3}
              value={sqlQuery}
              onChange={(e) => setSqlQuery(e.target.value)}
              className="w-full p-2.5 bg-slate-950 text-emerald-400 font-mono rounded-xl outline-none"
            />
            <button
              onClick={() => setSqlExecuted(true)}
              className="px-4 py-2 rounded-xl bg-blue-900 text-white font-bold cursor-pointer"
              style={{ backgroundColor: themeColor }}
            >
              Execute Query
            </button>
            {sqlExecuted && (
              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 font-bold">
                    <tr>
                      <th className="p-2">Name</th>
                      <th className="p-2">Department</th>
                      <th className="p-2">CGPA</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    <tr><td className="p-2">Anandha Selvan</td><td className="p-2">CSE</td><td className="p-2 font-bold text-blue-600">8.92</td></tr>
                    <tr><td className="p-2">Bavithra K</td><td className="p-2">IT</td><td className="p-2 font-bold text-blue-600">8.65</td></tr>
                    <tr><td className="p-2">Karthik Raja</td><td className="p-2">ECE</td><td className="p-2 font-bold text-blue-600">8.52</td></tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. DAILY CHALLENGES */}
      {activeTab === 'challenges' && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Today's Placement Sprints</h3>
          <div className="space-y-3">
            {challenges.map((c) => (
              <div key={c.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{c.title}</p>
                  <span className="text-[10px] text-amber-600 font-bold">+{c.xp} XP Points</span>
                </div>
                <button
                  onClick={() => setChallenges((prev) => prev.map((item) => (item.id === c.id ? { ...item, completed: true } : item)))}
                  className={`px-4 py-2 rounded-xl font-bold cursor-pointer ${
                    c.completed ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-900 text-white'
                  }`}
                  style={{ backgroundColor: !c.completed ? themeColor : undefined }}
                >
                  {c.completed ? '✓ Completed' : 'Solve & Claim'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. ASK A SENIOR */}
      {activeTab === 'ask_senior' && (
        <div className="space-y-4">
          <form onSubmit={handlePostQuestion} className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Ask Placed Seniors for Advice</h4>
            <textarea
              rows={3}
              placeholder="Type your question about coding, CGPA, interview rounds, or prep roadmap..."
              value={newQText}
              onChange={(e) => setNewQText(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 outline-none"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-900 text-white font-bold flex items-center gap-2 cursor-pointer"
              style={{ backgroundColor: themeColor }}
            >
              <Send className="w-3.5 h-3.5" />
              <span>Post Question</span>
            </button>
          </form>

          <div className="space-y-3">
            {seniorQuestions.map((q) => (
              <div key={q.id} className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
                <p className="font-bold text-slate-900 dark:text-white">Q: {q.question}</p>
                <div className="p-3 rounded-xl bg-blue-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {q.reply}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
export default JuniorDashboard;
