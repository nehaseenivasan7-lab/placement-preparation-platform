import React from 'react';
import { Building2, Code2, BookOpen, Award, BarChart3, CheckCircle2 } from 'lucide-react';

export const PreFinalDashboard = ({ onNavigate }) => {
  const highlights = [
    { title: 'Company Playbook', desc: 'Zoho, TCS, Accenture round-wise preparation strategies and coding patterns.', action: 'playbooks', icon: Building2 },
    { title: 'Practice Studio', desc: 'Multiple timed sections for Aptitude, DSA Coding, and Core CS MCQs.', action: 'practice', icon: Code2 },
    { title: 'Interview Experiences', desc: 'Real experiences from 2026 placed seniors with questions asked.', action: 'experiences', icon: BookOpen },
    { title: 'Readiness Analytics', desc: 'Track your DSA problem solved count, OA speed, and mock ratings.', action: 'analytics', icon: BarChart3 },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-indigo-900 to-purple-900 text-white p-6 rounded-2xl shadow-md">
        <span className="text-xs font-bold uppercase tracking-wider text-purple-200 bg-purple-800/60 px-2.5 py-1 rounded">
          Pre-Final Year Workspace (3rd Year Batch 2027)
        </span>
        <h2 className="text-2xl font-bold mt-2">Day-1 Recruitment Preparation Hub</h2>
        <p className="text-sm text-purple-100 max-w-2xl mt-1">
          Master company-specific technical patterns, ace online assessments, and simulate technical interviews.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {highlights.map((h, i) => {
          const Icon = h.icon;
          return (
            <div
              key={i}
              onClick={() => onNavigate && onNavigate(h.action)}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition cursor-pointer flex gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-base">{h.title}</h3>
                <p className="text-xs text-slate-500 mt-1">{h.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
