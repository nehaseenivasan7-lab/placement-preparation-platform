import React from 'react';
import { Users2, BookOpen, Building2, Code2, PlusCircle } from 'lucide-react';

export const SeniorDashboard = () => {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-amber-900 to-yellow-800 text-white p-6 rounded-2xl shadow-md">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-200 bg-amber-800/60 px-2.5 py-1 rounded">
          Senior Mentor Workspace (Batch 2026)
        </span>
        <h2 className="text-2xl font-bold mt-2">Guide the Next Batch to Success</h2>
        <p className="text-sm text-amber-100 max-w-2xl mt-1">
          Share round experiences, post frequently asked technical questions, and review resumes.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
            <Building2 className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">Add Company Playbook</h3>
          <p className="text-xs text-slate-500 mt-1">
            Publish hiring rounds, technical patterns, and tips for newly visiting companies.
          </p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">Post Interview Experience</h3>
          <p className="text-xs text-slate-500 mt-1">
            Detail questions asked in OA, Technical, and HR rounds from your campus placement.
          </p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-3">
            <Code2 className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">Contribute to Question Bank</h3>
          <p className="text-xs text-slate-500 mt-1">
            Submit DSA code snippets, SQL queries, and core CS questions with explanations.
          </p>
        </div>
      </div>
    </div>
  );
};
