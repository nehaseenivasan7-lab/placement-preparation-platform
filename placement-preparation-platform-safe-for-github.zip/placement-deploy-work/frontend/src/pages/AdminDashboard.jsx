import React, { useState } from 'react';
import {
  ShieldCheck,
  Mail,
  Send,
  Video,
  Building2,
  BarChart2,
  Download,
  Users2,
  Check,
  Clock,
  Plus,
  Search,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const AdminDashboard = () => {
  const { t, themeColor } = useTheme();
  const [activeTab, setActiveTab] = useState('overview');

  // Broadcast State
  const [broadcastSubject, setBroadcastSubject] = useState('Campus Recruitment Drive Notice: Deadline Tomorrow');
  const [broadcastBody, setBroadcastBody] = useState('Dear Students, Please verify that your placement resume is uploaded.');
  const [broadcastSent, setBroadcastSent] = useState(false);

  // Direct Message State
  const [directStudent, setDirectStudent] = useState('Anandha Selvan (CSE)');
  const [directSubject, setDirectSubject] = useState('Feedback on Zoho Mock Coding Round');
  const [directBody, setDirectBody] = useState('Great performance in Round 1! Focus on graph algorithms for Round 2.');
  const [directSent, setDirectSent] = useState(false);

  // Live Sessions State
  const [liveSessions, setLiveSessions] = useState([
    { id: 1, title: 'Zoho Coding Patterns & Strategy', speaker: 'Priya Dharshini (Zoho MTS)', date: 'Tomorrow, 06:00 PM', link: 'https://meet.google.com/nec-zoho' },
    { id: 2, title: 'Cracking TCS NQT Speed Math', speaker: 'Dr. K. Kalidasa Murugavel', date: 'Oct 15, 05:00 PM', link: 'Seminar Hall 1' },
  ]);
  const [newSessionTitle, setNewSessionTitle] = useState('');
  const [newSessionSpeaker, setNewSessionSpeaker] = useState('');

  // Drives State
  const [drives, setDrives] = useState([
    { id: 1, company: 'Zoho Corporation', role: 'MTS Software Developer', ctc: '₹8.40 LPA', deadline: 'Oct 20, 2026' },
    { id: 2, company: 'TCS (Digital / Prime)', role: 'Digital Software Engineer', ctc: '₹7.00 - 9.00 LPA', deadline: 'Oct 28, 2026' },
  ]);
  const [newCompany, setNewCompany] = useState('');
  const [newRole, setNewRole] = useState('');

  // Student Cohort Management
  const [students, setStudents] = useState([
    { id: '1', name: 'Anandha Selvan', roll: '24104001', dept: 'CSE', cgpa: 8.92, status: 'Day-1 Approved' },
    { id: '2', name: 'Bavithra K', roll: '24104002', dept: 'IT', cgpa: 8.65, status: 'Eligible' },
    { id: '3', name: 'Karthik Raja M', roll: '24104003', dept: 'ECE', cgpa: 8.52, status: 'Day-1 Approved' },
    { id: '4', name: 'Divya Bharathi S', roll: '24104004', dept: 'AI&DS', cgpa: 8.78, status: 'Placed in Zoho' },
    { id: '5', name: 'Muthu Kumar P', roll: '24104005', dept: 'Mech', cgpa: 7.95, status: 'Under Review' },
  ]);

  const handleSendBroadcast = (e) => {
    e.preventDefault();
    setBroadcastSent(true);
    setTimeout(() => setBroadcastSent(false), 3000);
  };

  const handleSendDirect = (e) => {
    e.preventDefault();
    setDirectSent(true);
    setTimeout(() => setDirectSent(false), 3000);
  };

  const handleCreateSession = (e) => {
    e.preventDefault();
    if (!newSessionTitle) return;
    setLiveSessions([
      { id: Date.now(), title: newSessionTitle, speaker: newSessionSpeaker || 'Placement Officer', date: 'Upcoming', link: 'https://meet.google.com/nec-live' },
      ...liveSessions,
    ]);
    setNewSessionTitle('');
    setNewSessionSpeaker('');
  };

  const handleCreateDrive = (e) => {
    e.preventDefault();
    if (!newCompany) return;
    setDrives([
      { id: Date.now(), company: newCompany, role: newRole || 'Graduate Engineer Trainee', ctc: '₹6.50 LPA', deadline: 'Nov 15, 2026' },
      ...drives,
    ]);
    setNewCompany('');
    setNewRole('');
  };

  const handleExportCSV = () => {
    const csv = 'Name,Roll,Dept,CGPA,Status\n' + students.map(s => `"${s.name}","${s.roll}","${s.dept}","${s.cgpa}","${s.status}"`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'NEC_Placement_Students.csv';
    a.click();
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 text-xs">
      {/* Top Banner */}
      <div
        className="p-6 rounded-3xl text-white shadow-md"
        style={{ background: `linear-gradient(135deg, ${themeColor} 0%, #1e1b4b 100%)` }}
      >
        <div className="flex items-center gap-2 mb-1">
          <ShieldCheck className="w-5 h-5 text-amber-300" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
            Training & Placement Cell Admin Command Center
          </span>
        </div>
        <h2 className="text-2xl font-black mt-1">Admin Placement Control & Operations Center</h2>
        <p className="text-xs text-blue-100 mt-1 max-w-2xl leading-relaxed">
          National Engineering College, Kovilpatti • Control student access, send broadcast emails, dispatch direct messages, monitor live practice, and schedule recruitment drives.
        </p>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center gap-1.5 overflow-x-auto scrollbar-none">
        {[
          { id: 'overview', label: 'Student Cohort Control', icon: Users2 },
          { id: 'broadcast', label: 'Broadcast Emails', icon: Mail },
          { id: 'messages', label: 'Direct Messages', icon: Send },
          { id: 'monitor', label: 'Live Activity Monitor', icon: BarChart2 },
          { id: 'sessions', label: 'Book Live Sessions', icon: Video },
          { id: 'drives', label: 'Placement Drives', icon: Building2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${
                isActive ? 'text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
              style={{ backgroundColor: isActive ? themeColor : undefined }}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
        <button
          onClick={handleExportCSV}
          className="ml-auto px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* 1. STUDENT COHORT CONTROL */}
      {activeTab === 'overview' && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Registered Students Cohort</h3>
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 font-bold">
                <tr>
                  <th className="p-3">Name</th>
                  <th className="p-3">Roll Number</th>
                  <th className="p-3">Department</th>
                  <th className="p-3">CGPA</th>
                  <th className="p-3">Eligibility Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {students.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold">{s.name}</td>
                    <td className="p-3 font-mono">{s.roll}</td>
                    <td className="p-3">{s.dept}</td>
                    <td className="p-3 font-bold text-blue-600">{s.cgpa}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {s.status}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-1">
                      <button
                        onClick={() => setStudents(prev => prev.map(item => item.id === s.id ? { ...item, status: 'Day-1 Approved' } : item))}
                        className="px-2.5 py-1 bg-emerald-600 text-white font-bold rounded-lg cursor-pointer"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => {
                          setDirectStudent(s.name);
                          setActiveTab('messages');
                        }}
                        className="px-2.5 py-1 bg-blue-600 text-white font-bold rounded-lg cursor-pointer"
                      >
                        Message
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. BROADCAST EMAILS */}
      {activeTab === 'broadcast' && (
        <form onSubmit={handleSendBroadcast} className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Compose Broadcast Email to Students</h3>
          {broadcastSent && <div className="p-3 bg-emerald-100 text-emerald-800 font-bold rounded-xl">✓ Broadcast email dispatched successfully!</div>}
          <input
            type="text"
            value={broadcastSubject}
            onChange={(e) => setBroadcastSubject(e.target.value)}
            className="w-full p-2.5 border rounded-xl outline-none"
            placeholder="Subject Header"
          />
          <textarea
            rows={5}
            value={broadcastBody}
            onChange={(e) => setBroadcastBody(e.target.value)}
            className="w-full p-2.5 border rounded-xl outline-none font-mono"
            placeholder="Email Body"
          />
          <button
            type="submit"
            className="px-6 py-2.5 bg-blue-900 text-white font-bold rounded-xl cursor-pointer"
            style={{ backgroundColor: themeColor }}
          >
            Send Broadcast Email
          </button>
        </form>
      )}

      {/* 3. DIRECT MESSAGES */}
      {activeTab === 'messages' && (
        <form onSubmit={handleSendDirect} className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Send Direct Message to Student</h3>
          {directSent && <div className="p-3 bg-emerald-100 text-emerald-800 font-bold rounded-xl">✓ Direct message delivered to {directStudent}!</div>}
          <input
            type="text"
            value={directStudent}
            onChange={(e) => setDirectStudent(e.target.value)}
            className="w-full p-2.5 border rounded-xl outline-none"
            placeholder="Student Name / Roll Number"
          />
          <input
            type="text"
            value={directSubject}
            onChange={(e) => setDirectSubject(e.target.value)}
            className="w-full p-2.5 border rounded-xl outline-none"
            placeholder="Subject"
          />
          <textarea
            rows={4}
            value={directBody}
            onChange={(e) => setDirectBody(e.target.value)}
            className="w-full p-2.5 border rounded-xl outline-none font-mono"
            placeholder="Private message details"
          />
          <button
            type="submit"
            className="px-6 py-2.5 bg-blue-900 text-white font-bold rounded-xl cursor-pointer"
            style={{ backgroundColor: themeColor }}
          >
            Send Message
          </button>
        </form>
      )}

      {/* 4. LIVE MONITOR */}
      {activeTab === 'monitor' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border">
              <p className="text-slate-500">Students Practicing Today</p>
              <p className="text-2xl font-black mt-1">184 Active</p>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border">
              <p className="text-slate-500">Coding Problems Solved</p>
              <p className="text-2xl font-black text-blue-600 mt-1">1,248 Solved</p>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border">
              <p className="text-slate-500">Aptitude Pass Rate</p>
              <p className="text-2xl font-black text-emerald-600 mt-1">82.5% Pass</p>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border">
              <p className="text-slate-500">Recruitment Drives</p>
              <p className="text-2xl font-black text-purple-600 mt-1">14 Companies</p>
            </div>
          </div>
        </div>
      )}

      {/* 5. LIVE SESSIONS */}
      {activeTab === 'sessions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <form onSubmit={handleCreateSession} className="bg-white dark:bg-slate-900 p-5 rounded-3xl border space-y-3">
            <h3 className="font-bold text-sm">Schedule New Live Session</h3>
            <input
              type="text"
              placeholder="Session Title"
              value={newSessionTitle}
              onChange={(e) => setNewSessionTitle(e.target.value)}
              className="w-full p-2.5 border rounded-xl"
            />
            <input
              type="text"
              placeholder="Speaker Name"
              value={newSessionSpeaker}
              onChange={(e) => setNewSessionSpeaker(e.target.value)}
              className="w-full p-2.5 border rounded-xl"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-900 text-white font-bold rounded-xl cursor-pointer"
              style={{ backgroundColor: themeColor }}
            >
              Add Session
            </button>
          </form>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border space-y-3">
            <h3 className="font-bold text-sm">Scheduled Live Sessions</h3>
            {liveSessions.map((s) => (
              <div key={s.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                <p className="font-bold text-xs">{s.title}</p>
                <p className="text-[11px] text-slate-500">Speaker: {s.speaker} • {s.date}</p>
                <p className="font-mono text-[10px] text-blue-600">{s.link}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. PLACEMENT DRIVES */}
      {activeTab === 'drives' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <form onSubmit={handleCreateDrive} className="bg-white dark:bg-slate-900 p-5 rounded-3xl border space-y-3">
            <h3 className="font-bold text-sm">Post Campus Recruitment Drive</h3>
            <input
              type="text"
              placeholder="Company Name (e.g. Amazon)"
              value={newCompany}
              onChange={(e) => setNewCompany(e.target.value)}
              className="w-full p-2.5 border rounded-xl"
            />
            <input
              type="text"
              placeholder="Job Role"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              className="w-full p-2.5 border rounded-xl"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-900 text-white font-bold rounded-xl cursor-pointer"
              style={{ backgroundColor: themeColor }}
            >
              Post Drive
            </button>
          </form>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border space-y-3">
            <h3 className="font-bold text-sm">Active On-Campus Drives</h3>
            {drives.map((d) => (
              <div key={d.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-xs">{d.company}</p>
                  <p className="text-[11px] text-slate-500">{d.role} • {d.ctc}</p>
                </div>
                <span className="text-[10px] text-emerald-600 font-bold">Deadline: {d.deadline}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
export default AdminDashboard;
