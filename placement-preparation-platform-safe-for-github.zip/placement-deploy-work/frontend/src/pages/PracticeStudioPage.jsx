import React, { useState } from 'react';
import { Code2, Award, BookOpen, CheckCircle } from 'lucide-react';

export const PracticeStudioPage = () => {
  const [activeSection, setActiveSection] = useState('aptitude');

  const questions = {
    aptitude: [
      {
        id: 1,
        title: 'Time & Work: Combined Task Duration',
        problem: 'Pipe A can fill a tank in 6 hours and Pipe B in 8 hours. If both open together, how long to fill?',
        answer: '3 hours 25 minutes (24/7 hours)',
      },
      {
        id: 2,
        title: 'Profit & Loss: Successive Discounts',
        problem: 'Two successive discounts of 20% and 10% are equivalent to a single discount of?',
        answer: '28%',
      },
    ],
    coding: [
      {
        id: 1,
        title: 'Two Sum Problem (Arrays & Hash Maps)',
        problem: 'Given an array of integers nums and an integer target, return indices of two numbers that add up to target.',
        answer: 'Use Hash Map for O(N) single pass lookup.',
      },
      {
        id: 2,
        title: 'Longest Substring Without Repeating Characters',
        problem: 'Find the length of the longest substring without repeating characters in string s.',
        answer: 'Sliding window technique with character set tracking.',
      },
    ],
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Practice Studio</h2>
          <p className="text-xs text-slate-500">
            Dedicated multi-section practice for campus assessments
          </p>
        </div>

        {/* Section Tabs */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveSection('aptitude')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeSection === 'aptitude' ? 'bg-white text-blue-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Aptitude Section
          </button>
          <button
            onClick={() => setActiveSection('coding')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeSection === 'coding' ? 'bg-white text-blue-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Coding (DSA) Section
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {questions[activeSection]?.map((q) => (
          <div key={q.id} className="p-5 bg-white rounded-2xl border border-slate-200 space-y-2">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              {q.title}
            </h3>
            <p className="text-xs text-slate-600 font-mono bg-slate-50 p-3 rounded-lg border border-slate-100">
              {q.problem}
            </p>
            <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 p-2.5 rounded-lg border border-emerald-100">
              💡 Solution: {q.answer}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
