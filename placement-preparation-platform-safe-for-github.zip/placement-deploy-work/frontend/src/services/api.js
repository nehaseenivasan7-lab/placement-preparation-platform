/**
 * API Service (JavaScript)
 * Calls Backend REST endpoints for Auth, Drives, Companies, Practice questions, and MongoDB health.
 */

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const getHeaders = () => {
  const token = localStorage.getItem('nec_app_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export const api = {
  // Health & MongoDB Compass Status
  getHealth: async () => {
    try {
      const res = await fetch(`${API_BASE}/health`);
      return await res.json();
    } catch {
      return {
        status: 'mock-active',
        mongoCompass: {
          status: 'Ready (Local Compass URI: mongodb://localhost:27017/nec_placement)',
          uri: 'mongodb://localhost:27017/nec_placement',
        },
      };
    }
  },

  // Auth Endpoints
  login: async (username, password, role) => {
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, roleOverride: role }),
      });
      return await res.json();
    } catch {
      // Offline fallback
      return {
        success: true,
        user: {
          id: `usr_${Date.now()}`,
          username,
          name: username === 'admin@nec.edu.in' ? 'Placement Admin' : `User (${username})`,
          role: role || (username.startsWith('251') ? 'junior' : username.startsWith('sen') ? 'senior' : username.includes('admin') ? 'admin' : 'pre_final'),
          email: username.includes('@') ? username : `${username}@nec.edu.in`,
        },
        token: 'mock_jwt_token',
      };
    }
  },

  googleLogin: async (email, name) => {
    try {
      const res = await fetch(`${API_BASE}/auth/google`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name }),
      });
      return await res.json();
    } catch {
      return {
        success: true,
        user: {
          id: 'usr_google_default',
          name: name || 'Karthik Raja M',
          email: email || '24104009@nec.edu.in',
          role: 'pre_final',
        },
        token: 'mock_google_jwt_token',
      };
    }
  },

  // Drives
  getDrives: async () => {
    try {
      const res = await fetch(`${API_BASE}/drives`, { headers: getHeaders() });
      return await res.json();
    } catch {
      return { success: true, data: [] };
    }
  },

  // Companies
  getCompanies: async () => {
    try {
      const res = await fetch(`${API_BASE}/companies`, { headers: getHeaders() });
      return await res.json();
    } catch {
      return { success: true, data: [] };
    }
  },

  // Practice Questions
  getPracticeQuestions: async (section, difficulty) => {
    try {
      const query = new URLSearchParams();
      if (section) query.append('section', section);
      if (difficulty) query.append('difficulty', difficulty);
      const res = await fetch(`${API_BASE}/practice?${query.toString()}`, { headers: getHeaders() });
      return await res.json();
    } catch {
      return { success: true, data: [] };
    }
  },
};
