/**
 * Authentication Middleware
 * National Engineering College - Placement Preparation Ecosystem
 *
 * Verifies incoming JWT tokens from the Authorization header and
 * attaches the user's role and ID to the request object for route protection.
 */

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'nec_placement_super_secret_jwt_key_2026';

/**
 * Middleware to verify JWT token from Authorization header
 */
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  
  if (!authHeader) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. No Authorization header provided.',
    });
  }

  // Support both "Bearer <token>" and raw "<token>"
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : authHeader.trim();

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. No token provided.',
    });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    // Attach user information to request object
    req.user = {
      ...decoded,
      id: decoded.id || decoded.userId || decoded._id,
      role: decoded.role,
    };

    // Convenient direct access shortcuts
    req.userId = req.user.id;
    req.userRole = req.user.role;

    next();
  } catch (err) {
    const isExpired = err.name === 'TokenExpiredError';
    return res.status(403).json({
      success: false,
      message: isExpired ? 'Session expired. Please log in again.' : 'Invalid session token.',
      error: err.message,
    });
  }
};

/**
 * Middleware to restrict route access to specific roles (RBAC)
 * e.g. authorizeRoles('admin', 'senior')
 */
const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: Access restricted to roles [${allowedRoles.join(', ')}].`,
      });
    }
    next();
  };
};

module.exports = authenticateToken;
module.exports.authenticateToken = authenticateToken;
module.exports.authorizeRoles = authorizeRoles;
module.exports.JWT_SECRET = JWT_SECRET;
