/**
 * Drive Controller
 * Placement Drives and Student Applications
 */

const Drive = require('../models/Drive');
const Application = require('../models/Application');
const { getIsConnected } = require('../config/db');

let inMemoryDrives = [
  {
    driveId: 'drv_01',
    companyName: 'Zoho Corporation',
    jobRole: 'Software Development Engineer (Product)',
    packageCtc: '8.4 LPA - 12.0 LPA',
    driveDate: '2026-10-15',
    registrationDeadline: '2026-10-12',
    minCgpa: 7.5,
    maxBacklogs: 0,
    eligibleDepartments: ['CSE', 'IT', 'ECE'],
    rounds: ['Aptitude + C/Java MCQs', 'Basic Programming Round', 'Advanced DSA Round', 'Technical Interview', 'HR Interview'],
    status: 'ACTIVE',
    totalRegistered: 142,
  },
  {
    driveId: 'drv_02',
    companyName: 'TCS Digital',
    jobRole: 'Systems Engineer & Digital Developer',
    packageCtc: '7.5 LPA - 9.0 LPA',
    driveDate: '2026-10-22',
    registrationDeadline: '2026-10-18',
    minCgpa: 7.0,
    maxBacklogs: 0,
    eligibleDepartments: ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'],
    rounds: ['TCS NQT Cognitive & Tech Test', 'Coding Round', 'Technical + Managerial + HR'],
    status: 'UPCOMING',
    totalRegistered: 210,
  },
  {
    driveId: 'drv_03',
    companyName: 'Accenture',
    jobRole: 'Associate Software Engineer (ASE)',
    packageCtc: '4.5 LPA - 6.5 LPA',
    driveDate: '2026-10-28',
    registrationDeadline: '2026-10-24',
    minCgpa: 6.5,
    maxBacklogs: 1,
    eligibleDepartments: ['CSE', 'IT', 'ECE', 'EEE'],
    rounds: ['Cognitive and Technical Assessment', 'Coding Assessment', 'Communication Assessment', 'Virtual Interview'],
    status: 'UPCOMING',
    totalRegistered: 185,
  },
];

let inMemoryApplications = [];

exports.getAllDrives = async (req, res) => {
  try {
    if (getIsConnected()) {
      const dbDrives = await Drive.find();
      if (dbDrives.length > 0) return res.json({ success: true, count: dbDrives.length, data: dbDrives });
    }
    return res.json({ success: true, count: inMemoryDrives.length, data: inMemoryDrives });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getDriveById = async (req, res) => {
  const { id } = req.params;
  const drive = inMemoryDrives.find((d) => d.driveId === id);
  if (!drive) return res.status(404).json({ success: false, message: 'Drive not found' });
  return res.json({ success: true, data: drive });
};

exports.createDrive = async (req, res) => {
  try {
    const newDrive = {
      driveId: `drv_${Date.now()}`,
      ...req.body,
      totalRegistered: 0,
      status: req.body.status || 'UPCOMING',
    };
    inMemoryDrives.push(newDrive);

    if (getIsConnected()) {
      await Drive.create(newDrive);
    }

    return res.status(201).json({ success: true, message: 'Drive created', data: newDrive });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.applyToDrive = async (req, res) => {
  try {
    const { driveId } = req.params;
    const drive = inMemoryDrives.find((d) => d.driveId === driveId);
    if (!drive) return res.status(404).json({ success: false, message: 'Drive not found' });

    const newApp = {
      applicationId: `app_${Date.now()}`,
      driveId,
      companyName: drive.companyName,
      userId: req.user.id,
      rollNumber: req.user.rollNumber || '24104009',
      studentName: req.user.name,
      email: req.user.email,
      status: 'APPLIED',
      appliedAt: new Date().toISOString(),
    };

    inMemoryApplications.push(newApp);
    drive.totalRegistered += 1;

    return res.status(201).json({ success: true, message: 'Successfully applied to drive', data: newApp });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
