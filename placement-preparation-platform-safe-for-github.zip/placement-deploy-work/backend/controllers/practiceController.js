/**
 * Practice Controller
 * Multiple sections for Aptitude, Coding, and Technical questions
 */

const Practice = require('../models/Practice');
const { getIsConnected } = require('../config/db');

let inMemoryQuestions = [
  // Aptitude Section
  {
    questionId: 'apt_01',
    section: 'aptitude',
    topic: 'Quantitative Aptitude - Time & Work',
    title: 'Work Completion Problem',
    difficulty: 'Easy',
    problemStatement: 'A can complete a project in 12 days, and B can complete it in 18 days. If they work together, in how many days will the project be finished?',
    options: ['7.2 days', '6.5 days', '8 days', '7.5 days'],
    correctAnswer: '7.2 days',
    explanation: 'Combined rate = 1/12 + 1/18 = (3+2)/36 = 5/36. Total days = 36/5 = 7.2 days.',
    targetRole: 'all',
  },
  {
    questionId: 'apt_02',
    section: 'aptitude',
    topic: 'Logical Reasoning - Blood Relations',
    title: 'Family Tree Deduction',
    difficulty: 'Medium',
    problemStatement: 'Pointing to a photograph, Suresh said: "She is the daughter of the only son of my grandfather." How is the woman related to Suresh?',
    options: ['Sister', 'Mother', 'Aunt', 'Cousin'],
    correctAnswer: 'Sister',
    explanation: 'Grandfather’s only son is Suresh’s father. The daughter of Suresh’s father is Suresh’s sister.',
    targetRole: 'all',
  },
  // Coding Section
  {
    questionId: 'code_01',
    section: 'coding',
    topic: 'Arrays & Two Pointers',
    title: 'Two Sum Problem',
    difficulty: 'Easy',
    problemStatement: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.',
    sampleSolution: 'function twoSum(nums, target) {\n  const map = new Map();\n  for (let i = 0; i < nums.length; i++) {\n    const comp = target - nums[i];\n    if (map.has(comp)) return [map.get(comp), i];\n    map.set(nums[i], i);\n  }\n  return [];\n}',
    tags: ['HashMap', 'Array', 'Zoho', 'TCS'],
    targetRole: 'all',
  },
  {
    questionId: 'code_02',
    section: 'coding',
    topic: 'Strings & Frequency Counting',
    title: 'First Non-Repeating Character',
    difficulty: 'Easy',
    problemStatement: 'Given a string s, find the first non-repeating character in it and return its index. If it does not exist, return -1.',
    sampleSolution: 'function firstUniqChar(s) {\n  const freq = {};\n  for (const ch of s) freq[ch] = (freq[ch] || 0) + 1;\n  for (let i = 0; i < s.length; i++) {\n    if (freq[s[i]] === 1) return i;\n  }\n  return -1;\n}',
    tags: ['String', 'Hash Table', 'Amazon', 'Accenture'],
    targetRole: 'all',
  },
];

exports.getAllQuestions = async (req, res) => {
  const { section, difficulty } = req.query;
  let filtered = inMemoryQuestions;
  if (section) filtered = filtered.filter((q) => q.section === section);
  if (difficulty) filtered = filtered.filter((q) => q.difficulty.toLowerCase() === difficulty.toLowerCase());
  return res.json({ success: true, count: filtered.length, data: filtered });
};

exports.getSections = async (req, res) => {
  const sections = [
    { id: 'aptitude', name: 'Quantitative & Logical Aptitude', totalQuestions: 145 },
    { id: 'coding', name: 'Data Structures & Algorithms (Coding)', totalQuestions: 98 },
    { id: 'technical', name: 'Core CS (DBMS, OS, CN, OOP)', totalQuestions: 120 },
    { id: 'verbal', name: 'Verbal Ability & Grammar', totalQuestions: 60 },
  ];
  return res.json({ success: true, sections });
};
