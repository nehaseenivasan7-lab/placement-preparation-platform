/**
 * Company Controller
 * Top campus recruitment companies, eligibility, rounds, and playbooks
 */

const Company = require('../models/Company');
const { getIsConnected } = require('../config/db');

let inMemoryCompanies = [
  {
    companyId: 'comp_zoho',
    name: 'Zoho Corporation',
    tier: 'Dream',
    packageRange: '₹8.4 - 12.0 LPA',
    industry: 'Enterprise Software & Cloud SaaS',
    hiringRoles: ['Software Developer', 'Quality Analyst', 'Member Technical Staff'],
    eligibility: { minCgpa: 7.5, maxBacklogs: 0, allowedBranches: ['CSE', 'IT', 'ECE', 'EEE'] },
    recruitmentProcess: [
      { roundNumber: 1, roundName: 'Round 1: General Aptitude & C/Java Output Prediction', duration: '60 mins' },
      { roundNumber: 2, roundName: 'Round 2: Basic Programming (Arrays, Strings, Recursion)', duration: '90 mins' },
      { roundNumber: 3, roundName: 'Round 3: Advanced Programming (Design, Data Structures)', duration: '120 mins' },
      { roundNumber: 4, roundName: 'Round 4: Technical Interview & OOP Implementation', duration: '45 mins' },
      { roundNumber: 5, roundName: 'Round 5: HR & Cultural Fitment', duration: '30 mins' },
    ],
    overview: 'Zoho is a renowned Indian SaaS powerhouse with zero external funding and world-class product development standards.',
    website: 'https://www.zoho.com',
    pastHiresCount: 38,
  },
  {
    companyId: 'comp_tcs',
    name: 'TCS (Tata Consultancy Services)',
    tier: 'Super Dream',
    packageRange: '₹3.6 - 9.0 LPA (Ninja & Digital)',
    industry: 'IT Services & Consulting',
    hiringRoles: ['Assistant System Engineer', 'Digital Specialist Engineer'],
    eligibility: { minCgpa: 6.5, maxBacklogs: 1, allowedBranches: ['All Engineering Branches'] },
    recruitmentProcess: [
      { roundNumber: 1, roundName: 'Round 1: TCS NQT National Qualifier Test', duration: '180 mins' },
      { roundNumber: 2, roundName: 'Round 2: Technical Interview', duration: '40 mins' },
      { roundNumber: 3, roundName: 'Round 3: Managerial & HR Interview', duration: '20 mins' },
    ],
    overview: 'TCS is India’s largest IT services corporation, hiring students across Ninja and Digital categories.',
    website: 'https://www.tcs.com',
    pastHiresCount: 112,
  },
  {
    companyId: 'comp_accenture',
    name: 'Accenture',
    tier: 'Dream',
    packageRange: '₹4.5 - 6.5 LPA',
    industry: 'Global Tech & Strategy Consulting',
    hiringRoles: ['Associate Software Engineer (ASE)', 'Advance ASE'],
    eligibility: { minCgpa: 6.5, maxBacklogs: 1, allowedBranches: ['CSE', 'IT', 'ECE', 'EEE'] },
    recruitmentProcess: [
      { roundNumber: 1, roundName: 'Round 1: Cognitive Assessment & Technical MCQs', duration: '90 mins' },
      { roundNumber: 2, roundName: 'Round 2: Coding Assessment (2 Questions)', duration: '45 mins' },
      { roundNumber: 3, roundName: 'Round 3: Communication Assessment (Automated AI)', duration: '20 mins' },
      { roundNumber: 4, roundName: 'Round 4: Technical & HR Virtual Interview', duration: '30 mins' },
    ],
    overview: 'Accenture provides consulting, digital, and technology operations worldwide.',
    website: 'https://www.accenture.com',
    pastHiresCount: 54,
  },
];

exports.getAllCompanies = async (req, res) => {
  try {
    if (getIsConnected()) {
      const dbComps = await Company.find();
      if (dbComps.length > 0) return res.json({ success: true, count: dbComps.length, data: dbComps });
    }
    return res.json({ success: true, count: inMemoryCompanies.length, data: inMemoryCompanies });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

exports.getCompanyById = async (req, res) => {
  const { id } = req.params;
  const comp = inMemoryCompanies.find((c) => c.companyId === id);
  if (!comp) return res.status(404).json({ success: false, message: 'Company not found' });
  return res.json({ success: true, data: comp });
};
