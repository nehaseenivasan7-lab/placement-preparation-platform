const express = require('express');
const cors = require('cors');
require('dotenv').config();

const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const driveRoutes = require('./routes/driveRoutes');
const companyRoutes = require('./routes/companyRoutes');
const practiceRoutes = require('./routes/practiceRoutes');

const app = express();
// Default to 5000 if not specified, avoiding clash with cloud preview port 8080/3000
const PORT = process.env.BACKEND_PORT || (process.env.PORT && process.env.PORT !== '8080' && process.env.PORT !== '3000' ? process.env.PORT : 5000);

// Initialize connection to MongoDB Atlas / Compass
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health Check API with MongoDB Atlas status
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    institution: 'National Engineering College, Kovilpatti',
    service: 'Placement Preparation Platform API',
    database: {
      status: connectDB.getIsConnected() ? 'Connected' : 'Connecting / Ready',
      provider: 'MongoDB Atlas & Compass',
      collections: ['users', 'drives', 'companies', 'practices', 'applications'],
    },
    timestamp: new Date().toISOString(),
  });
});

// Mount Protected and Public Routes
app.use('/api/auth', authRoutes);
app.use('/api/drives', driveRoutes);
app.use('/api/companies', companyRoutes);
app.use('/api/practice', practiceRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Backend Error]:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
  });
});

if (process.env.NODE_ENV !== 'test') {
  const server = app.listen(PORT, () => {
    console.log(`[Backend Server]: Running on port ${PORT}`);
    console.log(`[MongoDB Connection URI]: ${connectDB.MONGO_URI ? connectDB.MONGO_URI.replace(/:([^:@]{4,})@/, ':****@') : 'configured'}`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      const nextPort = Number(PORT) + 1;
      console.log(`[Notice]: Port ${PORT} busy, retrying on fallback port ${nextPort}...`);
      app.listen(nextPort, () => {
        console.log(`[Backend Server]: Running on fallback port ${nextPort}`);
      });
    } else {
      console.error('[Server Error]:', err.message);
    }
  });
}

module.exports = app;
