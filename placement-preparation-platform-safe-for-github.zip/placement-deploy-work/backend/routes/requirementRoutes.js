const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

let requirements = [
  {
    id: 'req_zoho_mts_2026',
    visitorId: 'usr_visitor_01',
    visitorName: 'Venkatesh Raman',
    organizationName: 'Zoho Corporation',
    jobRole: 'Member Technical Staff (MTS)',
    jobDescription: 'Design, architect, and build scalable web applications and cloud software systems.',
    requiredSkills: ['C', 'Java', 'Data Structures', 'OOPs'],
    degree: 'B.E. / B.Tech',
    branch: ['Computer Science & Engineering', 'Information Technology'],
    graduationYear: 2027,
    minCgpa: 7.5,
    maxBacklogs: 0,
    vacancies: 25,
    workLocation: 'Chennai & Tenkasi',
    salaryPackage: '8.5 - 12.0 LPA',
    employmentType: 'Full-Time',
    status: 'APPROVED',
    recruitmentRounds: [
      { roundNumber: 1, roundName: 'Basic Problem Solving', mode: 'Online' },
      { roundNumber: 2, roundName: 'Advanced Programming', mode: 'Online' },
      { roundNumber: 3, roundName: 'Technical Interview', mode: 'Offline' },
      { roundNumber: 4, roundName: 'HR Round', mode: 'Offline' },
    ],
  },
];

// GET: All requirements
router.get('/', (req, res) => {
  res.json({ success: true, requirements });
});

// POST: Create requirement
router.post('/', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const newReq = {
    id: `req_${Date.now()}`,
    visitorId: req.user.id,
    visitorName: req.user.name,
    status: 'SUBMITTED',
    createdAt: new Date().toISOString(),
    ...req.body,
  };
  requirements.unshift(newReq);
  res.status(201).json({ success: true, requirement: newReq });
});

// PATCH: Approve / Reject requirement (Placement Admin)
router.patch('/:id/status', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const { status } = req.body;
  const target = requirements.find((r) => r.id === req.params.id);
  if (!target) return res.status(404).json({ success: false, message: 'Requirement not found' });
  target.status = status;
  res.json({ success: true, message: `Requirement status updated to ${status}`, requirement: target });
});

module.exports = router;
