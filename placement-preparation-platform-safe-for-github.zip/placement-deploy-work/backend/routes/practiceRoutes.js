const express = require('express');
const router = express.Router();
const practiceController = require('../controllers/practiceController');

router.get('/', practiceController.getAllQuestions);
router.get('/sections', practiceController.getSections);

module.exports = router;
