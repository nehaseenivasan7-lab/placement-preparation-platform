const express = require('express');
const router = express.Router();
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

let organizations = [
  {
    id: 'org_zoho',
    name: 'Zoho Corporation',
    industry: 'Software & Cloud SaaS',
    website: 'https://www.zoho.com',
    description: 'Global SaaS enterprise creating workplace productivity, CRM, and cloud engineering solutions.',
    location: 'Chennai & Tenkasi, Tamil Nadu',
    contactPerson: 'Venkatesh Raman',
    contactEmail: 'campus@zohocorp.com',
    contactPhone: '+91 44 6744 7070',
    jobRoles: ['Member Technical Staff (MTS)', 'Quality Analyst', 'Product Designer'],
    status: 'Active',
    totalDrivesConducted: 8,
  },
  {
    id: 'org_tcs',
    name: 'Tata Consultancy Services',
    industry: 'IT Services & Consulting',
    website: 'https://www.tcs.com',
    description: 'Global IT powerhouse offering Prime, Digital, and Ninja technical profiles.',
    location: 'Pan India',
    contactPerson: 'Campus Talent Acquisition',
    contactEmail: 'campus.recruitment@tcs.com',
    contactPhone: '+91 22 6778 9999',
    jobRoles: ['Systems Engineer (Digital)', 'Software Engineer (Prime)', 'Assistant System Engineer'],
    status: 'Active',
    totalDrivesConducted: 12,
  },
];

// GET: All organizations
router.get('/', (req, res) => {
  const { search, status } = req.query;
  let list = [...organizations];
  if (search) {
    list = list.filter((o) => o.name.toLowerCase().includes(search.toLowerCase()));
  }
  if (status && status !== 'All') {
    list = list.filter((o) => o.status === status);
  }
  res.json({ success: true, organizations: list });
});

// POST: Add Organization
router.post('/', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const newOrg = {
    id: `org_${Date.now()}`,
    ...req.body,
    status: 'Active',
    totalDrivesConducted: 0,
    createdAt: new Date().toISOString(),
  };
  organizations.unshift(newOrg);
  res.status(201).json({ success: true, organization: newOrg });
});

// PUT: Edit / Archive Organization
router.put('/:id', authenticateToken, authorizeRoles('admin'), (req, res) => {
  const idx = organizations.findIndex((o) => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Organization not found' });
  organizations[idx] = { ...organizations[idx], ...req.body };
  res.json({ success: true, organization: organizations[idx] });
});

module.exports = router;
