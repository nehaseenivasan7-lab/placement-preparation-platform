const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authenticateToken } = require('../middleware/authMiddleware');

// POST /api/auth/login - Universal Login (Username + Password)
router.post('/login', authController.login);

// POST /api/auth/google - Real-Time Google OAuth Authentication
router.post('/google', authController.googleLogin);

// GET /api/auth/me - Current User Info
router.get('/me', authenticateToken, authController.getMe);

module.exports = router;
