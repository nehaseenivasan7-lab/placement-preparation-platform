const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/authMiddleware');

// POST: /api/eligibility/check
// Automatic evaluation of student criteria against company requirement or drive
router.post('/check', (req, res) => {
  const { student, criteria } = req.body;

  if (!student || !criteria) {
    return res.status(400).json({ success: false, message: 'Student and criteria data are required.' });
  }

  const reasons = [];

  // 1. Batch / Graduation Year Check
  if (criteria.graduationYear && student.graduationYear && student.graduationYear !== criteria.graduationYear) {
    reasons.push(`Batch mismatch: Target is ${criteria.graduationYear}, student batch is ${student.graduationYear}`);
  }

  // 2. CGPA Cutoff Check
  const studentCgpa = Number(student.cgpa) || 8.0;
  if (criteria.minCgpa && studentCgpa < Number(criteria.minCgpa)) {
    reasons.push(`CGPA ${studentCgpa} is below minimum cutoff of ${criteria.minCgpa}`);
  }

  // 3. Backlog Criteria Check
  const backlogs = Number(student.backlogs) || 0;
  if (criteria.maxBacklogs !== undefined && backlogs > Number(criteria.maxBacklogs)) {
    reasons.push(`Backlogs count (${backlogs}) exceeds maximum allowed (${criteria.maxBacklogs})`);
  }

  // 4. Branch / Department Check
  if (criteria.branches && criteria.branches.length > 0 && student.department) {
    const match = criteria.branches.some(
      (b) => b.toLowerCase().includes(student.department.toLowerCase()) || student.department.toLowerCase().includes(b.toLowerCase())
    );
    if (!match) {
      reasons.push(`Department ${student.department} is not in eligible branches list`);
    }
  }

  const eligible = reasons.length === 0;

  res.json({
    success: true,
    eligible,
    reasons,
    summary: eligible ? 'Student is eligible for drive registration' : 'Student does not meet eligibility cutoffs',
  });
});

module.exports = router;
