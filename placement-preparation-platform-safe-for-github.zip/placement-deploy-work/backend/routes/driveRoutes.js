const express = require('express');
const router = express.Router();
const driveController = require('../controllers/driveController');
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

router.get('/', driveController.getAllDrives);
router.get('/:id', driveController.getDriveById);
router.post('/', authenticateToken, authorizeRoles('admin'), driveController.createDrive);
router.post('/:driveId/apply', authenticateToken, driveController.applyToDrive);

module.exports = router;
