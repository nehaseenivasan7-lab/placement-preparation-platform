const mongoose = require('mongoose');

const driveSchema = new mongoose.Schema(
  {
    driveId: {
      type: String,
      required: true,
      unique: true,
    },
    companyName: {
      type: String,
      required: true,
    },
    jobRole: {
      type: String,
      required: true,
    },
    packageCtc: {
      type: String,
      required: true,
    },
    driveDate: {
      type: String,
      required: true,
    },
    registrationDeadline: {
      type: String,
      required: true,
    },
    minCgpa: {
      type: Number,
      default: 7.0,
    },
    maxBacklogs: {
      type: Number,
      default: 0,
    },
    eligibleDepartments: {
      type: [String],
      default: ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'],
    },
    rounds: {
      type: [String],
      default: ['Online Assessment', 'Technical Round', 'HR Interview'],
    },
    status: {
      type: String,
      enum: ['UPCOMING', 'ACTIVE', 'IN_PROGRESS', 'COMPLETED'],
      default: 'UPCOMING',
    },
    totalRegistered: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.models.Drive || mongoose.model('Drive', driveSchema);
