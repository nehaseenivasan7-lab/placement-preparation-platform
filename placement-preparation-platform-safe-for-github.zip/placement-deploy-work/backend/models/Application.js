const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema(
  {
    applicationId: {
      type: String,
      required: true,
      unique: true,
    },
    driveId: {
      type: String,
      required: true,
    },
    companyName: {
      type: String,
      required: true,
    },
    userId: {
      type: String,
      required: true,
    },
    rollNumber: String,
    studentName: String,
    email: String,
    cgpa: Number,
    department: String,
    status: {
      type: String,
      enum: ['APPLIED', 'ELIGIBLE', 'SHORTLISTED', 'REJECTED', 'SELECTED'],
      default: 'APPLIED',
    },
    appliedAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.models.Application || mongoose.model('Application', applicationSchema);
