const mongoose = require('mongoose');

const companySchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
      unique: true,
    },
    name: {
      type: String,
      required: true,
    },
    tier: {
      type: String,
      enum: ['Super Dream', 'Dream', 'Core', 'Mass / Service'],
      default: 'Dream',
    },
    packageRange: {
      type: String,
      required: true,
    },
    industry: {
      type: String,
      required: true,
    },
    hiringRoles: [String],
    eligibility: {
      minCgpa: Number,
      maxBacklogs: Number,
      allowedBranches: [String],
    },
    recruitmentProcess: [
      {
        roundNumber: Number,
        roundName: String,
        description: String,
        duration: String,
      },
    ],
    overview: String,
    website: String,
    pastHiresCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.models.Company || mongoose.model('Company', companySchema);
