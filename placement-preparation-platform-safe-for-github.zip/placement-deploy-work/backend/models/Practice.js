const mongoose = require('mongoose');

const practiceSchema = new mongoose.Schema(
  {
    questionId: {
      type: String,
      required: true,
      unique: true,
    },
    section: {
      type: String,
      enum: ['aptitude', 'coding', 'technical', 'verbal'],
      required: true,
    },
    topic: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    difficulty: {
      type: String,
      enum: ['Easy', 'Medium', 'Hard'],
      default: 'Easy',
    },
    problemStatement: String,
    options: [String],
    correctAnswer: String,
    explanation: String,
    testCases: [
      {
        input: String,
        expectedOutput: String,
      },
    ],
    sampleSolution: String,
    tags: [String],
    targetRole: {
      type: String,
      enum: ['junior', 'pre_final', 'all'],
      default: 'all',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.models.Practice || mongoose.model('Practice', practiceSchema);
