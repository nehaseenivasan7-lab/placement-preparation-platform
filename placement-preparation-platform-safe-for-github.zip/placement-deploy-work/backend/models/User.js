const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: ['junior', 'pre_final', 'senior', 'admin'],
      required: true,
    },
    rollNumber: {
      type: String,
      default: '',
    },
    department: {
      type: String,
      default: 'Computer Science & Engineering',
    },
    college: {
      type: String,
      default: 'National Engineering College, Kovilpatti',
    },
    graduationYear: {
      type: Number,
      default: 2026,
    },
    currentSemester: {
      type: Number,
      default: 5,
    },
    cgpa: {
      type: Number,
      default: 8.5,
    },
    backlogs: {
      type: Number,
      default: 0,
    },
    avatarUrl: {
      type: String,
      default: '',
    },
    skills: {
      type: [String],
      default: ['Data Structures', 'C++', 'Java', 'SQL'],
    },
    placementStatus: {
      type: String,
      enum: ['Not Placed', 'Placed', 'Pursuing Higher Studies', 'Faculty/Staff'],
      default: 'Not Placed',
    },
    currentCompany: {
      type: String,
      default: '',
    },
    lastLoginAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
