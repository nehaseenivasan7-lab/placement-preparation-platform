import React from 'react';
import { AdminWorkspaceView } from '../components/views/AdminWorkspaceView';

/**
 * System Administrator Dashboard in JSX
 * Overall user administration, announcements, audit logs, and system moderation
 */
export const AdminDashboard = () => {
  return (
    <div className="space-y-4">
      <AdminWorkspaceView />
    </div>
  );
};
export default AdminDashboard;
