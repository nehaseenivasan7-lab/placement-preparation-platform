import React from 'react';
import { HubView } from '../components/views/HubView';

/**
 * Pre-Final Year Intensive Placement Preparation Dashboard in JSX
 * Company Playbook, Coding Arena, Mock GD, Aptitude tests, and Day-1 Readiness Dial
 */
export const PreFinalDashboard = ({ onOpenModule, onOpenSettings }) => {
  return (
    <div className="space-y-4">
      <HubView onOpenModule={onOpenModule} onOpenSettings={onOpenSettings} />
    </div>
  );
};
export default PreFinalDashboard;
