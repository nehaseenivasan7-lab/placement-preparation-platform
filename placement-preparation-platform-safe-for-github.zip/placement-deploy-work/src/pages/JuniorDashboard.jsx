import React from 'react';
import { JuniorWorkspaceView } from '../components/views/JuniorWorkspaceView';

/**
 * Junior (2nd Year) Preparation Dashboard in JSX
 * Interactive coding playground, speed aptitude, Git & SQL simulations, and mentorship activities
 */
export const JuniorDashboard = ({ onOpenModule, onOpenSettings }) => {
  return (
    <div className="space-y-4">
      <JuniorWorkspaceView onOpenModule={onOpenModule} />
    </div>
  );
};
export default JuniorDashboard;
