import React from 'react';
import { SeniorWorkspaceView } from '../components/views/SeniorWorkspaceView';

/**
 * Placed Senior Mentor Dashboard in JSX
 * Senior Hub, Doubt Clearing, Specialization guidance, and Mock Interview conducting
 */
export const SeniorDashboard = ({ onOpenModule }) => {
  return (
    <div className="space-y-4">
      <SeniorWorkspaceView onOpenModule={onOpenModule} />
    </div>
  );
};
export default SeniorDashboard;
