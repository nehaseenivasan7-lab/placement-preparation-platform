import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { ArrowRight, ShieldCheck, Camera, ExternalLink } from 'lucide-react';
import { getEffectiveHeroImage } from '../assets/collegeImages';

/**
 * Official College Home Page in pure JSX
 * Features Full-View NEC Image, Accreditations, and Workspace Entry
 */
export const HomePage = ({ onEnterWorkspace }) => {
  const { user, isAuthenticated } = useAuth();
  const { t } = useTheme();
  const [isFullViewOpen, setIsFullViewOpen] = useState(false);
  const heroImage = getEffectiveHeroImage();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Academic Accreditation Bar */}
      <div className="bg-blue-950 text-amber-300 text-[11px] font-semibold px-4 py-1.5 flex flex-wrap items-center justify-between border-b border-blue-900/60">
        <div className="flex items-center gap-3">
          <span className="bg-amber-400 text-blue-950 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider">
            Autonomous
          </span>
          <span>Affiliated to Anna University, Chennai · Accredited by NAAC 'A+' Grade & NBA</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-slate-300">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>DST - FIST Sponsored Institution</span>
          </span>
          <span>Estd. 1984 · K.R. Nagar, Kovilpatti</span>
        </div>
      </div>

      {/* Main Institution Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-blue-900 via-blue-800 to-indigo-950 text-white font-black flex items-center justify-center text-sm shadow-md">
              <span className="text-amber-300 font-extrabold">NEC</span>
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-none uppercase">
                National Engineering College
              </h1>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Training & Placement Cell · Kovilpatti
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && user && (
              <div className="hidden sm:block text-right mr-1">
                <p className="text-xs font-bold text-slate-800">{user.name}</p>
                <p className="text-[10px] text-emerald-600 font-semibold">● Active Session</p>
              </div>
            )}
            <button
              onClick={onEnterWorkspace}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer"
            >
              <span>{t('enterWorkspace')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section with Full View NEC Monument Image */}
      <section className="bg-slate-950 text-white pt-6 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-4">
          <div>
            <h2 className="text-xl sm:text-3xl font-black text-white">
              Placement Preparation & Career Acceleration Ecosystem
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              National Engineering College · Click the campus image below to access your role workspace.
            </p>
          </div>

          {/* Full Rectangle Interactive Hero Image */}
          <div
            onClick={onEnterWorkspace}
            className="group relative w-full rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl border border-slate-800 bg-slate-900 cursor-pointer transition-all duration-300 hover:border-slate-600"
          >
            <div className="relative w-full aspect-[16/9] sm:aspect-[16/8] md:aspect-[21/9] max-h-[540px] bg-slate-950 flex items-center justify-center">
              <img
                src={heroImage}
                alt="National Engineering College Campus Entrance Monument"
                className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-[1.01]"
              />

              <div className="absolute top-3 sm:top-4 inset-x-3 sm:inset-x-5 flex items-center justify-between z-10">
                <span className="bg-black/60 text-white text-[11px] font-semibold px-3 py-1 rounded-lg backdrop-blur-md border border-white/10">
                  NEC Front Entrance Monument
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsFullViewOpen(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-black/60 hover:bg-black/80 text-amber-300 text-xs font-bold flex items-center gap-1.5 border border-amber-300/30 backdrop-blur-md transition cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Full View</span>
                </button>
              </div>

              <div className="absolute bottom-3 sm:bottom-4 inset-x-3 sm:inset-x-5 flex items-center justify-between z-10 text-xs">
                <div>
                  <p className="font-bold text-white drop-shadow-sm text-sm sm:text-base">
                    National Engineering College
                  </p>
                  <p className="text-slate-300 text-[11px]">K.R. Nagar, Kovilpatti · Accredited NAAC 'A+' & NBA</p>
                </div>
                <span className="text-[11px] font-semibold text-slate-200 bg-black/50 px-2.5 py-1 rounded-lg border border-white/15 backdrop-blur-xs flex items-center gap-1 group-hover:text-white transition">
                  <span>Enter Workspace</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Full View Lightbox Modal */}
      {isFullViewOpen && (
        <div
          onClick={() => setIsFullViewOpen(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-5xl w-full bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-700"
          >
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between border-b border-slate-800">
              <span className="font-bold text-sm">NEC Campus Monument — Full View</span>
              <button onClick={() => setIsFullViewOpen(false)} className="p-1 rounded bg-white/10 text-white">✕</button>
            </div>
            <div className="p-2 bg-black flex items-center justify-center">
              <img src={heroImage} alt="Full View" className="max-h-[75vh] w-auto max-w-full object-contain rounded-xl" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default HomePage;
