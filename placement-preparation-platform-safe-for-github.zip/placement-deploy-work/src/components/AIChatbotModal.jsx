import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles, User as UserIcon, RefreshCw, Bot, Minimize2 } from 'lucide-react';
import { askPlacementAssistant } from '../services/gemini';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
export const AIChatbotModal = ({ isOpen, onClose }) => {
    const { user } = useAuth();
    const { language, t } = useTheme();
    const getInitialGreeting = () => {
        if (language === 'ta') {
            return `வணக்கம் ${user?.name || ''}! நான் தேசிய பொறியியல் கல்லூரியின் AI வேலைவாய்ப்பு வழிகாட்டி. உங்கள் வளாக நேர்காணல் மற்றும் வேலைவாய்ப்பு பயிற்சிக்கான சந்தேகங்களை என்னிடம் கேளுங்கள்.\n\nநீங்கள் கேட்கக்கூடியவை:\n• Zoho, TCS நேர்காணல் வினாக்கள் & குறிப்புகள்\n• குழு விவாதம் (GD) வழிகாட்டுதல்\n• ரெஸ்யூம் (Resume) சரிபார்த்தல் & STAR முறை`;
        }
        if (language === 'hi') {
            return `नमस्ते ${user?.name || ''}! मैं नेशनल इंजीनियरिंग कॉलेज (NEC) का एआई प्लेसमेंट मेंटर हूँ। अपनी ड्रीम कंपनी क्रैक करने के लिए आप मुझसे कोई भी सवाल पूछ सकते हैं।\n\nआप पूछ सकते हैं:\n• जोहो और टीसीएस कोडिंग राउंड के टिप्स\n• ग्रुप डिस्कशन (जीडी) के वाक्यांश और तरीके\n• 'टेल मी अबाउट योरसेल्फ' का प्रभावशाली उत्तर`;
        }
        return `Hello ${user?.name || 'there'}! I am your AI Placement Preparation Mentor at National Engineering College. How can I help you crack your dream company today?\n\nYou can ask me about:\n• Zoho coding rounds & pointer questions\n• TCS NQT syllabus & speed math shortcuts\n• Resume optimization using STAR format\n• Answering "Tell me about yourself"\n• Group Discussion phrases and etiquette`;
    };
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const endRef = useRef(null);
    useEffect(() => {
        if (isOpen && messages.length === 0) {
            setMessages([
                {
                    role: 'model',
                    text: getInitialGreeting(),
                },
            ]);
        }
    }, [isOpen, language]);
    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, loading]);
    if (!isOpen)
        return null;
    const handleSend = async (textToSend) => {
        const query = textToSend || input.trim();
        if (!query || loading)
            return;
        const newMessages = [...messages, { role: 'user', text: query }];
        setMessages(newMessages);
        setInput('');
        setLoading(true);
        try {
            const reply = await askPlacementAssistant(query, newMessages, user?.role);
            setMessages([...newMessages, { role: 'model', text: reply }]);
        }
        catch (err) {
            setMessages([
                ...newMessages,
                {
                    role: 'model',
                    text: 'I encountered an issue connecting. Please try asking again or refer to the Company Playbook module.',
                },
            ]);
        }
        finally {
            setLoading(false);
        }
    };
    const quickPromptsByLang = {
        en: [
            'How to clear Zoho Round 2 & 3?',
            'TCS Digital test pattern & tips',
            'Tips for Group Discussion round',
            'STAR method for HR interview',
        ],
        ta: [
            'Zoho கோடிங் ரவுண்ட் பாஸ் செய்வது எப்படி?',
            'குழு விவாதம் (GD) முக்கிய குறிப்புகள்',
            'HR நேர்காணல் பதில்கள் STAR முறை',
            'TCS தேர்வு தயாரிப்பு வழிகாட்டி',
        ],
        hi: [
            'जोहो राउंड 2 और 3 कैसे क्रैक करें?',
            'ग्रुप डिस्कशन (जीडी) के बेहतरीन टिप्स',
            'एचआर इंटरव्यू के लिए स्टार मेथड',
            'टीसीएस डिजिटल टेस्ट पैटर्न',
        ],
    };
    const prompts = quickPromptsByLang[language] || quickPromptsByLang.en;
    return (<>
      {/* Mobile backdrop */}
      <div className="fixed inset-0 z-40 bg-slate-950/40 sm:hidden" onClick={onClose}/>

      {/* Floating Chat Container docked in right down side */}
      <div className="fixed bottom-20 right-3 sm:right-6 w-[94vw] sm:w-[440px] h-[580px] max-h-[82vh] bg-white rounded-2xl shadow-2xl border border-slate-300 flex flex-col overflow-hidden z-50 animate-in slide-in-from-bottom-5 duration-200">
        {/* Header */}
        <div className="px-4 py-3 bg-linear-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shadow-xs shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-700/80 border border-blue-400/40 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse"/>
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight flex items-center gap-1.5">
                {t('aiAssistant')}
              </h3>
              <p className="text-[10px] text-blue-200">National Engineering College 24/7 Mentor</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={onClose} title="Close Assistant" className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer">
              <Minimize2 className="w-4 h-4"/>
            </button>
            <button onClick={onClose} title="Close" className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer">
              <X className="w-4 h-4"/>
            </button>
          </div>
        </div>

        {/* Quick prompt suggestions */}
        <div className="p-2 bg-slate-50 border-b border-slate-200 overflow-x-auto flex gap-1.5 scrollbar-none text-[11px] shrink-0">
          {prompts.map((p, idx) => (<button key={idx} onClick={() => handleSend(p)} disabled={loading} className="whitespace-nowrap px-2.5 py-1 rounded-full bg-white border border-slate-200 text-slate-700 hover:border-blue-400 hover:bg-blue-50 transition cursor-pointer font-medium">
              {p}
            </button>))}
        </div>

        {/* Chat message flow */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-slate-50/40">
          {messages.map((m, idx) => {
            const isUser = m.role === 'user';
            return (<div key={idx} className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (<div className="w-7 h-7 rounded-lg bg-blue-900 text-amber-300 flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                    <Bot className="w-4 h-4"/>
                  </div>)}
                <div className={`max-w-[85%] p-3 rounded-2xl whitespace-pre-line leading-relaxed text-xs shadow-2xs ${isUser
                    ? 'bg-blue-600 text-white rounded-tr-none font-medium'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'}`}>
                  {m.text}
                </div>
                {isUser && (<div className="w-7 h-7 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                    <UserIcon className="w-4 h-4"/>
                  </div>)}
              </div>);
        })}

          {loading && (<div className="flex gap-2.5 justify-start items-center text-slate-500 text-xs">
              <div className="w-7 h-7 rounded-lg bg-blue-900 text-amber-300 flex items-center justify-center shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin"/>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-2xl rounded-tl-none text-slate-500 italic">
                NEC Placement AI is analyzing college interview patterns...
              </div>
            </div>)}
          <div ref={endRef}/>
        </div>

        {/* Input box */}
        <form onSubmit={(e) => {
            e.preventDefault();
            handleSend();
        }} className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          <input type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder={language === 'ta'
            ? 'உங்கள் நேர்காணல் அல்லது பயிற்சிக் கேள்வியைக் கேட்கவும்...'
            : language === 'hi'
                ? 'अपना प्लेसमेंट या कोडिंग प्रश्न पूछें...'
                : 'Ask placement questions, coding doubts, HR tips...'} className="flex-1 px-3 py-2 text-xs bg-slate-100 hover:bg-slate-50 focus:bg-white border border-slate-200 focus:border-blue-500 rounded-xl outline-none transition"/>
          <button type="submit" disabled={!input.trim() || loading} className="p-2 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white transition cursor-pointer shadow-xs">
            <Send className="w-4 h-4"/>
          </button>
        </form>
      </div>
    </>);
};
