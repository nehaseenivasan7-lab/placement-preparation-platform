import React from 'react';
import { LayoutDashboard, Building2, BookOpen, FileText, Layers, HelpCircle, Terminal, Flame, Video, Users, UserCheck, MessageSquare, Calendar, BarChart3, Trophy, Clock, Sparkles, ShieldCheck, GraduationCap, ChevronRight, CheckCircle2, TrendingUp, Compass, Briefcase, Cpu, Code2, Award, } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
export const Sidebar = ({ currentTab, activeModule, onSelectTab, onOpenModule, isMobileOpen, setIsMobileOpen, }) => {
    const { user } = useAuth();
    const { t } = useTheme();
    const isJunior = user?.role === 'junior';
    const isSenior = user?.role === 'senior';
    const isAdmin = user?.role === 'admin';
    // Junior 10-Module Foundation Path
    const juniorGroup = [
        { id: 'journey', label: 'Placement Journey', icon: Compass },
        { id: 'careers', label: 'Career Explorer', icon: Briefcase },
        { id: 'companies', label: 'Company Explorer', icon: Building2 },
        { id: 'skills', label: 'Skill Builder', icon: Cpu },
        { id: 'coding_basics', label: 'Coding Basics', icon: Code2 },
        { id: 'aptitude_starter', label: 'Aptitude Starter', icon: Award },
        { id: 'challenges', label: 'Daily Challenges', icon: Flame },
        { id: 'ask_senior', label: 'Ask a Senior', icon: MessageSquare },
        { id: 'progress', label: 'My Learning Progress', icon: BarChart3 },
        { id: 'planner', label: 'Learning Planner', icon: Calendar },
    ];
    // 1. DISCOVER: Company Explorer, Company Playbook, Interview Experiences, Round Resources
    const discoverGroup = [
        { id: 'companyExplorer', key: 'companyExplorer', icon: Building2 },
        { id: 'companyPlaybook', key: 'companyPlaybook', icon: BookOpen },
        { id: 'interviewExperiences', key: 'interviewExperiences', icon: FileText },
        { id: 'roundResources', key: 'roundResources', icon: Layers },
    ];
    // 2. CONNECT: Mock Interview, Mock GD, Mentorship, Peer Circle
    const connectGroup = [
        { id: 'mockInterviews', key: 'mockInterviewsMod', icon: Video },
        { id: 'mockGD', key: 'mockGD', icon: Users },
        { id: 'mentorship', key: 'mentorship', icon: UserCheck },
        { id: 'peerCircle', key: 'peerCircle', icon: MessageSquare },
    ];
    // 3. PRACTICE: Question Bank, Practice Studio, Daily Challenges
    const practiceGroup = [
        { id: 'questionBank', key: 'questionBank', icon: HelpCircle },
        { id: 'practiceStudio', key: 'practiceStudio', icon: Terminal },
        { id: 'dailyChallenges', key: 'dailyChallenges', icon: Flame },
    ];
    // 4. TRACK: Performance Analytics, Leaderboard, Upcoming Sessions, Feedback Journal
    const trackGroup = [
        { id: 'performanceAnalytics', key: 'performanceAnalytics', icon: BarChart3 },
        { id: 'leaderboard', key: 'leaderboard', icon: Trophy },
        { id: 'upcomingSessions', key: 'upcomingSessions', icon: Clock },
        { id: 'feedbackJournal', key: 'feedbackJournal', icon: Sparkles },
    ];
    const handleModuleClick = (modId) => {
        onOpenModule(modId);
        setIsMobileOpen(false);
    };
    const handleNavClick = (tabId) => {
        onSelectTab(tabId);
        setIsMobileOpen(false);
    };
    return (<>
      {/* Mobile backdrop */}
      {isMobileOpen && (<div className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden" onClick={() => setIsMobileOpen(false)}/>)}

      <aside className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-200 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        {/* College Header in Sidebar */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-linear-to-tr from-amber-500 to-amber-300 flex items-center justify-center font-bold text-slate-950 shadow-sm shrink-0">
              <GraduationCap className="w-5 h-5 text-slate-950"/>
            </div>
            <div>
              <p className="text-xs uppercase font-extrabold tracking-wider text-amber-400">NEC Placement</p>
              <p className="text-[11px] text-slate-400 font-medium">Preparation Platform</p>
            </div>
          </div>
          <button onClick={() => setIsMobileOpen(false)} className="lg:hidden text-slate-400 hover:text-white text-xs p-1">
            ✕
          </button>
        </div>

        {/* Scrollable Navigation */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4 scrollbar-thin">
          {/* Primary View: Workspace */}
          <div className="space-y-1">
            <button onClick={() => handleNavClick('workspace')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${currentTab === 'workspace' && !activeModule
            ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
            : 'text-slate-300 hover:bg-slate-800 hover:text-white'}`}>
              <LayoutDashboard className={`w-4 h-4 shrink-0 ${currentTab === 'workspace' && !activeModule ? 'text-white' : 'text-slate-400'}`}/>
              <span className="flex-1 leading-tight">
                {user?.role === 'senior'
            ? 'Senior Mentor Hub'
            : t('workspace')}
              </span>
              {currentTab === 'workspace' && !activeModule && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
            </button>

            {isAdmin && (<button onClick={() => handleNavClick('admin')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer text-left ${currentTab === 'admin' && !activeModule
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-purple-300 hover:bg-slate-800 hover:text-white'}`}>
                <ShieldCheck className={`w-4 h-4 shrink-0 ${currentTab === 'admin' && !activeModule ? 'text-white' : 'text-purple-400'}`}/>
                <span className="flex-1 leading-tight">{t('adminCenter')}</span>
                {currentTab === 'admin' && !activeModule && <ChevronRight className="w-3.5 h-3.5 text-purple-200 shrink-0"/>}
              </button>)}
          </div>

          {/* Conditional Navigation based on Role */}
          {isJunior ? (<div className="pt-2 border-t border-slate-800/80">
              <div className="px-3 mb-2 flex items-center justify-between">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-400">
                  {t('journey', 'Junior Placement Journey')}
                </span>
                <span className="text-[9px] bg-blue-900/80 text-blue-200 px-1.5 py-0.2 rounded font-bold">
                  {t('2nd Year', '2nd Year')}
                </span>
              </div>
              <div className="space-y-1">
                {juniorGroup.map((item) => {
                const Icon = item.icon;
                const isSelected = activeModule === item.id;
                return (<button key={item.id} onClick={() => handleModuleClick(item.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer text-left ${isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}`}>
                      <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-blue-400'}`}/>
                      <span className="truncate flex-1">{t(item.id, item.label)}</span>
                      {isSelected && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
                    </button>);
            })}
              </div>
            </div>) : (<>
              {/* 1. DISCOVER */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="px-3 mb-1.5 flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-400/90">
                    {t('discover')}
                  </span>
                </div>
                <div className="space-y-1">
                  {discoverGroup.map((item) => {
                const Icon = item.icon;
                const isSelected = activeModule === item.id;
                return (<button key={item.id} onClick={() => handleModuleClick(item.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer text-left ${isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}`}>
                        <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`}/>
                        <span className="truncate flex-1">{t(item.key)}</span>
                        {isSelected && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
                      </button>);
            })}
                </div>
              </div>

              {/* 2. CONNECT */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="px-3 mb-1.5 flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-400">
                    {t('connect')}
                  </span>
                </div>
                <div className="space-y-1">
                  {connectGroup.map((item) => {
                const Icon = item.icon;
                const isSelected = activeModule === item.id;
                return (<button key={item.id} onClick={() => handleModuleClick(item.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer text-left ${isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}`}>
                        <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`}/>
                        <span className="truncate flex-1">{t(item.key)}</span>
                        {isSelected && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
                      </button>);
            })}
                </div>
              </div>

              {/* 3. PRACTICE */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="px-3 mb-1.5 flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400">
                    {t('practice')}
                  </span>
                </div>
                <div className="space-y-1">
                  {practiceGroup.map((item) => {
                const Icon = item.icon;
                const isSelected = activeModule === item.id;
                return (<button key={item.id} onClick={() => handleModuleClick(item.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer text-left ${isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}`}>
                        <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`}/>
                        <span className="truncate flex-1">{t(item.key)}</span>
                        {isSelected && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
                      </button>);
            })}
                </div>
              </div>

              {/* 4. TRACK */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="px-3 mb-1.5 flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-400">
                    {t('track')}
                  </span>
                </div>
                <div className="space-y-1">
                  {trackGroup.map((item) => {
                const Icon = item.icon;
                const isSelected = activeModule === item.id;
                return (<button key={item.id} onClick={() => handleModuleClick(item.id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer text-left ${isSelected
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}`}>
                        <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`}/>
                        <span className="truncate flex-1">{t(item.key)}</span>
                        {isSelected && <ChevronRight className="w-3.5 h-3.5 text-blue-200 shrink-0"/>}
                      </button>);
            })}
                </div>
              </div>
            </>)}

          {/* FINAL: READINESS DASHBOARD */}
          <div className="pt-2 border-t border-slate-800">
            <button onClick={() => handleNavClick('readinessDashboard')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer text-left ${currentTab === 'readinessDashboard' && !activeModule
            ? 'bg-linear-to-r from-emerald-600 to-teal-600 text-white shadow-md'
            : 'text-emerald-300 hover:bg-slate-800 hover:text-emerald-200'}`}>
              <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0"/>
              <span className="flex-1 leading-tight">{t('readinessDashboard')}</span>
              {currentTab === 'readinessDashboard' && !activeModule && (<CheckCircle2 className="w-3.5 h-3.5 text-emerald-200 shrink-0"/>)}
            </button>
          </div>

          {/* Senior Mentor Specialization Badge if user is senior */}
          {isSenior && (<div className="p-3 rounded-xl bg-slate-800/90 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold mb-1">
                <Sparkles className="w-3.5 h-3.5"/>
                <span>Mentor Specialization</span>
              </div>
              <p className="text-slate-200 font-semibold text-[11px] truncate">{user?.specialization}</p>
              <p className="text-[10px] text-slate-400 mt-0.5 font-mono">ID: {user?.seniorId}</p>
            </div>)}
        </div>

        {/* User Card at Bottom */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-blue-900/60 border border-blue-700 flex items-center justify-center text-xs font-bold text-blue-300 shrink-0">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="truncate flex-1">
              <p className="text-xs font-bold text-white truncate">{user?.name}</p>
              <p className="text-[10px] text-amber-400/90 font-medium truncate capitalize">
                {user?.role === 'junior'
            ? t('junior', 'Junior · 2nd Year')
            : user?.role === 'pre_final'
                ? t('pre_final', 'Pre-Final Year')
                : user?.role === 'senior'
                    ? t('senior', `Senior · ${user.seniorId || 'Mentor'}`)
                    : t('admin', 'Placement Admin')}
              </p>
            </div>
          </div>
        </div>
      </aside>
    </>);
};
