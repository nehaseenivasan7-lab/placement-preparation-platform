import React, { useState, useEffect } from 'react';
import { Award, Users, MessageSquare, Video, BookOpen, HelpCircle, Medal, } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
export const SeniorWorkspaceView = ({ onOpenModule }) => {
    const { user } = useAuth();
    const [contributions, setContributions] = useState(null);
    const [doubts, setDoubts] = useState([]);
    const [replyInputMap, setReplyInputMap] = useState({});
    const [activeTab, setActiveTab] = useState('overview');
    useEffect(() => {
        if (user?.seniorId) {
            setContributions(storageService.getSeniorContributions(user.seniorId));
            setDoubts(storageService.getDoubts());
        }
    }, [user]);
    if (!user || user.role !== 'senior')
        return null;
    const seniorId = user.seniorId || 'SEN001';
    const specialization = user.specialization || 'Company Explorer';
    const myDoubts = doubts.filter((d) => d.mentorId === user.id || d.specializationTarget === specialization);
    const mockSessions = storageService.getMockInterviews().filter((m) => m.mentorId === user.id);
    const handleReplySubmit = (doubtId) => {
        const text = replyInputMap[doubtId];
        if (!text)
            return;
        storageService.replyDoubt(doubtId, text);
        setDoubts(storageService.getDoubts());
        setReplyInputMap({ ...replyInputMap, [doubtId]: '' });
        if (user.seniorId) {
            const current = storageService.getSeniorContributions(user.seniorId);
            storageService.updateSeniorContribution(user.seniorId, {
                doubtsResolved: current.doubtsResolved + 1,
            });
            setContributions(storageService.getSeniorContributions(user.seniorId));
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner: Clear "What is my role in this platform?" */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-blue-950 via-slate-900 to-indigo-950 text-white shadow-md space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300 bg-amber-400/10 px-2.5 py-0.5 rounded-full border border-amber-400/30">
                Specialized Senior Mentor Ecosystem
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-950 font-bold font-mono">
                {seniorId}
              </span>
            </div>
            <h2 className="text-2xl font-black tracking-tight">{user.name}’s Mentor Workspace</h2>
            <p className="text-xs text-blue-200">
              Placed at: <strong className="text-white">{user.currentCompany || 'Campus Recruiter'}</strong> • {user.jobRole || 'Engineer'}
            </p>
          </div>

          {/* Specialization Badge */}
          <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-xs">
            <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider block mb-0.5">
              Primary Specialization
            </span>
            <p className="font-extrabold text-sm text-white">{specialization}</p>
            <p className="text-[10px] text-blue-200 mt-0.5 font-medium">Domain Responsibility Active</p>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex gap-2 pt-2 border-t border-slate-800 text-xs overflow-x-auto">
          {[
            { id: 'overview', label: 'Mentor Overview & Badges' },
            { id: 'doubts', label: `Student Doubts Inbox (${myDoubts.filter((d) => d.status === 'Open').length} Open)` },
            { id: 'sessions', label: `My Scheduled Sessions (${mockSessions.length})` },
            { id: 'contributions', label: 'Contribution Analytics' },
        ].map((tab) => (<button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`px-3.5 py-1.5 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${activeTab === tab.id
                ? 'bg-amber-400 text-blue-950 shadow-xs'
                : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10'}`}>
              {tab.label}
            </button>))}
        </div>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (<div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Students Guided</span>
              <p className="text-2xl font-black text-slate-900">{contributions?.studentsGuided || 18}</p>
              <p className="text-[11px] text-slate-500 font-medium">1-on-1 mentorship interactions</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Mock Sessions Conducted</span>
              <p className="text-2xl font-black text-blue-900">{contributions?.mockInterviewsConducted || 6}</p>
              <p className="text-[11px] text-slate-500 font-medium">Live interviews evaluated</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Questions Contributed</span>
              <p className="text-2xl font-black text-emerald-700">{contributions?.questionsAdded || 12}</p>
              <p className="text-[11px] text-slate-500 font-medium">Added to Question Bank</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Doubts Resolved</span>
              <p className="text-2xl font-black text-amber-600">{contributions?.doubtsResolved || 15}</p>
              <p className="text-[11px] text-slate-500 font-medium">Student queries answered</p>
            </div>
          </div>

          {/* Mentor Recognition & Badges */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500"/>
              <h3 className="font-bold text-slate-900 text-sm">Official Mentor Recognition & Badges</h3>
            </div>
            <p className="text-slate-500 text-[11px]">
              Earned based on verified contributions to National Engineering College placement records.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {[
                { title: 'Active Mentor', desc: 'Consistent guidance to 2nd & 3rd years', icon: Medal },
                { title: `${specialization} Lead`, desc: 'Curating domain materials', icon: Award },
                { title: 'Interview Evaluator', desc: 'Conducting live technical mocks', icon: Video },
                { title: 'Student Supporter', desc: 'Answering student doubts within 24h', icon: Users },
            ].map((badge, idx) => {
                const Icon = badge.icon;
                return (<div key={idx} className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-200/80 space-y-1">
                    <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs">
                      <Icon className="w-4 h-4 text-amber-600"/>
                      <span>{badge.title}</span>
                    </div>
                    <p className="text-[10px] text-slate-500">{badge.desc}</p>
                  </div>);
            })}
            </div>
          </div>

          {/* Quick Action Contribution shortcuts */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs text-xs space-y-3">
            <h3 className="font-bold text-slate-900 text-sm">Quick Contribution Actions for Your Role</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button onClick={() => onOpenModule('questionBank')} className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 bg-slate-50/50 hover:bg-white text-left transition cursor-pointer space-y-1">
                <HelpCircle className="w-5 h-5 text-blue-700"/>
                <p className="font-bold text-slate-900">Add Questions to Bank</p>
                <p className="text-[11px] text-slate-500">Contribute questions asked in your campus drives.</p>
              </button>

              <button onClick={() => onOpenModule('interviewExperiences')} className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 bg-slate-50/50 hover:bg-white text-left transition cursor-pointer space-y-1">
                <BookOpen className="w-5 h-5 text-amber-600"/>
                <p className="font-bold text-slate-900">Post Interview Experience</p>
                <p className="text-[11px] text-slate-500">Share round breakdown and questions asked.</p>
              </button>

              <button onClick={() => onOpenModule('mockInterviews')} className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 bg-slate-50/50 hover:bg-white text-left transition cursor-pointer space-y-1">
                <Video className="w-5 h-5 text-purple-600"/>
                <p className="font-bold text-slate-900">Review Student Mocks</p>
                <p className="text-[11px] text-slate-500">Evaluate candidates and submit rubrics.</p>
              </button>
            </div>
          </div>
        </div>)}

      {/* DOUBTS INBOX TAB */}
      {activeTab === 'doubts' && (<div className="space-y-4 text-xs">
          <p className="font-bold text-slate-700 uppercase tracking-wider">
            Student Doubts & Questions for {specialization}
          </p>

          {myDoubts.length === 0 ? (<div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-slate-500">
              <MessageSquare className="w-8 h-8 mx-auto text-slate-300 mb-2"/>
              <p className="font-bold text-slate-800">No pending student queries</p>
              <p className="text-slate-400 mt-0.5">Queries asked by juniors will appear here for you to answer.</p>
            </div>) : (myDoubts.map((doubt) => (<div key={doubt.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900">
                      From: {doubt.studentName} ({doubt.studentRole.replace('_', ' ')})
                    </span>
                    <h4 className="font-bold text-sm text-slate-900 mt-1">{doubt.subject}</h4>
                  </div>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${doubt.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                    {doubt.status}
                  </span>
                </div>

                <p className="text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed">
                  "{doubt.message}"
                </p>

                {doubt.reply ? (<div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1">
                    <p className="font-bold text-blue-900">Your Official Response:</p>
                    <p className="text-slate-800 leading-relaxed">{doubt.reply}</p>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Answered: {new Date(doubt.repliedAt || '').toLocaleDateString()}
                    </span>
                  </div>) : (<div className="space-y-2 pt-1">
                    <textarea rows={3} placeholder="Write your advice and answer for this student..." value={replyInputMap[doubt.id] || ''} onChange={(e) => setReplyInputMap({ ...replyInputMap, [doubt.id]: e.target.value })} className="w-full p-3 border rounded-xl bg-slate-50 focus:bg-white outline-none"/>
                    <button onClick={() => handleReplySubmit(doubt.id)} disabled={!replyInputMap[doubt.id]?.trim()} className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl disabled:opacity-50 transition cursor-pointer">
                      Publish Reply to Student
                    </button>
                  </div>)}
              </div>)))}
        </div>)}

      {/* SESSIONS TAB */}
      {activeTab === 'sessions' && (<div className="space-y-4 text-xs">
          <p className="font-bold text-slate-700 uppercase tracking-wider">
            Mock Interviews & Mentorship Calls Assigned to You
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockSessions.map((session) => (<div key={session.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-900">{session.roleOrCompany}</h4>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${session.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                    {session.status}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1 border border-slate-100 text-[11px]">
                  <p>
                    <strong>Student Candidate:</strong> {session.studentName}
                  </p>
                  <p className="font-mono text-slate-800">
                    <strong>Schedule:</strong> {session.scheduledDate} at {session.scheduledTime}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <a href={session.meetingLink} target="_blank" rel="noreferrer" className="text-blue-700 font-bold hover:underline">
                    Join Room →
                  </a>
                  <button onClick={() => onOpenModule('mockInterviews')} className="px-3 py-1 bg-blue-900 text-white font-bold rounded-lg">
                    Evaluate & Score
                  </button>
                </div>
              </div>))}
          </div>
        </div>)}

      {/* CONTRIBUTIONS TAB */}
      {activeTab === 'contributions' && (<div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs text-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">Detailed Senior Contribution Analytics</h3>
          <p className="text-slate-500">
            Audit logs tracking your impact across National Engineering College campus placement preparation drives.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-500">Resources Uploaded</span>
              <p className="text-xl font-black text-slate-900 mt-1">{contributions?.resourcesContributed || 4}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-500">Interview Experiences</span>
              <p className="text-xl font-black text-slate-900 mt-1">{contributions?.interviewExperiencesAdded || 3}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-semibold text-slate-500">Feedback Reports Filed</span>
              <p className="text-xl font-black text-slate-900 mt-1">{contributions?.feedbackSubmitted || 10}</p>
            </div>
          </div>
        </div>)}
    </div>);
};
