import React, { useState, useEffect } from 'react';
import { Compass, Briefcase, Building2, Cpu, Code2, Award, Flame, MessageSquare, BarChart3, Calendar, CheckCircle2, Send, Play, RotateCcw, Clock, Terminal, Database, Plus, Trash2, } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
export const JuniorWorkspaceView = ({ onOpenModule, activeSection, }) => {
    const { user } = useAuth();
    const { t, themeColor, language } = useTheme();
    const [activeTab, setActiveTab] = useState(activeSection || 'coding_basics');
    useEffect(() => {
        if (activeSection) {
            setActiveTab(activeSection);
        }
    }, [activeSection]);
    // ================= 1. CODING PLAYGROUND STATE =================
    const codingProblems = [
        {
            id: 0,
            title: '1. Variables & Logic: Check Even or Odd',
            difficulty: 'Easy',
            description: 'Write a function `isEven(n)` that returns `true` if `n` is even, and `false` if `n` is odd without using `% 2`.',
            hint: 'Bitwise check: `(n & 1) === 0` is even.',
            starterCode: `function isEven(n) {\n  // Your code here\n  return (n & 1) === 0;\n}`,
            testCases: [
                { input: 24, expected: 'true' },
                { input: 17, expected: 'false' },
                { input: 0, expected: 'true' },
            ],
        },
        {
            id: 1,
            title: '2. Loops: FizzBuzz Classic',
            difficulty: 'Easy',
            description: 'Write a function `fizzBuzz(n)` returning "Fizz" if divisible by 3, "Buzz" if divisible by 5, "FizzBuzz" if both, or `n` as string otherwise.',
            hint: 'Check `n % 15 === 0` first.',
            starterCode: `function fizzBuzz(n) {\n  if (n % 15 === 0) return "FizzBuzz";\n  if (n % 3 === 0) return "Fizz";\n  if (n % 5 === 0) return "Buzz";\n  return String(n);\n}`,
            testCases: [
                { input: 15, expected: 'FizzBuzz' },
                { input: 9, expected: 'Fizz' },
                { input: 10, expected: 'Buzz' },
            ],
        },
        {
            id: 2,
            title: '3. Functions: Prime Number Checker',
            difficulty: 'Medium',
            description: 'Write `isPrime(n)` to test if an integer greater than 1 is prime.',
            hint: 'Loop from 2 up to `Math.sqrt(n)`. If `n % i === 0`, return false.',
            starterCode: `function isPrime(n) {\n  if (n <= 1) return false;\n  for (let i = 2; i * i <= n; i++) {\n    if (n % i === 0) return false;\n  }\n  return true;\n}`,
            testCases: [
                { input: 29, expected: 'true' },
                { input: 49, expected: 'false' },
                { input: 2, expected: 'true' },
            ],
        },
        {
            id: 3,
            title: '4. Arrays: Reverse Array In-Place',
            difficulty: 'Easy',
            description: 'Write a function `reverseArray(arr)` that reverses elements.',
            hint: 'Use two pointers: left at 0, right at length - 1.',
            starterCode: `function reverseArray(arr) {\n  return arr.reverse();\n}`,
            testCases: [
                { input: [1, 2, 3, 4], expected: '[4,3,2,1]' },
                { input: [9, 8], expected: '[8,9]' },
            ],
        },
        {
            id: 4,
            title: '5. Strings: Palindrome Validator',
            difficulty: 'Easy',
            description: 'Write `isPalindrome(str)` returning true if string reads same backward, ignoring spaces and case.',
            hint: 'Clean string with regex `/[^a-z0-9]/gi` and check reversed.',
            starterCode: `function isPalindrome(str) {\n  const clean = str.toLowerCase().replace(/[^a-z0-9]/g, '');\n  return clean === clean.split('').reverse().join('');\n}`,
            testCases: [
                { input: 'Racecar', expected: 'true' },
                { input: 'hello', expected: 'false' },
            ],
        },
        {
            id: 5,
            title: '6. Math: Sum of Digits',
            difficulty: 'Easy',
            description: 'Given integer `n`, return the sum of its individual digits.',
            hint: 'Repeatedly add `n % 10` and divide `Math.floor(n / 10)`.',
            starterCode: `function sumDigits(n) {\n  let sum = 0;\n  n = Math.abs(n);\n  while (n > 0) {\n    sum += n % 10;\n    n = Math.floor(n / 10);\n  }\n  return sum;\n}`,
            testCases: [
                { input: 1234, expected: '10' },
                { input: 909, expected: '18' },
            ],
        },
    ];
    const [selectedCodingProblem, setSelectedCodingProblem] = useState(0);
    const [userCode, setUserCode] = useState(codingProblems[0].starterCode);
    const [codeExecutionResults, setCodeExecutionResults] = useState(null);
    const [codingSolved, setCodingSolved] = useState({});
    useEffect(() => {
        setUserCode(codingProblems[selectedCodingProblem].starterCode);
        setCodeExecutionResults(null);
    }, [selectedCodingProblem]);
    const handleRunCode = () => {
        const prob = codingProblems[selectedCodingProblem];
        const logs = [];
        let allPassed = true;
        try {
            logs.push(`🚀 Compiling solution for: ${prob.title}...`);
            // Simulated safe execution evaluation
            prob.testCases.forEach((tc, idx) => {
                logs.push(`✓ Test Case ${idx + 1}: Input (${JSON.stringify(tc.input)}) => Expected: ${tc.expected} [Passed]`);
            });
            logs.push(`🎉 All ${prob.testCases.length} Test Cases Passed Successfully!`);
            setCodeExecutionResults({ pass: true, logs });
            setCodingSolved((prev) => ({ ...prev, [selectedCodingProblem]: true }));
        }
        catch (err) {
            allPassed = false;
            logs.push(`❌ Runtime Error: ${err.message}`);
            setCodeExecutionResults({ pass: false, logs });
        }
    };
    // ================= 2. APTITUDE ARENA STATE =================
    const aptitudeQuestions = [
        {
            id: 0,
            topic: 'Speed Math - Percentages',
            question: 'If the price of petrol increases by 25%, by what percentage must a car owner reduce consumption so that expenditure remains unchanged?',
            options: ['20%', '25%', '15%', '16.66%'],
            correct: 0,
            explanation: 'Formula: [R / (100 + R)] * 100 = [25 / 125] * 100 = 20%.',
        },
        {
            id: 1,
            topic: 'Logical Reasoning - Number Series',
            question: 'Find the next number in the series: 2, 6, 12, 20, 30, ?',
            options: ['40', '42', '44', '48'],
            correct: 1,
            explanation: 'Differences are +4, +6, +8, +10, +12. 30 + 12 = 42 (or n^2 + n).',
        },
        {
            id: 2,
            topic: 'Time & Work',
            question: 'A can do a piece of work in 12 days, and B can do it in 24 days. How many days will they take working together?',
            options: ['6 days', '8 days', '10 days', '18 days'],
            correct: 1,
            explanation: 'Combined 1-day work = 1/12 + 1/24 = 3/24 = 1/8. So 8 days.',
        },
        {
            id: 3,
            topic: 'Ratios & Proportions',
            question: 'If A:B = 3:4 and B:C = 8:9, what is A:C?',
            options: ['1:2', '2:3', '3:2', '4:5'],
            correct: 1,
            explanation: 'A/C = (A/B) * (B/C) = (3/4) * (8/9) = 24/36 = 2/3.',
        },
        {
            id: 4,
            topic: 'Speed, Time & Distance',
            question: 'A train 150m long is travelling at 54 km/h. How many seconds will it take to pass an electric pole?',
            options: ['8 sec', '10 sec', '12 sec', '15 sec'],
            correct: 1,
            explanation: 'Speed in m/s = 54 * (5/18) = 15 m/s. Time = Distance/Speed = 150/15 = 10 seconds.',
        },
        {
            id: 5,
            topic: 'Verbal Ability - Synonyms',
            question: 'Choose the most suitable synonym for the word: "PRAGMATIC"',
            options: ['Theoretical', 'Practical', 'Careless', 'Arrogant'],
            correct: 1,
            explanation: '"Pragmatic" means dealing with things sensibly and realistically; practical.',
        },
    ];
    const [selectedAptOption, setSelectedAptOption] = useState({});
    const [aptSubmitted, setAptSubmitted] = useState({});
    const [aptTimer, setAptTimer] = useState(60);
    useEffect(() => {
        const timer = setInterval(() => {
            setAptTimer((prev) => (prev > 0 ? prev - 1 : 60));
        }, 1000);
        return () => clearInterval(timer);
    }, []);
    const totalAptSolved = Object.keys(aptSubmitted).length;
    const totalAptCorrect = Object.entries(aptSubmitted).filter(([qId]) => selectedAptOption[Number(qId)] === aptitudeQuestions[Number(qId)].correct).length;
    // ================= 3. INTERACTIVE SKILL BUILDER ACTIVITIES =================
    // Activity 1: Git Simulator
    const [gitTerminalCommands, setGitTerminalCommands] = useState([
        'Welcome to NEC Junior Git Terminal Simulator!',
        'Try typing: git init, git add ., or git commit -m "First commit"',
    ]);
    const [gitInput, setGitInput] = useState('');
    const [gitCompletedSteps, setGitCompletedSteps] = useState({});
    const handleGitSubmit = (e) => {
        e.preventDefault();
        if (!gitInput.trim())
            return;
        const cmd = gitInput.trim();
        const newLogs = [...gitTerminalCommands, `$ ${cmd}`];
        if (cmd === 'git init') {
            newLogs.push('Initialized empty Git repository in /campus/nec-project/.git/');
            setGitCompletedSteps((p) => ({ ...p, init: true }));
        }
        else if (cmd === 'git add .' || cmd === 'git add index.js') {
            newLogs.push('Staged all project files for commit (ready for git commit).');
            setGitCompletedSteps((p) => ({ ...p, add: true }));
        }
        else if (cmd.startsWith('git commit')) {
            newLogs.push('[main (root-commit) 8f3b2a] ' + (cmd.split('-m')[1] || 'Initial commit'));
            newLogs.push(' 3 files changed, 48 insertions(+)');
            setGitCompletedSteps((p) => ({ ...p, commit: true }));
        }
        else if (cmd === 'git status') {
            newLogs.push('On branch main. Nothing to commit, working tree clean.');
        }
        else {
            newLogs.push(`Command '${cmd}' recognized. Good practice! Try 'git init', 'git add .', or 'git commit -m "msg"'.`);
        }
        setGitTerminalCommands(newLogs);
        setGitInput('');
    };
    // Activity 2: Interactive SQL Query Studio
    const [sqlQuery, setSqlQuery] = useState('SELECT name, department, cgpa FROM students WHERE cgpa >= 8.5;');
    const [sqlResults, setSqlResults] = useState([
        { id: 1, name: 'Anandha Selvan', department: 'CSE', cgpa: 8.92 },
        { id: 2, name: 'Bavithra K', department: 'IT', cgpa: 8.65 },
        { id: 3, name: 'Karthik Raja M', department: 'CSE', cgpa: 8.52 },
    ]);
    const [sqlMessage, setSqlMessage] = useState('Query executed successfully: 3 rows returned in 4ms.');
    const handleExecuteSql = () => {
        setSqlMessage(`Query "${sqlQuery}" executed! Database tables scanned successfully.`);
    };
    // ================= 4. DAILY CHALLENGES =================
    const [dailyChallenges, setDailyChallenges] = useState([
        {
            id: 'c1',
            type: 'Coding Sprint',
            title: 'Count Vowels & Consonants',
            desc: 'Write a program to scan a string and output the total vowels vs consonants ignoring spaces.',
            reward: 25,
            completed: false,
        },
        {
            id: 'c2',
            type: 'Aptitude Quickfire',
            title: 'Train Crossing Platform Problem',
            desc: 'A 180m train travelling at 54 km/h passes a platform in 20 seconds. Find platform length.',
            reward: 20,
            completed: false,
        },
        {
            id: 'c3',
            type: 'Communication Sprint',
            title: 'Record 60-Second Elevator Pitch',
            desc: 'Introduce yourself: Name, Department, primary programming interest, and 1 project.',
            reward: 30,
            completed: false,
        },
    ]);
    const [challengeInput, setChallengeInput] = useState({});
    const handleCompleteChallenge = (id) => {
        setDailyChallenges((prev) => prev.map((c) => (c.id === id ? { ...c, completed: true } : c)));
    };
    // ================= 5. ASK A SENIOR INTERACTIVE FORUM =================
    const [askedQuestions, setAskedQuestions] = useState([
        {
            id: 1,
            student: 'Junior (25104001)',
            topic: 'DSA in 2nd Year',
            question: 'Should I focus more on LeetCode or core subjects like DBMS and OS during 3rd and 4th semester?',
            senior: 'Priya Dharshini (Zoho MTS • Batch 2026)',
            reply: 'Master C++ / Java fundamentals and basic arrays/strings first. In 4th semester, start basic LeetCode Easy problems alongside your college DBMS labs. Consistency beats cramming!',
            likes: 18,
        },
        {
            id: 2,
            student: 'Junior (25104002)',
            topic: 'CGPA Cutoffs',
            question: 'What is the safe CGPA cutoff for Dream and Super Dream companies visiting National Engineering College?',
            senior: 'Karthik Subramanian (TCS Digital • Batch 2026)',
            reply: 'Aim to keep your CGPA strictly above 8.0 with zero active arrears. This guarantees eligibility for 95%+ of visiting campus recruitment drives.',
            likes: 24,
        },
    ]);
    const [newQuestionText, setNewQuestionText] = useState('');
    const [newQuestionTopic, setNewQuestionTopic] = useState('Placement Roadmap');
    const handlePostQuestion = (e) => {
        e.preventDefault();
        if (!newQuestionText.trim())
            return;
        const newQ = {
            id: Date.now(),
            student: `${user?.name || 'Junior Student'} (${user?.rollNumber || '25104009'})`,
            topic: newQuestionTopic,
            question: newQuestionText,
            senior: 'Karthik Raja S (Senior Mentor)',
            reply: 'Thanks for reaching out! In 2nd year, dedicate 45 minutes daily to solving basic programming logic. Consistency and asking doubts early will put you ahead of 90% of candidates.',
            likes: 1,
        };
        setAskedQuestions([newQ, ...askedQuestions]);
        setNewQuestionText('');
    };
    // ================= 6. INTERACTIVE LEARNING PLANNER =================
    const [plannerTasks, setPlannerTasks] = useState([
        { id: 1, text: 'Solve 2 array problems on Coding Basics', done: true },
        { id: 2, text: 'Complete Speed Math Percentages Quiz', done: true },
        { id: 3, text: 'Practice Git Terminal (git init, commit)', done: false },
        { id: 4, text: 'Write a basic SQL query with INNER JOIN', done: false },
        { id: 5, text: 'Prepare 90-sec introduction for mock interviews', done: false },
    ]);
    const [newTaskInput, setNewTaskInput] = useState('');
    const [studyHoursTarget, setStudyHoursTarget] = useState(2);
    const handleAddTask = (e) => {
        e.preventDefault();
        if (!newTaskInput.trim())
            return;
        setPlannerTasks([
            ...plannerTasks,
            { id: Date.now(), text: newTaskInput.trim(), done: false },
        ]);
        setNewTaskInput('');
    };
    const handleToggleTask = (id) => {
        setPlannerTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
    };
    const handleDeleteTask = (id) => {
        setPlannerTasks((prev) => prev.filter((t) => t.id !== id));
    };
    // Calculate live dynamic readiness score
    const solvedCodeCount = Object.keys(codingSolved).length;
    const completedChallengesCount = dailyChallenges.filter((c) => c.completed).length;
    const completedTasksCount = plannerTasks.filter((t) => t.done).length;
    const totalScoreCalc = Math.min(100, Math.round((solvedCodeCount / codingProblems.length) * 35 +
        (totalAptCorrect / aptitudeQuestions.length) * 25 +
        (completedChallengesCount / dailyChallenges.length) * 20 +
        (completedTasksCount / plannerTasks.length) * 20));
    return (<div className="space-y-6 animate-in fade-in duration-200 text-xs">
      {/* Top Banner specifically for Juniors */}
      <div className="p-6 rounded-3xl text-white shadow-md relative overflow-hidden transition-all" style={{
            background: `linear-gradient(135deg, ${themeColor} 0%, #0f172a 100%)`,
        }}>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300 bg-amber-400/20 px-2.5 py-0.5 rounded-full border border-amber-300/30">
              {t('junior', 'Junior Foundation Hub • 2nd Year (Batch 2028)')}
            </span>
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-semibold">
              Live Readiness: {totalScoreCalc}%
            </span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">
            {t('platformTitle', 'Junior Placement Roadmap & Practice Studio')}
          </h2>
          <p className="text-xs text-blue-100 max-w-2xl mt-1 leading-relaxed">
            {t('tagline', 'Learn coding fundamentals, speed aptitude, interactive Git, SQL, and connect with placed seniors.')}
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-4 border-t border-white/10 text-white">
            <div className="bg-black/20 p-2.5 rounded-xl backdrop-blur-xs">
              <span className="text-[10px] text-white/70">Coding Solved</span>
              <p className="text-base font-black">{solvedCodeCount} / {codingProblems.length}</p>
            </div>
            <div className="bg-black/20 p-2.5 rounded-xl backdrop-blur-xs">
              <span className="text-[10px] text-white/70">Aptitude Correct</span>
              <p className="text-base font-black">{totalAptCorrect} / {aptitudeQuestions.length}</p>
            </div>
            <div className="bg-black/20 p-2.5 rounded-xl backdrop-blur-xs">
              <span className="text-[10px] text-white/70">Daily Streak</span>
              <p className="text-base font-black">🔥 7 Days</p>
            </div>
            <div className="bg-black/20 p-2.5 rounded-xl backdrop-blur-xs">
              <span className="text-[10px] text-white/70">Tasks Completed</span>
              <p className="text-base font-black">{completedTasksCount} / {plannerTasks.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 10 Navigation Tabs for Juniors with Active Indicator */}
      <div className="bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center gap-1.5 overflow-x-auto scrollbar-none text-xs">
        {[
            { id: 'coding_basics', label: t('coding_basics', 'Coding Basics'), icon: Code2 },
            { id: 'aptitude_starter', label: t('aptitude_starter', 'Aptitude Starter'), icon: Award },
            { id: 'skills', label: t('skills', 'Skill Builder'), icon: Cpu },
            { id: 'challenges', label: t('challenges', 'Daily Challenges'), icon: Flame },
            { id: 'journey', label: t('journey', 'Placement Journey'), icon: Compass },
            { id: 'careers', label: t('careers', 'Career Explorer'), icon: Briefcase },
            { id: 'companies', label: t('companies', 'Company Explorer'), icon: Building2 },
            { id: 'ask_senior', label: t('ask_senior', 'Ask a Senior'), icon: MessageSquare },
            { id: 'progress', label: t('progress', 'My Progress'), icon: BarChart3 },
            { id: 'planner', label: t('planner', 'Learning Planner'), icon: Calendar },
        ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (<button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold transition whitespace-nowrap cursor-pointer ${isActive
                    ? 'text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{
                    backgroundColor: isActive ? themeColor : undefined,
                }}>
              <Icon className="w-3.5 h-3.5"/>
              <span>{tab.label}</span>
            </button>);
        })}
      </div>

      {/* ================= 1. INTERACTIVE CODING BASICS PLAYGROUND ================= */}
      {activeTab === 'coding_basics' && (<div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Problem Selector List */}
          <div className="lg:col-span-4 space-y-2.5">
            <div className="flex items-center justify-between pb-1">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Beginner Coding Problems
              </h3>
              <span className="text-[10px] bg-blue-100 text-blue-900 px-2 py-0.5 rounded font-bold">
                {solvedCodeCount}/{codingProblems.length} Solved
              </span>
            </div>

            <div className="space-y-1.5">
              {codingProblems.map((prob) => {
                const isSelected = selectedCodingProblem === prob.id;
                const isSolved = codingSolved[prob.id];
                return (<button key={prob.id} onClick={() => setSelectedCodingProblem(prob.id)} className={`w-full p-3 rounded-xl text-left border transition cursor-pointer flex items-center justify-between ${isSelected
                        ? 'border-blue-500 bg-blue-50 dark:bg-slate-800 text-blue-950 dark:text-white font-bold ring-1 ring-blue-500/20'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50'}`}>
                    <div className="truncate mr-2">
                      <p className="truncate text-xs">{prob.title}</p>
                      <span className="text-[10px] text-slate-400 font-normal">{prob.difficulty}</span>
                    </div>
                    {isSolved ? (<CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0"/>) : (<span className="w-2 h-2 rounded-full bg-slate-300 shrink-0"/>)}
                  </button>);
            })}
            </div>
          </div>

          {/* Interactive Code Editor & Test Runner */}
          <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  {codingProblems[selectedCodingProblem].title}
                </h4>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {codingProblems[selectedCodingProblem].difficulty}
                </span>
              </div>
              <p className="text-slate-600 dark:text-slate-300 text-xs mt-1 leading-relaxed">
                {codingProblems[selectedCodingProblem].description}
              </p>
            </div>

            {/* Beginner Hint */}
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-300 text-xs flex items-start gap-2">
              <span className="font-bold shrink-0">💡 Hint:</span>
              <span>{codingProblems[selectedCodingProblem].hint}</span>
            </div>

            {/* Code Editor */}
            <div>
              <div className="flex items-center justify-between pb-1.5 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5"/>
                  <span>JavaScript / Python Interactive Editor</span>
                </span>
                <button onClick={() => setUserCode(codingProblems[selectedCodingProblem].starterCode)} className="text-[11px] text-blue-600 hover:underline flex items-center gap-1 cursor-pointer">
                  <RotateCcw className="w-3 h-3"/>
                  <span>Reset Template</span>
                </button>
              </div>
              <textarea rows={6} value={userCode} onChange={(e) => setUserCode(e.target.value)} className="w-full p-3 font-mono text-xs bg-slate-950 text-emerald-400 rounded-xl outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed"/>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-1">
              <button onClick={handleRunCode} className="px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center gap-2 shadow-xs" style={{ backgroundColor: themeColor }}>
                <Play className="w-3.5 h-3.5 fill-current"/>
                <span>Run Code & Verify Test Cases</span>
              </button>

              {codingSolved[selectedCodingProblem] && (<span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4"/>
                  <span>Solved (+25 XP)</span>
                </span>)}
            </div>

            {/* Terminal Output */}
            {codeExecutionResults && (<div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 font-mono text-xs space-y-1 animate-in fade-in">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800 text-[11px] text-slate-400">
                  <span>Terminal Execution Console</span>
                  <span className={codeExecutionResults.pass ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {codeExecutionResults.pass ? 'PASSED ✓' : 'FAILED ✕'}
                  </span>
                </div>
                {codeExecutionResults.logs.map((log, i) => (<p key={i} className={log.includes('Passed') ? 'text-emerald-400' : 'text-slate-300'}>
                    {log}
                  </p>))}
              </div>)}
          </div>
        </div>)}

      {/* ================= 2. INTERACTIVE APTITUDE STARTER ================= */}
      {activeTab === 'aptitude_starter' && (<div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Quantitative & Speed Math Starter
                </h3>
                <p className="text-slate-500 text-xs">
                  Timed campus placement screening aptitude quiz with instant scoring.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 font-mono font-bold text-xs">
                  <Clock className="w-4 h-4 text-amber-600"/>
                  <span>Timer: {aptTimer}s</span>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-xs">
                  Score: {totalAptCorrect} / {aptitudeQuestions.length}
                </div>
              </div>
            </div>

            {/* Questions List */}
            <div className="space-y-4">
              {aptitudeQuestions.map((q) => {
                const isAnswered = selectedAptOption[q.id] !== undefined;
                const isSubmitted = aptSubmitted[q.id];
                const isCorrect = selectedAptOption[q.id] === q.correct;
                return (<div key={q.id} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-900 dark:text-blue-200">
                        {q.topic}
                      </span>
                      {isSubmitted && (<span className={`text-[10px] font-bold px-2 py-0.5 rounded ${isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                          {isCorrect ? '✓ Correct Answer (+10 XP)' : '✕ Incorrect'}
                        </span>)}
                    </div>

                    <p className="font-bold text-slate-800 dark:text-slate-200 text-xs leading-relaxed">
                      {q.id + 1}. {q.question}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt, optIdx) => {
                        const isChosen = selectedAptOption[q.id] === optIdx;
                        return (<button key={optIdx} onClick={() => setSelectedAptOption({ ...selectedAptOption, [q.id]: optIdx })} className={`p-2.5 rounded-xl border text-left text-xs font-medium transition cursor-pointer ${isChosen
                                ? 'bg-blue-900 text-white border-blue-900 shadow-xs'
                                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'}`}>
                            <span className="font-bold mr-1.5">{String.fromCharCode(65 + optIdx)})</span>
                            <span>{opt}</span>
                          </button>);
                    })}
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <button onClick={() => setAptSubmitted({ ...aptSubmitted, [q.id]: true })} disabled={!isAnswered} className="px-4 py-1.5 bg-blue-900 hover:bg-blue-800 disabled:opacity-40 text-white font-bold rounded-lg text-xs cursor-pointer" style={{ backgroundColor: themeColor }}>
                        Check Answer
                      </button>

                      {isSubmitted && (<p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                          💡 <strong>Formula:</strong> {q.explanation}
                        </p>)}
                    </div>
                  </div>);
            })}
            </div>
          </div>
        </div>)}

      {/* ================= 3. INTERACTIVE SKILL BUILDER (GIT TERMINAL & SQL STUDIO) ================= */}
      {activeTab === 'skills' && (<div className="space-y-5">
          {/* Activity 1: Live Interactive Git Terminal Simulator */}
          <div className="bg-slate-950 p-5 rounded-3xl border border-slate-800 shadow-md text-white space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400"/>
                <span className="font-bold text-xs text-white">Interactive Git Terminal Simulator</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400">
                <span>Completed:</span>
                <span className={gitCompletedSteps.init ? 'text-emerald-400' : 'text-slate-500'}>init ✓</span>
                <span className={gitCompletedSteps.add ? 'text-emerald-400' : 'text-slate-500'}>add ✓</span>
                <span className={gitCompletedSteps.commit ? 'text-emerald-400' : 'text-slate-500'}>commit ✓</span>
              </div>
            </div>

            <div className="h-40 overflow-y-auto space-y-1 font-mono text-[11px] text-slate-300 pr-2">
              {gitTerminalCommands.map((line, idx) => (<p key={idx} className={line.startsWith('$') ? 'text-amber-300 font-bold' : 'text-emerald-400'}>
                  {line}
                </p>))}
            </div>

            <form onSubmit={handleGitSubmit} className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <span className="text-emerald-400 font-mono font-bold">$</span>
              <input type="text" placeholder="Type 'git init', 'git add .', or 'git commit -m &quot;first commit&quot;'..." value={gitInput} onChange={(e) => setGitInput(e.target.value)} className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-white placeholder-slate-500"/>
              <button type="submit" className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs cursor-pointer">
                Execute
              </button>
            </form>
          </div>

          {/* Activity 2: Interactive SQL Query Studio */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600"/>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  Interactive SQL Database Query Studio
                </h4>
              </div>
              <span className="text-[10px] text-slate-500">Live Practice Table: `students`</span>
            </div>

            <div>
              <textarea rows={2} value={sqlQuery} onChange={(e) => setSqlQuery(e.target.value)} className="w-full p-3 font-mono text-xs bg-slate-900 text-blue-200 rounded-xl outline-none focus:ring-1 focus:ring-blue-500"/>
            </div>

            <div className="flex items-center justify-between">
              <button onClick={handleExecuteSql} className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs cursor-pointer flex items-center gap-1.5" style={{ backgroundColor: themeColor }}>
                <Play className="w-3.5 h-3.5"/>
                <span>Execute SQL Query</span>
              </button>
              <span className="text-[11px] text-emerald-600 font-medium">{sqlMessage}</span>
            </div>

            {/* Query Results Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                  <tr>
                    <th className="p-2.5">ID</th>
                    <th className="p-2.5">Student Name</th>
                    <th className="p-2.5">Department</th>
                    <th className="p-2.5">CGPA</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {sqlResults.map((r) => (<tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-mono text-slate-500">{r.id}</td>
                      <td className="p-2.5 font-semibold text-slate-900 dark:text-white">{r.name}</td>
                      <td className="p-2.5 text-slate-600 dark:text-slate-300">{r.department}</td>
                      <td className="p-2.5 font-bold text-blue-900 dark:text-blue-400">{r.cgpa}</td>
                    </tr>))}
                </tbody>
              </table>
            </div>
          </div>
        </div>)}

      {/* ================= 4. DAILY LEARNING CHALLENGES ================= */}
      {activeTab === 'challenges' && (<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {dailyChallenges.map((ch) => (<div key={ch.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                    {ch.type}
                  </span>
                  <span className="text-[10px] font-bold text-emerald-600">+{ch.reward} XP</span>
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">{ch.title}</h4>
                <p className="text-slate-600 dark:text-slate-300 text-xs leading-relaxed">{ch.desc}</p>
                <textarea rows={2} placeholder="Type your solution / summary here..." value={challengeInput[ch.id] || ''} onChange={(e) => setChallengeInput({ ...challengeInput, [ch.id]: e.target.value })} className="w-full p-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs outline-none"/>
              </div>

              <button onClick={() => handleCompleteChallenge(ch.id)} className={`w-full py-2.5 rounded-xl font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${ch.completed
                    ? 'bg-emerald-100 text-emerald-800 font-black'
                    : 'bg-blue-900 hover:bg-blue-800 text-white'}`} style={{ backgroundColor: !ch.completed ? themeColor : undefined }}>
                {ch.completed ? <CheckCircle2 className="w-4 h-4"/> : null}
                <span>{ch.completed ? 'Challenge Solved ✓' : 'Submit Challenge Solution'}</span>
              </button>
            </div>))}
        </div>)}

      {/* ================= 5. PLACEMENT JOURNEY ROADMAP ================= */}
      {activeTab === 'journey' && (<div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Campus Recruitment Journey (Day 1 to Offer Letter)
            </h3>
            <p className="text-slate-500 text-xs mt-0.5">
              Comprehensive 4-round recruitment workflow conducted at National Engineering College.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {[
                {
                    round: 'Round 1',
                    name: 'Online Screening (OA)',
                    topics: 'Speed Math, Logical Reasoning, C/Java Output Questions',
                    action: 'Practice Aptitude Starter',
                    tab: 'aptitude_starter',
                },
                {
                    round: 'Round 2',
                    name: 'Hands-on Coding Assessment',
                    topics: 'Arrays, Strings, Recursion, Time Complexity Analysis',
                    action: 'Open Coding Basics',
                    tab: 'coding_basics',
                },
                {
                    round: 'Round 3',
                    name: 'Technical Interview',
                    topics: 'OOP Pillars, SQL Queries, Git Architecture, Projects',
                    action: 'Skill Builder Studio',
                    tab: 'skills',
                },
                {
                    round: 'Round 4',
                    name: 'HR & Cultural Alignment',
                    topics: '90-sec Elevator Pitch, Communication, Career Vision',
                    action: 'Ask a Senior Mentor',
                    tab: 'ask_senior',
                },
            ].map((r, idx) => (<div key={idx} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2 flex flex-col justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase text-blue-900 dark:text-blue-400">
                    {r.round}
                  </span>
                  <p className="font-bold text-slate-900 dark:text-white text-sm">{r.name}</p>
                  <p className="text-slate-500 text-[11px]">{r.topics}</p>
                </div>
                <button onClick={() => setActiveTab(r.tab)} className="w-full py-1.5 text-center rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-900 dark:text-blue-200 font-bold text-xs hover:bg-blue-200 cursor-pointer">
                  {r.action} →
                </button>
              </div>))}
          </div>
        </div>)}

      {/* ================= 6. CAREER EXPLORER ================= */}
      {activeTab === 'careers' && (<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
                {
                    title: 'Full Stack & Web Engineering',
                    package: '₹6.5 - 12 LPA',
                    roles: ['Frontend Developer', 'Backend Engineer', 'Full Stack SDE'],
                    skills: ['React', 'Node.js', 'MongoDB / PostgreSQL', 'REST APIs'],
                    companies: ['Zoho', 'Freshworks', 'Amazon', 'Accenture'],
                },
                {
                    title: 'AI, ML & Data Analytics',
                    package: '₹7.0 - 14 LPA',
                    roles: ['Data Analyst', 'ML Engineer', 'Applied AI Associate'],
                    skills: ['Python', 'Pandas & NumPy', 'SQL', 'Scikit-Learn'],
                    companies: ['TCS Digital', 'L&T Technology', 'Tiger Analytics'],
                },
                {
                    title: 'Cloud & DevOps Engineering',
                    package: '₹6.0 - 11 LPA',
                    roles: ['Cloud Associate', 'Site Reliability Engineer', 'DevOps Analyst'],
                    skills: ['Linux Shell', 'Docker', 'AWS / Google Cloud', 'CI/CD Pipelines'],
                    companies: ['Cognizant', 'Infosys', 'Cisco'],
                },
            ].map((c, idx) => (<div key={idx} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">{c.title}</h4>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {c.package}
                </span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Core Job Roles</span>
                <p className="text-slate-700 dark:text-slate-300 font-medium text-xs mt-0.5">
                  {c.roles.join(' • ')}
                </p>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Foundational Skills</span>
                <p className="text-slate-600 dark:text-slate-400 text-xs mt-0.5">{c.skills.join(', ')}</p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-blue-900 dark:text-blue-400 font-semibold">
                <span>Hiring Partners: </span>
                <span className="text-slate-500 font-normal">{c.companies.join(', ')}</span>
              </div>
            </div>))}
        </div>)}

      {/* ================= 7. COMPANY EXPLORER ================= */}
      {activeTab === 'companies' && (<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
                {
                    name: 'Zoho Corporation',
                    type: 'Product / SaaS',
                    ctc: '₹8.4 - 12.0 LPA',
                    eligibility: 'CGPA 7.0+ | Zero Backlogs',
                    rounds: 'Aptitude -> Basic Coding -> Advanced DSA -> Tech -> HR',
                    tip: 'Focus heavily on C/Java pointers, matrix traversal, and string search.',
                },
                {
                    name: 'TCS (Digital & Prime)',
                    type: 'IT Services & High Growth',
                    ctc: '₹7.0 - 9.0 LPA',
                    eligibility: 'CGPA 7.0+ | All Branches',
                    rounds: 'TCS NQT Cognitive Test -> Coding Assessment -> Interview',
                    tip: 'Speed math shortcuts and logical series are key to clearing Round 1.',
                },
                {
                    name: 'Accenture',
                    type: 'Global Tech Consulting',
                    ctc: '₹4.5 - 6.5 LPA',
                    eligibility: 'CGPA 6.5+ | Up to 1 Backlog',
                    rounds: 'Cognitive Test -> Coding -> AI Communication -> Tech HR',
                    tip: 'Clarity in spoken English and modular clean code structures.',
                },
            ].map((comp, i) => (<div key={i} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">{comp.name}</h4>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {comp.ctc}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">{comp.type} • {comp.eligibility}</p>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-[11px] text-slate-700 dark:text-slate-300 space-y-1">
                <p><strong>Recruitment Flow:</strong> {comp.rounds}</p>
                <p className="text-blue-900 dark:text-blue-400"><strong>Junior Strategy:</strong> {comp.tip}</p>
              </div>
            </div>))}
        </div>)}

      {/* ================= 8. ASK A SENIOR ================= */}
      {activeTab === 'ask_senior' && (<div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Ask Placed Seniors & Alumni for Placement Strategy
            </h3>
            <form onSubmit={handlePostQuestion} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                <select value={newQuestionTopic} onChange={(e) => setNewQuestionTopic(e.target.value)} className="px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs font-semibold dark:text-white">
                  <option value="Placement Roadmap">Placement Roadmap</option>
                  <option value="DSA & Coding">DSA & Coding</option>
                  <option value="CGPA & Cutoffs">CGPA & Cutoffs</option>
                  <option value="Projects & Resume">Projects & Resume</option>
                  <option value="Company Specific">Company Specific</option>
                </select>
                <input type="text" required placeholder="Type your question for placed seniors..." value={newQuestionText} onChange={(e) => setNewQuestionText(e.target.value)} className="sm:col-span-3 px-4 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white"/>
              </div>
              <button type="submit" className="px-5 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5" style={{ backgroundColor: themeColor }}>
                <Send className="w-3.5 h-3.5"/>
                <span>Post Question to Seniors</span>
              </button>
            </form>
          </div>

          <div className="space-y-3">
            {askedQuestions.map((q) => (<div key={q.id} className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-200">
                    {q.topic}
                  </span>
                  <span className="text-slate-400 text-[10px]">{q.student}</span>
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">{q.question}</h4>
                <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-slate-700 dark:text-slate-300 space-y-1">
                  <p className="font-bold text-amber-900 dark:text-amber-400 text-[11px]">💬 Answer from {q.senior}:</p>
                  <p className="text-xs leading-relaxed">{q.reply}</p>
                </div>
              </div>))}
          </div>
        </div>)}

      {/* ================= 9. MY LEARNING PROGRESS ================= */}
      {activeTab === 'progress' && (<div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Live Junior Learning Progress Tracker
              </h3>
              <p className="text-slate-500 text-xs">
                Real-time tracking updated as you solve code problems, aptitude tests, and learning tasks.
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-blue-900 dark:text-blue-400">{totalScoreCalc}%</span>
              <p className="text-[10px] text-slate-400">Total Readiness Score</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-blue-50 dark:bg-slate-800/80 rounded-2xl border border-blue-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-blue-900 dark:text-blue-300 uppercase">Coding Problems</span>
              <p className="text-2xl font-black text-blue-950 dark:text-white mt-1">
                {solvedCodeCount} / {codingProblems.length}
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5">Basic arrays & strings</p>
            </div>
            <div className="p-4 bg-indigo-50 dark:bg-slate-800/80 rounded-2xl border border-indigo-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-indigo-900 dark:text-indigo-300 uppercase">Aptitude Correct</span>
              <p className="text-2xl font-black text-indigo-950 dark:text-white mt-1">
                {totalAptCorrect} / {aptitudeQuestions.length}
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5">Speed math practice</p>
            </div>
            <div className="p-4 bg-amber-50 dark:bg-slate-800/80 rounded-2xl border border-amber-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-amber-900 dark:text-amber-300 uppercase">Daily Streak</span>
              <p className="text-2xl font-black text-amber-950 dark:text-white mt-1">🔥 7 Days</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Consistent learner</p>
            </div>
            <div className="p-4 bg-emerald-50 dark:bg-slate-800/80 rounded-2xl border border-emerald-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-emerald-900 dark:text-emerald-300 uppercase">Challenges Done</span>
              <p className="text-2xl font-black text-emerald-950 dark:text-white mt-1">
                {completedChallengesCount} / {dailyChallenges.length}
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5">XP earned</p>
            </div>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-200">
              <span>Overall 2nd Year Foundation Progress</span>
              <span>{totalScoreCalc}% Complete</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-500" style={{ width: `${totalScoreCalc}%`, backgroundColor: themeColor }}/>
            </div>
          </div>
        </div>)}

      {/* ================= 10. INTERACTIVE LEARNING PLANNER ================= */}
      {activeTab === 'planner' && (<div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Interactive Placement Study Planner
              </h3>
              <p className="text-slate-500 text-xs">
                Add daily tasks, mark off milestones, and set daily preparation hours.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-slate-700 dark:text-slate-300">Daily Study Target:</span>
              <select value={studyHoursTarget} onChange={(e) => setStudyHoursTarget(Number(e.target.value))} className="px-2.5 py-1 border rounded-lg bg-slate-50 dark:bg-slate-800 font-bold dark:text-white">
                <option value={1}>1 Hour / Day</option>
                <option value={2}>2 Hours / Day</option>
                <option value={3}>3 Hours / Day</option>
                <option value={4}>4 Hours / Day</option>
              </select>
            </div>
          </div>

          {/* Add Task Form */}
          <form onSubmit={handleAddTask} className="flex items-center gap-2">
            <input type="text" placeholder="Add a new custom study task (e.g. 'Solve 3 loop questions', 'Watch OS Lecture')..." value={newTaskInput} onChange={(e) => setNewTaskInput(e.target.value)} className="flex-1 px-4 py-2.5 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 outline-none text-xs dark:text-white"/>
            <button type="submit" className="px-4 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs cursor-pointer flex items-center gap-1.5" style={{ backgroundColor: themeColor }}>
              <Plus className="w-4 h-4"/>
              <span>Add Task</span>
            </button>
          </form>

          {/* Checklist */}
          <div className="space-y-2">
            {plannerTasks.map((t) => (<div key={t.id} className={`p-3 rounded-xl border flex items-center justify-between transition ${t.done
                    ? 'bg-emerald-50/50 dark:bg-slate-800/80 border-emerald-300 dark:border-emerald-900 line-through text-slate-400'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'}`}>
                <label className="flex items-center gap-3 cursor-pointer flex-1">
                  <input type="checkbox" checked={t.done} onChange={() => handleToggleTask(t.id)} className="w-4 h-4 text-emerald-600 rounded"/>
                  <span className="text-xs font-semibold">{t.text}</span>
                </label>
                <button onClick={() => handleDeleteTask(t.id)} className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer">
                  <Trash2 className="w-3.5 h-3.5"/>
                </button>
              </div>))}
          </div>
        </div>)}
    </div>);
};
