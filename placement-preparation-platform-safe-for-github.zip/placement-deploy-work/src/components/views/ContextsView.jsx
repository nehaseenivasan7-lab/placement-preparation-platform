import React from 'react';
import { Compass, Target, Building, History, Users, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
export const ContextsView = ({ onOpenModule }) => {
    const { user } = useAuth();
    const goals = user ? storageService.getStudyGoals(user.id) : [];
    const recentlyAccessed = user ? storageService.getRecentlyAccessed(user.id) : [];
    const allCompanies = storageService.getCompanies();
    const mentors = storageService.getUsers().filter((u) => u.role === 'senior');
    const targetCompanies = allCompanies.filter((c) => user?.preferredCompanies?.some((pc) => c.name.toLowerCase().includes(pc.toLowerCase())));
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-blue-950 via-blue-900 to-indigo-950 text-white shadow-md">
        <div className="flex items-center gap-2 mb-1">
          <Compass className="w-5 h-5 text-amber-400"/>
          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
            Personalization Engine
          </span>
        </div>
        <h2 className="text-2xl font-black tracking-tight">Placement Contexts & Strategic Roadmap</h2>
        <p className="text-xs text-blue-200 mt-1 max-w-2xl">
          Your centralized preparation context: target companies, milestones, active mentor relationships, and saved materials.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start text-xs">
        {/* Target Companies Context */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-blue-800"/>
              <h3 className="font-bold text-sm text-slate-900">Target Companies Context</h3>
            </div>
            <button onClick={() => onOpenModule('companyExplorer')} className="text-xs text-blue-700 font-bold hover:underline cursor-pointer">
              Explore criteria →
            </button>
          </div>

          <p className="text-slate-500 text-[11px]">
            Companies you have selected as primary placement aspirations:
          </p>

          <div className="space-y-2">
            {(targetCompanies.length > 0 ? targetCompanies : allCompanies.slice(0, 3)).map((c) => (<div key={c.id} onClick={() => onOpenModule('companyExplorer')} className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 hover:border-blue-400 hover:bg-white transition cursor-pointer flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900">{c.name}</h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900">
                      {c.tier}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">{c.packageRange} • Min {c.eligibilityCgpa} CGPA</p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400"/>
              </div>))}
          </div>
        </div>

        {/* Active Goals Context */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-amber-600"/>
              <h3 className="font-bold text-sm text-slate-900">Active Goals & Milestones</h3>
            </div>
            <button onClick={() => onOpenModule('studyPlanner')} className="text-xs text-blue-700 font-bold hover:underline cursor-pointer">
              Study Planner →
            </button>
          </div>

          <p className="text-slate-500 text-[11px]">Personal placement preparation checklist:</p>

          <div className="space-y-2">
            {goals.length === 0 ? (<div className="p-4 bg-slate-50 rounded-xl text-center text-slate-400">
                No goals created yet. Use the Study Planner module to set daily targets.
              </div>) : (goals.slice(0, 4).map((g) => (<div key={g.id} className={`p-3 rounded-xl border flex items-center justify-between ${g.isCompleted ? 'bg-emerald-50/50 border-emerald-200' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className={`w-4 h-4 ${g.isCompleted ? 'text-emerald-600' : 'text-slate-300'}`}/>
                    <span className={`font-semibold ${g.isCompleted ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                      {g.title}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{g.deadline}</span>
                </div>)))}
          </div>
        </div>

        {/* Mentor Context */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-700"/>
              <h3 className="font-bold text-sm text-slate-900">Assigned Senior Mentor Context</h3>
            </div>
            <button onClick={() => onOpenModule('mentorship')} className="text-xs text-blue-700 font-bold hover:underline cursor-pointer">
              Mentor Directory →
            </button>
          </div>

          <p className="text-slate-500 text-[11px]">Top seniors designated for your target specializations:</p>

          <div className="space-y-2">
            {mentors.slice(0, 3).map((m) => (<div key={m.id} onClick={() => onOpenModule('mentorship')} className="p-3 bg-slate-50 rounded-xl border border-slate-200 hover:border-blue-400 transition cursor-pointer flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900">{m.name}</h4>
                  <p className="text-[11px] text-blue-900 font-semibold">{m.specialization}</p>
                  <p className="text-[10px] text-slate-500 font-mono">Placed at {m.currentCompany}</p>
                </div>
                <span className="text-[11px] text-blue-700 font-bold">Connect →</span>
              </div>))}
          </div>
        </div>

        {/* Recent Activity Audit Context */}
        <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-emerald-700"/>
            <h3 className="font-bold text-sm text-slate-900">Recent Activity Context</h3>
          </div>

          <p className="text-slate-500 text-[11px]">Audit trail of recently opened modules & questions:</p>

          <div className="space-y-2">
            {recentlyAccessed.length === 0 ? (<div className="p-4 bg-slate-50 rounded-xl text-center text-slate-400">
                No recent activity recorded yet.
              </div>) : (recentlyAccessed.slice(0, 4).map((rec) => (<div key={rec.id} onClick={() => onOpenModule(rec.link)} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer hover:bg-white">
                  <div>
                    <p className="font-bold text-slate-900 truncate max-w-[200px]">{rec.title}</p>
                    <p className="text-[10px] text-slate-400">{rec.subtext}</p>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    {new Date(rec.accessedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>)))}
          </div>
        </div>
      </div>
    </div>);
};
