import React from 'react';
import { Building2, BookOpen, Award, Layers, HelpCircle, PlayCircle, Flame, Terminal, Calculator, Video, Users, Compass, MessageSquare, CalendarCheck, BarChart3, Trophy, Calendar, History, ArrowRight, Sparkles, } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const WorkspaceView = ({ onOpenModule }) => {
    const { user } = useAuth();
    const progress = user ? storageService.getUserProgress(user.id) : null;
    const modules = [
        {
            id: 'companyExplorer',
            num: '01',
            name: 'Company Explorer',
            desc: 'Explore visiting companies, eligibility CGPA, compensation tiers, and historical selection processes.',
            icon: Building2,
            assignedMentor: 'Priya M (Zoho MTS · SEN001)',
            color: 'from-blue-700 to-indigo-700',
            progressText: `${storageService.getCompanies().length} Companies Active`,
        },
        {
            id: 'companyPlaybook',
            num: '02',
            name: 'Company Playbook',
            desc: 'Targeted preparation guides with round-wise focus topics and insider tips from placed seniors.',
            icon: BookOpen,
            assignedMentor: 'Karthik Raja S (SEN003)',
            color: 'from-blue-800 to-slate-900',
            progressText: `${storageService.getPlaybooks().length} Playbooks Ready`,
        },
        {
            id: 'interviewExperiences',
            num: '03',
            name: 'Interview Experiences',
            desc: 'Real drive debriefs, actual questions asked by panelists, difficulty ratings, and candidate takeaways.',
            icon: Award,
            assignedMentor: 'Karthik Raja S (TCS Digital · SEN003)',
            color: 'from-amber-600 to-amber-700',
            progressText: `${storageService.getInterviewExperiences().length} Verified Reviews`,
        },
        {
            id: 'roundResources',
            num: '04',
            name: 'Round Resources',
            desc: 'Round-by-round syllabus, formula cheatsheets, technical handbook, and HR answer blueprints.',
            icon: Layers,
            assignedMentor: 'Priya M & Deepa R (SEN001/004)',
            color: 'from-indigo-600 to-blue-700',
            progressText: `${storageService.getResources().length} Guides Available`,
        },
        {
            id: 'questionBank',
            num: '05',
            name: 'Question Bank',
            desc: 'Filterable repository of coding, aptitude, core CS (OS, DBMS, CN), and HR interview questions.',
            icon: HelpCircle,
            assignedMentor: 'Deepa Rajan (Infosys SP · SEN004)',
            color: 'from-teal-600 to-emerald-700',
            progressText: `${storageService.getQuestions().length} Questions Curated`,
        },
        {
            id: 'practiceStudio',
            num: '06',
            name: 'Practice Studio',
            desc: 'Interactive quiz simulator with instant answer verification. Every attempt updates your readiness.',
            icon: PlayCircle,
            assignedMentor: 'Deepa Rajan (SEN004)',
            color: 'from-blue-600 to-blue-800',
            progressText: `${progress?.questionsAttempted || 0} Questions Solved`,
        },
        {
            id: 'dailyChallenges',
            num: '07',
            name: 'Daily Challenges',
            desc: 'Daily placement challenge puzzle to earn XP and maintain your consecutive study streak.',
            icon: Flame,
            assignedMentor: 'Sanjay Vignesh (SEN007)',
            color: 'from-rose-600 to-orange-600',
            progressText: `${progress?.dailyChallengesCompleted || 0} Solved (${progress?.studyStreakDays || 0}d streak)`,
        },
        {
            id: 'codingArena',
            num: '08',
            name: 'Coding Arena',
            desc: 'Algorithmic problem solving in JavaScript, Python, or Java with hidden test case evaluation.',
            icon: Terminal,
            assignedMentor: 'Deepa Rajan (SEN004)',
            color: 'from-slate-800 to-slate-950',
            progressText: `${progress?.codingProblemsSolved || 0} Problems Cleared`,
        },
        {
            id: 'aptitudePractice',
            num: '09',
            name: 'Aptitude Practice',
            desc: 'Quantitative aptitude, logical deductions, and verbal ability with step-by-step shortcuts.',
            icon: Calculator,
            assignedMentor: 'Karthik Raja S (SEN003)',
            color: 'from-cyan-700 to-blue-800',
            progressText: `${progress?.aptitudeSolved || 0} Solved`,
        },
        {
            id: 'mockInterviews',
            num: '10',
            name: 'Mock Interviews',
            desc: '1-on-1 technical and HR mock interviews with placed seniors. Receive instant rubric evaluations.',
            icon: Video,
            assignedMentor: 'Sanjay Vignesh (Amazon SDE · SEN007)',
            color: 'from-purple-700 to-indigo-800',
            progressText: `${progress?.mockInterviewsAttended || 0} Sessions Attended`,
        },
        {
            id: 'mockGD',
            num: '11',
            name: 'Mock GD',
            desc: 'Group Discussion cohorts with senior evaluators scoring clarity, body language, and leadership.',
            icon: Users,
            assignedMentor: 'Karthik Raja S (SEN003)',
            color: 'from-blue-700 to-violet-800',
            progressText: `${progress?.mockGDsAttended || 0} Cohorts Completed`,
        },
        {
            id: 'mentorship',
            num: '12',
            name: 'Mentorship',
            desc: 'Mentor matching system. Book 1-on-1 guidance calls and submit doubts to specialized placed seniors.',
            icon: Compass,
            assignedMentor: 'All Placed Seniors (SEN001-SEN009)',
            color: 'from-emerald-700 to-teal-800',
            progressText: `${progress?.mentorshipSessionsAttended || 0} Guidance Calls`,
        },
        {
            id: 'peerCircle',
            num: '13',
            name: 'Peer Circle',
            desc: 'Collaborative student forum to discuss doubts, share off-campus drive referrals, and form study groups.',
            icon: MessageSquare,
            assignedMentor: 'College Peer Network',
            color: 'from-slate-700 to-slate-900',
            progressText: `${storageService.getPeerPosts().length} Discussions Active`,
        },
        {
            id: 'studyPlanner',
            num: '14',
            name: 'Study Planner',
            desc: 'Placement preparation checklist and daily milestones. Completed tasks directly advance your readiness.',
            icon: CalendarCheck,
            assignedMentor: 'Self & Mentor Guidance',
            color: 'from-indigo-700 to-blue-900',
            progressText: `${progress?.studyGoalsCompleted || 0} Goals Achieved`,
        },
        {
            id: 'performanceAnalytics',
            num: '15',
            name: 'Performance Analytics',
            desc: 'Comprehensive accuracy analysis, preparation distribution, and live readiness calculation engine.',
            icon: BarChart3,
            assignedMentor: 'Placement Cell Analytics',
            color: 'from-blue-900 to-indigo-950',
            progressText: `${progress?.readinessScore || 0}% Readiness Index`,
        },
        {
            id: 'leaderboard',
            num: '16',
            name: 'Leaderboard',
            desc: 'College-wide rankings based on genuine practice scores, daily challenge streaks, and mock sessions.',
            icon: Trophy,
            assignedMentor: 'NEC Training & Placement Cell',
            color: 'from-amber-600 to-yellow-600',
            progressText: 'Dynamic Real-Time Rankings',
        },
        {
            id: 'upcomingSessions',
            num: '17',
            name: 'Upcoming Sessions',
            desc: 'Schedule and active room links for your upcoming mock interviews, GDs, and mentorship calls.',
            icon: Calendar,
            assignedMentor: 'Placed Mentors Schedule',
            color: 'from-blue-800 to-indigo-900',
            progressText: 'Syncs with Google Meet',
        },
        {
            id: 'feedbackJournal',
            num: '18',
            name: 'Feedback Journal & Rewinders',
            desc: 'Chronological evaluation log and rewinders dashboard to analyze feedback notes and growth over time.',
            icon: History,
            assignedMentor: 'Archived Mentor Reviews',
            color: 'from-slate-800 to-zinc-900',
            progressText: 'Historical Growth Timeline',
        },
    ];
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-blue-950 via-blue-900 to-indigo-950 text-white shadow-md">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="w-5 h-5 text-amber-400"/>
          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
            Workspace Core Directory
          </span>
        </div>
        <h2 className="text-2xl font-black tracking-tight">The 18 Placement Preparation Modules</h2>
        <p className="text-xs text-blue-200 mt-1 max-w-2xl leading-relaxed">
          Every module is fully interactive, connected to our relational database, and maintained by specialized placed seniors from National Engineering College.
        </p>
      </div>

      {/* 18-Module Clean Responsive Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {modules.map((m) => {
            const Icon = m.icon;
            return (<div key={m.id} className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-blue-400 hover:shadow-md transition-all flex flex-col justify-between p-5 text-xs group">
              <div>
                {/* Module Number and Icon Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className={`w-10 h-10 rounded-xl bg-linear-to-tr ${m.color} text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform`}>
                    <Icon className="w-5 h-5"/>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-slate-400">
                    MOD #{m.num}
                  </span>
                </div>

                {/* Name & Description */}
                <h3 className="font-bold text-sm text-slate-900 group-hover:text-blue-900 transition-colors leading-tight mb-1.5">
                  {m.name}
                </h3>
                <p className="text-slate-600 leading-relaxed line-clamp-2 mb-3">
                  {m.desc}
                </p>

                {/* Assigned Senior Mentor */}
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] space-y-0.5 mb-3">
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                    Specialized Lead:
                  </span>
                  <p className="font-semibold text-slate-800 truncate">{m.assignedMentor}</p>
                </div>
              </div>

              {/* Progress & Open Action */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between mt-1">
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 truncate max-w-[140px]">
                  {m.progressText}
                </span>

                <button onClick={() => onOpenModule(m.id)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition cursor-pointer shadow-2xs text-[11px]">
                  <span>Open</span>
                  <ArrowRight className="w-3.5 h-3.5"/>
                </button>
              </div>
            </div>);
        })}
      </div>
    </div>);
};
