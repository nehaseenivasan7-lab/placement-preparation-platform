import React, { useState, useEffect } from 'react';
import { Flame, Video, Users, ArrowRight, Sparkles, BookOpen, Building2, Clock, TrendingUp, FileText, Layers, HelpCircle, Terminal, Trophy, UserCheck, MessageSquare, History, BellRing, CalendarCheck, } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { storageService } from '../../services/storage';
export const HubView = ({ onOpenModule, onOpenSettings }) => {
    const { user } = useAuth();
    const { t } = useTheme();
    const [progress, setProgress] = useState(null);
    const [recentlyAccessed, setRecentlyAccessed] = useState([]);
    const [targetCompanies, setTargetCompanies] = useState([]);
    useEffect(() => {
        if (user) {
            setProgress(storageService.getUserProgress(user.id));
            setRecentlyAccessed(storageService.getRecentlyAccessed(user.id));
            const allCompanies = storageService.getCompanies();
            const matched = allCompanies.filter((c) => user.preferredCompanies?.some((pc) => c.name.toLowerCase().includes(pc.toLowerCase())));
            setTargetCompanies(matched.length > 0 ? matched : allCompanies.slice(0, 3));
        }
    }, [user]);
    if (!progress || !user)
        return null;
    const isJunior = user.role === 'junior';
    const isPreFinal = user.role === 'pre_final';
    // 18 Pre-Final Core Preparation Modules
    const preFinalModules = [
        {
            id: 'companyExplorer',
            title: 'Company Explorer',
            description: 'Detailed company information, eligibility criteria, job roles, recruitment processes, and CTC packages.',
            icon: Building2,
            category: 'Explore',
            badge: '40+ Recruiter Profiles',
            color: 'blue',
        },
        {
            id: 'companyPlaybook',
            title: 'Company Playbook',
            description: 'Company-specific preparation strategies, high-yield technical topics, coding patterns, and round blueprints.',
            icon: BookOpen,
            category: 'Strategy',
            badge: 'Zoho, TCS, Infosys, CTS',
            color: 'indigo',
        },
        {
            id: 'interviewExperiences',
            title: 'Interview Experiences',
            description: 'Senior & alumni real interview experiences with actual questions, round patterns, difficulty, and tips.',
            icon: FileText,
            category: 'Insights',
            badge: 'Verified Senior Transcripts',
            color: 'purple',
        },
        {
            id: 'roundResources',
            title: 'Recruitment Round Hub',
            description: 'Dedicated active resources & downloadable guides for Aptitude, Coding, Technical, HR, and Group Discussion.',
            icon: Layers,
            category: 'Resources',
            badge: 'Formula & Concept Sheets',
            color: 'teal',
        },
        {
            id: 'questionBank',
            title: 'Advanced Question Bank',
            description: 'High-frequency DSA, coding, SQL, DBMS, OS, Computer Networks, OOP, and quantitative aptitude questions.',
            icon: HelpCircle,
            category: 'Practice',
            badge: 'Company Tagged MCQs',
            color: 'cyan',
        },
        {
            id: 'practiceStudio',
            title: 'Practice Studio',
            description: 'Timed coding assessments, section-wise aptitude tests, DSA practice, and company mock assessments.',
            icon: Terminal,
            category: 'Test Arena',
            badge: 'Live Code & Aptitude Runner',
            color: 'emerald',
        },
        {
            id: 'dailyChallenges',
            title: 'Daily Placement Challenges',
            description: 'Daily DSA problems, coding snippets, quantitative problems, SQL queries, and interview thought exercises.',
            icon: Flame,
            category: 'Consistency',
            badge: `${progress.studyStreakDays} Day Streak`,
            color: 'amber',
        },
        {
            id: 'mockInterviews',
            title: 'Mock Interview Lab',
            description: '1-on-1 Technical, HR, and behavioral mock interviews with live Google Meet integration and scoring rubrics.',
            icon: Video,
            category: 'Simulate',
            badge: 'Google Meet Connected',
            color: 'rose',
        },
        {
            id: 'mockGD',
            title: 'Mock GD Arena',
            description: 'Placement-style group discussions with performance evaluations, timer rounds, and structured feedback.',
            icon: Users,
            category: 'Communication',
            badge: 'Active Topic Discussions',
            color: 'indigo',
        },
        {
            id: 'mentorship',
            title: 'Mentorship Hub',
            description: 'Connect with placed seniors and alumni for company preparation, resume review, and interview roadmaps.',
            icon: UserCheck,
            category: 'Mentors',
            badge: 'Book Senior 1:1',
            color: 'blue',
        },
        {
            id: 'peerCircle',
            title: 'Peer Preparation Circle',
            description: 'Collaborative student circles to discuss coding solutions, upcoming on-campus drives, and preparation tactics.',
            icon: MessageSquare,
            category: 'Peer Study',
            badge: 'Batch 2027 Circle',
            color: 'teal',
        },
        {
            id: 'performanceAnalytics',
            title: 'Placement Readiness Analytics',
            description: 'Detailed analytics tracking coding, aptitude, core technical mastery, mock scores, and Day-1 eligibility.',
            icon: TrendingUp,
            category: 'Metrics',
            badge: `${progress.readinessScore}% Campus Ready`,
            color: 'emerald',
        },
        {
            id: 'studyPlanner',
            title: 'Placement Study Planner',
            description: 'Create a structured personal placement schedule, manage preparation milestones, and track deadlines.',
            icon: CalendarCheck,
            category: 'Schedule',
            badge: 'Active Goal Tracker',
            color: 'sky',
        },
        {
            id: 'leaderboard',
            title: 'Preparation Leaderboard',
            description: 'Compare preparation consistency, challenges solved, assessment scores, and streak across branches.',
            icon: Trophy,
            category: 'Rankings',
            badge: 'College-wide Ranks',
            color: 'amber',
        },
        {
            id: 'upcomingSessions',
            title: 'Upcoming Placement Sessions',
            description: 'Schedule for upcoming technical mock interviews, company pre-placement talks, and GD sessions.',
            icon: Clock,
            category: 'Calendar',
            badge: 'Live Drive Timetable',
            color: 'violet',
        },
        {
            id: 'feedbackJournal',
            title: 'Feedback Journal',
            description: 'Record and review mentor feedback, mock interview evaluations, and targeted areas of improvement.',
            icon: Sparkles,
            category: 'Reflect',
            badge: 'Personal Assessment Notes',
            color: 'fuchsia',
        },
    ];
    // Live Placement Reminders
    const placementReminders = [
        {
            id: 'rem_1',
            title: 'Zoho Corporation - Technical Drive Registration',
            deadline: 'Tomorrow, 5:00 PM',
            type: 'Drive Registration',
            urgent: true,
            role: 'Member Technical Staff (8.5 LPA)',
        },
        {
            id: 'rem_2',
            title: 'TCS Digital Mock Coding Assessment #3',
            deadline: 'Oct 08, 10:00 AM',
            type: 'Mock Assessment',
            urgent: false,
            role: 'Timed 90-min Pattern Test',
        },
        {
            id: 'rem_3',
            title: 'Mock GD Round: Impact of AI on Software Engineering',
            deadline: 'Oct 10, 3:30 PM',
            type: 'Mock GD Arena',
            urgent: false,
            role: 'Seminar Hall 2 / Online',
        },
        {
            id: 'rem_4',
            title: 'Cognizant GenC Next Aptitude Screening',
            deadline: 'Oct 14, 11:00 AM',
            type: 'Company Assessment',
            urgent: false,
            role: 'Aptitude & Automata Fix',
        },
    ];
    return (<div className="space-y-6">
      {/* Pre-Final Year Placement Accelerator Header */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-slate-900 via-indigo-950 to-blue-950 text-white border border-slate-800 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300 bg-amber-400/20 px-2.5 py-1 rounded-full border border-amber-300/30">
              ⚡ Pre-Final Year (Batch 2027) • Placement Preparation Workspace
            </span>
            <span className="text-xs text-slate-300 font-mono">Roll: {user.rollNumber || user.email}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Welcome, {user.name}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            National Engineering College • Master end-to-end recruitment rounds: Explore company playbooks, crack advanced coding & aptitude in Practice Studio, and simulate live interviews.
          </p>

          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button onClick={() => onOpenModule('practiceStudio')} className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-2 shadow-xs">
              <Terminal className="w-4 h-4"/>
              <span>Launch Practice Studio</span>
              <ArrowRight className="w-3.5 h-3.5"/>
            </button>
            <button onClick={() => onOpenModule('roundResources')} className="px-4 py-2.5 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-2 shadow-xs">
              <Layers className="w-4 h-4 text-blue-200"/>
              <span>Recruitment Round Hub</span>
            </button>
            <button onClick={() => onOpenModule('mockInterviews')} className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-white text-xs font-medium rounded-xl border border-white/20 transition cursor-pointer flex items-center gap-2">
              <Video className="w-4 h-4 text-purple-300"/>
              <span>Mock Interview Lab</span>
            </button>
          </div>
        </div>

        {/* Real-time Readiness Dial */}
        <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700 text-center w-full sm:w-60 shrink-0 flex sm:flex-col items-center justify-between sm:justify-center gap-4 shadow-inner">
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path className="text-slate-700" strokeWidth="3.5" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
              <path className="text-amber-400 transition-all duration-700" strokeDasharray={`${progress.readinessScore}, 100`} strokeWidth="3.5" strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
            </svg>
            <div className="absolute text-center">
              <span className="text-lg font-black text-white">{progress.readinessScore}%</span>
            </div>
          </div>
          <div className="text-left sm:text-center">
            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Placement Readiness</p>
            <p className="text-xs text-emerald-400 font-bold mt-0.5">
              {progress.readinessScore >= 70 ? 'Eligible for Day-1 Drives' : 'Strengthen Technical MCQs'}
            </p>
          </div>
        </div>
      </div>

      {/* Real-Time Metric Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Questions Attempted</p>
          <p className="text-2xl font-black text-slate-900 mt-1">{progress.questionsAttempted}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Aptitude & Technical</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Coding Problems Solved</p>
          <p className="text-2xl font-black text-emerald-600 mt-1">{progress.codingProblemsSolved || 28}</p>
          <p className="text-[10px] text-emerald-700 mt-0.5">LeetCode & NEC Arena</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Mock Interviews</p>
          <p className="text-2xl font-black text-blue-600 mt-1">{progress.mockInterviewsAttended}</p>
          <p className="text-[10px] text-blue-700 mt-0.5">1:1 Senior Evaluations</p>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <p className="text-xs text-slate-500 font-medium">Study Streak</p>
          <p className="text-2xl font-black text-amber-600 mt-1">{progress.studyStreakDays} Days</p>
          <p className="text-[10px] text-amber-700 mt-0.5">Consistency Badge</p>
        </div>
      </div>

      {/* Two-Column Utility Bar: 17. Recently Accessed & 18. Placement Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        {/* 17. RECENTLY ACCESSED */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <History className="w-4 h-4 text-blue-600"/>
                <span>Recently Accessed Materials</span>
              </div>
              <span className="text-[10px] bg-blue-50 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                Quick Resume
              </span>
            </div>

            <div className="divide-y divide-slate-100 mt-2">
              {recentlyAccessed.length > 0 ? (recentlyAccessed.slice(0, 4).map((item, idx) => (<div key={idx} onClick={() => onOpenModule(item.link || 'practiceStudio')} className="py-2.5 flex items-center justify-between hover:bg-slate-50 rounded-lg px-2 transition cursor-pointer">
                    <div>
                      <p className="font-bold text-slate-800 text-xs">{item.title}</p>
                      <p className="text-[11px] text-slate-500 capitalize">{item.subtext}</p>
                    </div>
                    <span className="text-blue-600 font-semibold text-[11px] flex items-center gap-1">
                      <span>Open</span>
                      <ArrowRight className="w-3 h-3"/>
                    </span>
                  </div>))) : (<div className="py-4 text-center text-slate-400">
                  No recently accessed materials yet. Jump into any module below!
                </div>)}
            </div>
          </div>
          <button onClick={() => onOpenModule('questionBank')} className="w-full mt-3 py-2 text-center text-blue-600 font-bold bg-blue-50/70 hover:bg-blue-100 rounded-xl transition cursor-pointer">
            Explore Question Bank →
          </button>
        </div>

        {/* 18. PLACEMENT REMINDERS */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <BellRing className="w-4 h-4 text-amber-500"/>
                <span>Placement Reminders & Deadlines</span>
              </div>
              <span className="text-[10px] bg-amber-50 text-amber-800 font-bold px-2 py-0.5 rounded-full">
                Active Alerts
              </span>
            </div>

            <div className="space-y-2.5 mt-3">
              {placementReminders.map((rem) => (<div key={rem.id} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-2 h-2 rounded-full ${rem.urgent ? 'bg-rose-500 animate-pulse' : 'bg-blue-500'}`}/>
                    <div>
                      <p className="font-bold text-slate-900 text-xs">{rem.title}</p>
                      <p className="text-[11px] text-slate-500">{rem.role}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${rem.urgent
                ? 'bg-rose-100 text-rose-800'
                : 'bg-slate-200 text-slate-700'}`}>
                      {rem.deadline}
                    </span>
                  </div>
                </div>))}
            </div>
          </div>

          <button onClick={() => onOpenModule('upcomingSessions')} className="w-full mt-3 py-2 text-center text-amber-700 font-bold bg-amber-50/70 hover:bg-amber-100 rounded-xl transition cursor-pointer">
            View All Drives & Sessions →
          </button>
        </div>
      </div>

      {/* Complete 16 Pre-Final Year Core Modules Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-black text-slate-900 text-base">
              Pre-Final Year Comprehensive Preparation Ecosystem
            </h3>
            <span className="text-[11px] font-bold bg-blue-100 text-blue-900 px-2 py-0.5 rounded-full">
              16 Active Modules
            </span>
          </div>
          <span className="text-xs text-slate-500">Click any card to launch real-time module</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {preFinalModules.map((mod) => {
            const Icon = mod.icon;
            return (<div key={mod.id} onClick={() => onOpenModule(mod.id)} className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md transition-all duration-200 flex flex-col justify-between cursor-pointer group">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 group-hover:bg-blue-600 text-blue-900 group-hover:text-white flex items-center justify-center transition-colors">
                      <Icon className="w-5 h-5"/>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                      {mod.category}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-slate-900 group-hover:text-blue-900 transition-colors">
                    {mod.title}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    {mod.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between text-xs">
                  <span className="text-[10px] font-semibold text-slate-500 truncate max-w-[130px]">
                    {mod.badge}
                  </span>
                  <span className="font-bold text-blue-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-1 text-[11px]">
                    <span>Open</span>
                    <ArrowRight className="w-3 h-3"/>
                  </span>
                </div>
              </div>);
        })}
        </div>
      </div>
    </div>);
};
