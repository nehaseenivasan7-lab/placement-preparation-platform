import React, { useState } from 'react';
import { ShieldCheck, Search, BarChart2, Building2, Mail, Send, Video, Plus, Clock, Download, Check, } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useTheme } from '../../context/ThemeContext';
export const AdminWorkspaceView = () => {
    const { t, themeColor, language } = useTheme();
    const [users, setUsers] = useState(() => storageService.getUsers());
    const [search, setSearch] = useState('');
    const [activeAdminTab, setActiveAdminTab] = useState('junior');
    const [selectedStudent, setSelectedStudent] = useState(null);
    // Direct 1-on-1 Student Message State
    const [directRecipientId, setDirectRecipientId] = useState('');
    const [directMessageSubject, setDirectMessageSubject] = useState('Placement Cell Feedback & Action Items');
    const [directMessageText, setDirectMessageText] = useState('Hello, Please review your recent practice test score in the portal and ensure you complete the mock coding problem before Friday.');
    const [directMsgSuccess, setDirectMsgSuccess] = useState('');
    const [directMessagesHistory, setDirectMessagesHistory] = useState([
        {
            id: 1,
            recipientName: 'Anandha Selvan (CSE)',
            subject: 'Review on Zoho Mock Coding Round',
            body: 'Great performance in round 1! Please practice graph traversals and tree problems for round 2.',
            sentAt: 'Today, 11:20 AM',
        },
        {
            id: 2,
            recipientName: 'Bavithra K (IT)',
            subject: 'TCS Digital Resume Verification',
            body: 'Your resume has been verified and shortlisted for the technical round.',
            sentAt: 'Yesterday, 02:40 PM',
        },
    ]);
    // Live Student Practice Activity Monitoring State
    const [recentStudentActivities] = useState([
        { id: 1, student: 'Anandha Selvan (CSE)', activity: 'Solved Coding Problem: Variables & Logic (+25 XP)', time: '4 mins ago', tag: 'Coding Studio' },
        { id: 2, student: 'Bavithra K (IT)', activity: 'Scored 5/6 in Quantitative Speed Math Test', time: '12 mins ago', tag: 'Aptitude Arena' },
        { id: 3, student: 'Karthik Raja M (ECE)', activity: 'Completed Git Simulator Terminal Challenge', time: '28 mins ago', tag: 'Skill Builder' },
        { id: 4, student: 'Divya Bharathi S (AI&DS)', activity: 'Booked Mock Interview with Zoho Senior Mentor', time: '45 mins ago', tag: 'Mentorship' },
        { id: 5, student: 'Muthu Kumar P (Mech)', activity: 'Submitted SQL Query Studio Test Case 3', time: '1 hour ago', tag: 'Database Lab' },
    ]);
    // Broadcast Email State
    const [broadcastTarget, setBroadcastTarget] = useState('all');
    const [broadcastSubject, setBroadcastSubject] = useState('Campus Recruitment Drive Notice: Registration Deadline');
    const [broadcastMessage, setBroadcastMessage] = useState('Dear Students,\n\nPlease note that registration for the upcoming campus recruitment drive closes tomorrow at 5:00 PM. Verify that your placement profile and resume are updated in the portal.\n\nPlacement & Training Cell\nNational Engineering College');
    const [broadcastSuccessMsg, setBroadcastSuccessMsg] = useState('');
    const [outboxHistory, setOutboxHistory] = useState([
        {
            id: 1,
            subject: 'Zoho Corporation On-Campus Drive Announced (Batch 2026)',
            target: '3rd Year Pre-Final',
            sentAt: 'Today, 09:30 AM',
            recipients: 142,
        },
        {
            id: 2,
            subject: 'Junior Foundation DSA & Aptitude Bootcamp Starting Monday',
            target: '2nd Year Juniors',
            sentAt: 'Yesterday, 04:15 PM',
            recipients: 180,
        },
    ]);
    // Live Session Scheduler State
    const [liveSessions, setLiveSessions] = useState([
        {
            id: 1,
            title: 'Zoho Technical Round Coding Patterns & Strategy',
            speaker: 'Priya Dharshini (Zoho MTS • Senior Mentor)',
            date: 'Tomorrow, 06:00 PM',
            platform: 'Google Meet',
            link: 'https://meet.google.com/nec-zoho-prep',
            target: 'Pre-Final & Senior',
            capacity: '200 Seats',
        },
        {
            id: 2,
            title: 'Cracking TCS NQT Speed Math & Cognitive Logic',
            speaker: 'Dr. K. Kalidasa Murugavel (Placement Officer)',
            date: 'Oct 15, 05:00 PM',
            platform: 'Auditorium / Hybrid',
            link: 'Seminar Hall 1',
            target: '2nd Year Juniors',
            capacity: '350 Seats',
        },
    ]);
    const [newSessionTitle, setNewSessionTitle] = useState('');
    const [newSessionSpeaker, setNewSessionSpeaker] = useState('');
    const [newSessionDate, setNewSessionDate] = useState('');
    const [newSessionLink, setNewSessionLink] = useState('https://meet.google.com/nec-live');
    const [newSessionTarget, setNewSessionTarget] = useState('All Students');
    const [sessionSuccessMsg, setSessionSuccessMsg] = useState('');
    // Placement Drive State
    const [placementDrives, setPlacementDrives] = useState([
        {
            id: 1,
            company: 'Zoho Corporation',
            role: 'Member Technical Staff (MTS)',
            ctc: '₹8.40 LPA',
            eligibility: 'CGPA 7.0+, Zero Arrears',
            deadline: 'Oct 20, 2026',
            status: 'Accepting Applications',
        },
        {
            id: 2,
            company: 'TCS (Digital / Prime)',
            role: 'Digital Software Engineer',
            ctc: '₹7.00 - 9.00 LPA',
            eligibility: 'CGPA 6.5+, Circuit Branches',
            deadline: 'Oct 28, 2026',
            status: 'Upcoming',
        },
    ]);
    const [newDriveCompany, setNewDriveCompany] = useState('');
    const [newDriveRole, setNewDriveRole] = useState('');
    const [newDriveCtc, setNewDriveCtc] = useState('');
    const [newDriveEligibility, setNewDriveEligibility] = useState('');
    const [newDriveDeadline, setNewDriveDeadline] = useState('');
    const [driveSuccessMsg, setDriveSuccessMsg] = useState('');
    const juniorStudents = users.filter((u) => u.role === 'junior');
    const preFinalStudents = users.filter((u) => u.role === 'pre_final');
    const seniorMentors = users.filter((u) => u.role === 'senior');
    const filterList = (list) => {
        return list.filter((u) => u.name.toLowerCase().includes(search.toLowerCase()) ||
            u.email.toLowerCase().includes(search.toLowerCase()) ||
            (u.seniorId && u.seniorId.toLowerCase().includes(search.toLowerCase())) ||
            (u.department && u.department.toLowerCase().includes(search.toLowerCase())));
    };
    const handleSendBroadcast = (e) => {
        e.preventDefault();
        if (!broadcastSubject || !broadcastMessage)
            return;
        const count = broadcastTarget === 'all'
            ? users.length
            : broadcastTarget === 'junior'
                ? juniorStudents.length
                : broadcastTarget === 'pre_final'
                    ? preFinalStudents.length
                    : seniorMentors.length;
        const newOutbox = {
            id: Date.now(),
            subject: broadcastSubject,
            target: broadcastTarget === 'all'
                ? 'All Students'
                : broadcastTarget === 'junior'
                    ? '2nd Year Juniors'
                    : broadcastTarget === 'pre_final'
                        ? '3rd Year Pre-Final'
                        : 'Senior Mentors',
            sentAt: 'Just now',
            recipients: count,
        };
        setOutboxHistory([newOutbox, ...outboxHistory]);
        setBroadcastSuccessMsg(`✓ Broadcast email successfully dispatched to ${count} students!`);
        setTimeout(() => setBroadcastSuccessMsg(''), 4000);
    };
    const handleSendDirectMessage = (e) => {
        e.preventDefault();
        if (!directMessageText.trim())
            return;
        const targetUser = users.find((u) => u.id === directRecipientId) || users[0];
        const newMsg = {
            id: Date.now(),
            recipientName: `${targetUser.name} (${targetUser.department || 'Student'})`,
            subject: directMessageSubject,
            body: directMessageText,
            sentAt: 'Just now',
        };
        setDirectMessagesHistory([newMsg, ...directMessagesHistory]);
        if (targetUser) {
            storageService.addNotification({
                userId: targetUser.id,
                title: `Placement Cell: ${directMessageSubject}`,
                message: directMessageText,
                type: 'system',
                isRead: false,
            });
        }
        setDirectMsgSuccess(`✓ Direct message sent to ${targetUser.name}! In-app notification delivered.`);
        setDirectMessageText('');
        setTimeout(() => setDirectMsgSuccess(''), 4500);
    };
    const handleScheduleSession = (e) => {
        e.preventDefault();
        if (!newSessionTitle || !newSessionSpeaker)
            return;
        const newSess = {
            id: Date.now(),
            title: newSessionTitle,
            speaker: newSessionSpeaker,
            date: newSessionDate || 'Upcoming This Week',
            platform: 'Google Meet',
            link: newSessionLink,
            target: newSessionTarget,
            capacity: '250 Seats',
        };
        setLiveSessions([newSess, ...liveSessions]);
        setSessionSuccessMsg('✓ Live session scheduled! Notification broadcast to cohort.');
        setNewSessionTitle('');
        setNewSessionSpeaker('');
        setTimeout(() => setSessionSuccessMsg(''), 4000);
    };
    const handleAddDrive = (e) => {
        e.preventDefault();
        if (!newDriveCompany || !newDriveRole)
            return;
        const newDr = {
            id: Date.now(),
            company: newDriveCompany,
            role: newDriveRole,
            ctc: newDriveCtc || '₹6.50 LPA',
            eligibility: newDriveEligibility || 'CGPA 7.0+',
            deadline: newDriveDeadline || 'Nov 15, 2026',
            status: 'Accepting Applications',
        };
        setPlacementDrives([newDr, ...placementDrives]);
        setDriveSuccessMsg('✓ Placement drive posted! Students can now view and apply.');
        setNewDriveCompany('');
        setNewDriveRole('');
        setNewDriveCtc('');
        setTimeout(() => setDriveSuccessMsg(''), 4000);
    };
    const handleUpdateStudentStatus = (studentId, newStatus) => {
        setUsers((prev) => prev.map((u) => (u.id === studentId ? { ...u, placementStatus: newStatus } : u)));
        if (selectedStudent && selectedStudent.id === studentId) {
            setSelectedStudent({ ...selectedStudent, placementStatus: newStatus });
        }
    };
    const handleExportCSV = () => {
        const csvContent = 'data:text/csv;charset=utf-8,' +
            'Name,Email,Role,Department,CGPA,Placement Status\n' +
            users
                .map((u) => `"${u.name}","${u.email}","${u.role}","${u.department || 'CSE'}","${u.cgpa || 8.0}","${u.placementStatus || 'Active'}"`)
                .join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', 'NEC_Placement_Student_Cohort_Report.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    return (<div className="space-y-6 text-xs animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl text-white shadow-md relative overflow-hidden" style={{
            background: `linear-gradient(135deg, ${themeColor} 0%, #1e1b4b 100%)`,
        }}>
        <div className="flex items-center gap-2 mb-1">
          <ShieldCheck className="w-5 h-5 text-amber-300"/>
          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
            {t('adminCenter', 'Training & Placement Cell Admin Command Center')}
          </span>
        </div>
        <h2 className="text-2xl font-black tracking-tight">
          {t('cohortMonitor', 'Admin Placement Control & Operations Center')}
        </h2>
        <p className="text-xs text-blue-100 mt-1 max-w-2xl leading-relaxed">
          {t('collegeName', 'National Engineering College, Kovilpatti')} • Monitor student cohorts, send broadcast emails, book live sessions, and manage recruitment drives.
        </p>

        {/* Quick Admin Action Bar */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-white/10 flex-wrap">
          <button onClick={() => setActiveAdminTab('broadcast')} className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold transition flex items-center gap-1.5 cursor-pointer">
            <Mail className="w-3.5 h-3.5"/>
            <span>Send Email Broadcast</span>
          </button>
          <button onClick={() => setActiveAdminTab('sessions')} className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold transition flex items-center gap-1.5 cursor-pointer">
            <Video className="w-3.5 h-3.5"/>
            <span>Schedule Live Session</span>
          </button>
          <button onClick={() => setActiveAdminTab('drives')} className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold transition flex items-center gap-1.5 cursor-pointer">
            <Building2 className="w-3.5 h-3.5"/>
            <span>Post Placement Drive</span>
          </button>
          <button onClick={handleExportCSV} className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold transition flex items-center gap-1.5 cursor-pointer ml-auto">
            <Download className="w-3.5 h-3.5"/>
            <span>Export Cohort CSV</span>
          </button>
        </div>
      </div>

      {/* Admin Module Navigation Tabs */}
      <div className="bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center gap-1.5 overflow-x-auto scrollbar-none">
        <button onClick={() => setActiveAdminTab('junior')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'junior'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'junior' ? themeColor : undefined }}>
          <span>🎓 Junior Students (2nd Year)</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-black/10 dark:bg-white/10">
            {juniorStudents.length}
          </span>
        </button>

        <button onClick={() => setActiveAdminTab('pre_final')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'pre_final'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'pre_final' ? themeColor : undefined }}>
          <span>⚡ Pre-Final Students (3rd Year)</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-black/10 dark:bg-white/10">
            {preFinalStudents.length}
          </span>
        </button>

        <button onClick={() => setActiveAdminTab('senior')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'senior'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'senior' ? themeColor : undefined }}>
          <span>🌟 Senior Mentors (Placed)</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-black/10 dark:bg-white/10">
            {seniorMentors.length}
          </span>
        </button>

        <button onClick={() => setActiveAdminTab('broadcast')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'broadcast'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'broadcast' ? themeColor : undefined }}>
          <Mail className="w-3.5 h-3.5"/>
          <span>Broadcast Emails</span>
        </button>

        <button onClick={() => setActiveAdminTab('messages')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'messages'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'messages' ? themeColor : undefined }}>
          <Send className="w-3.5 h-3.5"/>
          <span>Direct Messages</span>
        </button>

        <button onClick={() => setActiveAdminTab('monitor')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'monitor'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'monitor' ? themeColor : undefined }}>
          <BarChart2 className="w-3.5 h-3.5"/>
          <span>Live Activity Monitor</span>
        </button>

        <button onClick={() => setActiveAdminTab('sessions')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'sessions'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'sessions' ? themeColor : undefined }}>
          <Video className="w-3.5 h-3.5"/>
          <span>Book Live Sessions</span>
        </button>

        <button onClick={() => setActiveAdminTab('drives')} className={`px-4 py-2 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer ${activeAdminTab === 'drives'
            ? 'text-white shadow-xs'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`} style={{ backgroundColor: activeAdminTab === 'drives' ? themeColor : undefined }}>
          <Building2 className="w-3.5 h-3.5"/>
          <span>Manage Drives</span>
        </button>
      </div>

      {/* ================= 1. DIRECT 1-ON-1 STUDENT MESSAGING ================= */}
      {activeAdminTab === 'messages' && (<div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-600"/>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">Send Direct Message to Student</h3>
              </div>
              <span className="text-[10px] text-slate-400">In-App Notification & Real-Time Alert</span>
            </div>

            {directMsgSuccess && (<div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600"/>
                <span>{directMsgSuccess}</span>
              </div>)}

            <form onSubmit={handleSendDirectMessage} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Select Specific Student</label>
                <select value={directRecipientId} onChange={(e) => setDirectRecipientId(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs font-semibold dark:text-white outline-none">
                  <option value="">-- Choose a student (Junior, Pre-Final, or Senior) --</option>
                  {users.map((u) => (<option key={u.id} value={u.id}>
                      {u.name} ({u.role.toUpperCase()} • {u.department || 'CSE'} • {u.email})
                    </option>))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Message Subject / Purpose</label>
                <input type="text" required value={directMessageSubject} onChange={(e) => setDirectMessageSubject(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Message Details / Action Requested</label>
                <textarea rows={5} required value={directMessageText} onChange={(e) => setDirectMessageText(e.target.value)} className="w-full p-3 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none leading-relaxed font-mono"/>
              </div>

              <button type="submit" className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2" style={{ backgroundColor: themeColor }}>
                <Send className="w-3.5 h-3.5"/>
                <span>Send Direct Message to Student</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500"/>
              <span>Direct Messages Sent</span>
            </h4>
            <div className="space-y-2">
              {directMessagesHistory.map((m) => (<div key={m.id} className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-900 dark:text-white">{m.recipientName}</span>
                    <span className="text-slate-400">{m.sentAt}</span>
                  </div>
                  <p className="font-semibold text-blue-900 dark:text-blue-300 text-xs">{m.subject}</p>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed line-clamp-2">{m.body}</p>
                </div>))}
            </div>
          </div>
        </div>)}

      {/* ================= 2. LIVE STUDENT ACTIVITY & PRACTICE MONITOR ================= */}
      {activeAdminTab === 'monitor' && (<div className="space-y-5">
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium">Students Practicing Today</span>
              <p className="text-xl font-black text-slate-900 dark:text-white mt-1">184 Active</p>
              <span className="text-[10px] text-emerald-600 font-bold">● Live activity tracked</span>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium">Coding Problems Solved</span>
              <p className="text-xl font-black text-blue-900 dark:text-blue-400 mt-1">1,248 Solved</p>
              <span className="text-[10px] text-slate-400">Past 7 days across campus</span>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium">Avg Aptitude Test Pass Rate</span>
              <p className="text-xl font-black text-emerald-600 mt-1">82.5% Pass</p>
              <span className="text-[10px] text-emerald-600 font-bold">↑ 4.2% from last week</span>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium">Drive Applications</span>
              <p className="text-xl font-black text-purple-600 mt-1">320 Total</p>
              <span className="text-[10px] text-slate-400">Zoho & TCS drives</span>
            </div>
          </div>

          {/* Activity Feed & Department Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-blue-600"/>
                  <span>Real-Time Student Practice Activity Feed</span>
                </h4>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Live</span>
              </div>
              <div className="space-y-2.5">
                {recentStudentActivities.map((act) => (<div key={act.id} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white text-xs">{act.student}</p>
                      <p className="text-slate-600 dark:text-slate-300 text-[11px]">{act.activity}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-900 dark:text-blue-200">
                        {act.tag}
                      </span>
                      <p className="text-[10px] text-slate-400 mt-0.5">{act.time}</p>
                    </div>
                  </div>))}
              </div>
            </div>

            <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Department Placement Readiness</h4>
              <div className="space-y-3">
                {[
                { dept: 'Computer Science & Eng (CSE)', rate: 94, count: '68/72 Ready' },
                { dept: 'Information Technology (IT)', rate: 89, count: '55/62 Ready' },
                { dept: 'Electronics & Comm (ECE)', rate: 82, count: '52/64 Ready' },
                { dept: 'Artificial Intelligence & DS', rate: 91, count: '56/61 Ready' },
                { dept: 'Electrical & Electronics (EEE)', rate: 76, count: '45/59 Ready' },
                { dept: 'Mechanical Engineering', rate: 71, count: '41/58 Ready' },
            ].map((item, idx) => (<div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-slate-800 dark:text-slate-200">{item.dept}</span>
                      <span className="text-slate-500 font-mono text-[11px]">{item.rate}% ({item.count})</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{ width: `${item.rate}%`, backgroundColor: themeColor }}/>
                    </div>
                  </div>))}
              </div>
            </div>
          </div>
        </div>)}

      {/* ================= 1. BROADCAST EMAILS & ANNOUNCEMENTS ================= */}
      {activeAdminTab === 'broadcast' && (<div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-600"/>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">Compose Broadcast Email to Students</h3>
              </div>
              <span className="text-[10px] text-slate-400">SMTP & In-app Delivery</span>
            </div>

            {broadcastSuccessMsg && (<div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600"/>
                <span>{broadcastSuccessMsg}</span>
              </div>)}

            <form onSubmit={handleSendBroadcast} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Target Student Cohort</label>
                <select value={broadcastTarget} onChange={(e) => setBroadcastTarget(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs font-semibold dark:text-white outline-none">
                  <option value="all">All Registered Students (Juniors, Pre-Final, Seniors)</option>
                  <option value="junior">2nd Year Junior Students Only (Batch 2028)</option>
                  <option value="pre_final">3rd Year Pre-Final Students Only (Batch 2027)</option>
                  <option value="senior">Senior Mentors Only (Batch 2026)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Subject Header</label>
                <input type="text" required value={broadcastSubject} onChange={(e) => setBroadcastSubject(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Email Body Message</label>
                <textarea rows={6} required value={broadcastMessage} onChange={(e) => setBroadcastMessage(e.target.value)} className="w-full p-3 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none leading-relaxed font-mono"/>
              </div>

              <button type="submit" className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2" style={{ backgroundColor: themeColor }}>
                <Send className="w-3.5 h-3.5"/>
                <span>Send Broadcast Email to Cohort</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500"/>
              <span>Broadcast Outbox History</span>
            </h4>
            <div className="space-y-2">
              {outboxHistory.map((item) => (<div key={item.id} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-1.5">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-blue-900 dark:text-blue-300 uppercase">{item.target}</span>
                    <span className="text-slate-400">{item.sentAt}</span>
                  </div>
                  <p className="font-bold text-slate-900 dark:text-white text-xs">{item.subject}</p>
                  <p className="text-[11px] text-emerald-600 font-semibold">
                    ✓ Dispatched to {item.recipients} students
                  </p>
                </div>))}
            </div>
          </div>
        </div>)}

      {/* ================= 2. LIVE SESSION SCHEDULER ================= */}
      {activeAdminTab === 'sessions' && (<div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Video className="w-4 h-4 text-purple-600"/>
              <span>Schedule Live Interactive Session</span>
            </h3>

            {sessionSuccessMsg && (<p className="text-xs text-emerald-600 font-bold">{sessionSuccessMsg}</p>)}

            <form onSubmit={handleScheduleSession} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Session Title</label>
                <input type="text" required placeholder="e.g. Masterclass: Cracking Zoho OA Coding" value={newSessionTitle} onChange={(e) => setNewSessionTitle(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Speaker / Mentor</label>
                <input type="text" required placeholder="e.g. Anandha Selvan (Senior MTS)" value={newSessionSpeaker} onChange={(e) => setNewSessionSpeaker(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Date & Time</label>
                <input type="text" placeholder="e.g. Oct 18, 06:30 PM" value={newSessionDate} onChange={(e) => setNewSessionDate(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Meeting Link</label>
                <input type="text" value={newSessionLink} onChange={(e) => setNewSessionLink(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none font-mono"/>
              </div>

              <button type="submit" className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5" style={{ backgroundColor: themeColor }}>
                <Plus className="w-4 h-4"/>
                <span>Schedule Session & Notify Cohort</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Active Scheduled Placement Sessions</h4>
            <div className="space-y-3">
              {liveSessions.map((s) => (<div key={s.id} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-900">
                      {s.target}
                    </span>
                    <span className="text-[11px] font-bold text-slate-500">{s.date}</span>
                  </div>
                  <h5 className="font-bold text-slate-900 dark:text-white text-sm">{s.title}</h5>
                  <p className="text-slate-600 dark:text-slate-300 text-xs">Speaker: {s.speaker}</p>
                  <div className="pt-2 flex items-center justify-between text-[11px]">
                    <span className="font-mono text-blue-900 dark:text-blue-400">{s.link}</span>
                    <span className="text-emerald-600 font-bold">{s.capacity}</span>
                  </div>
                </div>))}
            </div>
          </div>
        </div>)}

      {/* ================= 3. PLACEMENT DRIVES MANAGER ================= */}
      {activeAdminTab === 'drives' && (<div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600"/>
              <span>Post New Campus Placement Drive</span>
            </h3>

            {driveSuccessMsg && (<p className="text-xs text-emerald-600 font-bold">{driveSuccessMsg}</p>)}

            <form onSubmit={handleAddDrive} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Company Name</label>
                <input type="text" required placeholder="e.g. Amazon / Microsoft" value={newDriveCompany} onChange={(e) => setNewDriveCompany(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Job Role</label>
                <input type="text" required placeholder="e.g. SDE-1 / Cloud Consultant" value={newDriveRole} onChange={(e) => setNewDriveRole(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">CTC Package (LPA)</label>
                <input type="text" placeholder="e.g. ₹12.50 LPA" value={newDriveCtc} onChange={(e) => setNewDriveCtc(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">Eligibility Criteria</label>
                <input type="text" placeholder="e.g. CGPA 7.5+, CSE/IT/ECE" value={newDriveEligibility} onChange={(e) => setNewDriveEligibility(e.target.value)} className="w-full px-3 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 text-xs dark:text-white outline-none"/>
              </div>

              <button type="submit" className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5" style={{ backgroundColor: themeColor }}>
                <Plus className="w-4 h-4"/>
                <span>Post Drive for Campus</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Active On-Campus Drives</h4>
            <div className="space-y-3">
              {placementDrives.map((d) => (<div key={d.id} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">{d.company}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {d.ctc}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-xs">Role: {d.role} • {d.eligibility}</p>
                  <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Deadline: {d.deadline}</span>
                    <span className="text-blue-900 dark:text-blue-400 font-bold">{d.status}</span>
                  </div>
                </div>))}
            </div>
          </div>
        </div>)}

      {/* ================= 4. STUDENT COHORT TABLES WITH CONTROLS ================= */}
      {(activeAdminTab === 'junior' || activeAdminTab === 'pre_final' || activeAdminTab === 'senior') && (<div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
              <input type="text" placeholder="Search students by name, roll number, or department..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 border rounded-xl bg-slate-50 dark:bg-slate-800 dark:border-slate-700 outline-none text-xs dark:text-white"/>
            </div>

            <div className="text-xs font-semibold text-slate-500">
              Showing {filterList(activeAdminTab === 'junior' ? juniorStudents : activeAdminTab === 'pre_final' ? preFinalStudents : seniorMentors).length} students in cohort
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                <tr>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Roll / ID</th>
                  <th className="p-3">Department</th>
                  <th className="p-3">CGPA</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Admin Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filterList(activeAdminTab === 'junior' ? juniorStudents : activeAdminTab === 'pre_final' ? preFinalStudents : seniorMentors).map((student) => (<tr key={student.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td className="p-3">
                      <div className="font-bold text-slate-900 dark:text-white">{student.name}</div>
                      <div className="text-[10px] text-slate-400">{student.email}</div>
                    </td>
                    <td className="p-3 font-mono font-semibold text-slate-700 dark:text-slate-300">
                      {student.rollNumber || student.seniorId || '24104009'}
                    </td>
                    <td className="p-3 text-slate-600 dark:text-slate-400">
                      {student.department || 'Computer Science'}
                    </td>
                    <td className="p-3 font-bold text-blue-900 dark:text-blue-400">
                      {student.cgpa || 8.4}
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {student.placementStatus || 'Eligible'}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-1">
                      <button onClick={() => setSelectedStudent(student)} className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-900/40 text-blue-900 dark:text-blue-200 font-bold hover:bg-blue-100 cursor-pointer">
                        Manage
                      </button>
                      <button onClick={() => handleUpdateStudentStatus(student.id, 'Day-1 Approved')} className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 font-bold hover:bg-emerald-100 cursor-pointer">
                        Approve
                      </button>
                    </td>
                  </tr>))}
              </tbody>
            </table>
          </div>
        </div>)}

      {/* Student Management Modal */}
      {selectedStudent && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b dark:border-slate-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Student Placement Profile & Controls</h3>
              <button onClick={() => setSelectedStudent(null)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <p><strong>Name:</strong> {selectedStudent.name}</p>
              <p><strong>Email:</strong> {selectedStudent.email}</p>
              <p><strong>Roll Number:</strong> {selectedStudent.rollNumber || selectedStudent.seniorId}</p>
              <p><strong>Role Cohort:</strong> {selectedStudent.role}</p>
              <p><strong>Current Status:</strong> {selectedStudent.placementStatus || 'Active'}</p>
            </div>

            <div className="pt-2 border-t dark:border-slate-800 space-y-2">
              <p className="font-bold text-slate-800 dark:text-slate-200">Change Placement Eligibility Status:</p>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handleUpdateStudentStatus(selectedStudent.id, 'Day-1 Approved')} className="py-2 bg-emerald-600 text-white font-bold rounded-xl cursor-pointer">
                  Day-1 Approved
                </button>
                <button onClick={() => handleUpdateStudentStatus(selectedStudent.id, 'Needs Remedial')} className="py-2 bg-amber-600 text-white font-bold rounded-xl cursor-pointer">
                  Needs Remedial
                </button>
                <button onClick={() => handleUpdateStudentStatus(selectedStudent.id, 'Placed in Zoho')} className="py-2 bg-blue-600 text-white font-bold rounded-xl cursor-pointer">
                  Mark Placed
                </button>
                <button onClick={() => handleUpdateStudentStatus(selectedStudent.id, 'Under Review')} className="py-2 bg-slate-600 text-white font-bold rounded-xl cursor-pointer">
                  Under Review
                </button>
              </div>

              <button onClick={() => {
                setDirectRecipientId(selectedStudent.id);
                setDirectMessageSubject(`Placement Notice for ${selectedStudent.name}`);
                setActiveAdminTab('messages');
                setSelectedStudent(null);
            }} className="w-full py-2.5 mt-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-xs" style={{ backgroundColor: themeColor }}>
                <Send className="w-3.5 h-3.5"/>
                <span>Send Direct Message to Student</span>
              </button>
            </div>
          </div>
        </div>)}
    </div>);
};
