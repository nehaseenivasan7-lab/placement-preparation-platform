import React, { useState, useEffect, useRef } from 'react';
import { GraduationCap, ArrowRight, ShieldCheck, Users, Building2, BookOpen, TrendingUp, ExternalLink, Camera, RotateCcw, } from 'lucide-react';
import { COLLEGE_IMAGES, getEffectiveHeroImage, setCustomHeroImage, resetCustomHeroImage, USER_CUSTOM_IMAGE_KEY, } from '../../assets/collegeImages';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
export const NecHomePage = ({ onEnterWorkspace }) => {
    const { user, isAuthenticated } = useAuth();
    const { t, language } = useTheme();
    const fileInputRef = useRef(null);
    const [heroImage, setHeroImage] = useState(getEffectiveHeroImage());
    const [hasCustomImage, setHasCustomImage] = useState(false);
    const [isFullViewOpen, setIsFullViewOpen] = useState(false);
    useEffect(() => {
        const updateImage = () => {
            setHeroImage(getEffectiveHeroImage());
            setHasCustomImage(Boolean(localStorage.getItem(USER_CUSTOM_IMAGE_KEY)));
        };
        updateImage();
        window.addEventListener('nec_hero_image_updated', updateImage);
        return () => window.removeEventListener('nec_hero_image_updated', updateImage);
    }, []);
    const handleImageFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                if (event.target?.result) {
                    setCustomHeroImage(event.target.result);
                }
            };
            reader.readAsDataURL(file);
        }
    };
    const handleResetImage = (e) => {
        e.stopPropagation();
        resetCustomHeroImage();
    };
    return (<div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Academic Accreditation Bar */}
      <div className="bg-blue-950 text-amber-300 text-[11px] font-semibold px-4 py-1.5 flex flex-wrap items-center justify-between border-b border-blue-900/60">
        <div className="flex items-center gap-3">
          <span className="bg-amber-400 text-blue-950 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider">
            Autonomous
          </span>
          <span>Affiliated to Anna University, Chennai · Accredited by NAAC 'A+' Grade & NBA</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-slate-300">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400"/>
            <span>DST - FIST Sponsored Institution</span>
          </span>
          <span>Estd. 1984 · K.R. Nagar, Kovilpatti</span>
        </div>
      </div>

      {/* Main Institution Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          {/* Logo & College Identity */}
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center shadow-xs border border-slate-200 shrink-0 overflow-hidden p-1">
              <img src={COLLEGE_IMAGES.logo} alt="National Engineering College Emblem" className="w-full h-full object-contain" onError={(e) => {
            e.currentTarget.style.display = 'none';
        }}/>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-none uppercase">
                  National Engineering College
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200 hidden sm:inline-block">
                  Autonomous · Estd. 1984
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Training & Placement Cell · Kovilpatti
              </p>
            </div>
          </div>

          {/* SINGLE Unified Enter Workspace Action in Header */}
          <div className="flex items-center gap-3">
            {isAuthenticated && user && (<div className="hidden sm:flex items-center gap-2 text-right mr-1">
                <div>
                  <p className="text-xs font-bold text-slate-800">{user.name}</p>
                  <p className="text-[10px] text-emerald-600 font-semibold">● Active Session</p>
                </div>
              </div>)}
            <button onClick={onEnterWorkspace} className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all transform hover:scale-[1.02] active:scale-95 cursor-pointer">
              <span>{t('enterWorkspace')}</span>
              <ArrowRight className="w-4 h-4"/>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section with First Image in Full Rectangle View (Minimal Details) */}
      <section className="bg-slate-950 text-white pt-6 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
          {/* Minimal Intro Headline - No Yellow Buttons Here */}
          <div className="space-y-1.5">
            <h2 className="text-xl sm:text-3xl font-black tracking-tight text-white">
              Placement Preparation & Career Acceleration Ecosystem
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              National Engineering College · Click the campus image below to access your student workspace.
            </p>
          </div>

          {/* THE FIRST IMAGE IN FULL RECTANGLE VIEW */}
          <div className="w-full">
            <div onClick={onEnterWorkspace} className="group relative w-full rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl border border-slate-800 bg-slate-900 cursor-pointer transition-all duration-300 hover:border-slate-600" title="Click anywhere to enter workspace">
              {/* Full-Size Front Entrance Image Container */}
              <div className="relative w-full h-[520px] sm:h-[640px] lg:h-[760px] bg-slate-950 flex items-center justify-center overflow-hidden">
                <img src={heroImage} alt="National Engineering College Campus Entrance Monument" className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-[1.02]"/>

                {/* Subtle top & bottom vignette for legibility */}
                <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/80 via-black/40 to-transparent pointer-events-none"/>
                <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/85 via-black/40 to-transparent pointer-events-none"/>

                {/* Top Overlay Bar */}
                <div className="absolute top-3 sm:top-4 inset-x-3 sm:inset-x-5 flex items-center justify-between z-10">
                  <div className="flex items-center gap-2">
                    <span className="bg-black/60 text-white text-[11px] font-semibold px-3 py-1 rounded-lg backdrop-blur-md border border-white/10">
                      {hasCustomImage ? 'Uploaded Campus Photo' : 'NEC Front Entrance'}
                    </span>
                  </div>

                  {/* Photo Customizer & Full View */}
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => setIsFullViewOpen(true)} className="px-2.5 py-1 rounded-lg bg-black/60 hover:bg-black/80 text-amber-300 text-xs font-bold flex items-center gap-1.5 border border-amber-300/30 backdrop-blur-md transition cursor-pointer" title="Open full view image">
                      <ExternalLink className="w-3.5 h-3.5"/>
                      <span>Full View</span>
                    </button>
                    <button onClick={() => fileInputRef.current?.click()} className="px-2.5 py-1 rounded-lg bg-black/60 hover:bg-black/80 text-white text-xs font-medium flex items-center gap-1.5 border border-white/20 backdrop-blur-md transition cursor-pointer" title="Upload your exact image">
                      <Camera className="w-3.5 h-3.5 text-amber-300"/>
                      <span>Change Photo</span>
                    </button>
                    {hasCustomImage && (<button onClick={handleResetImage} className="p-1 rounded-lg bg-black/60 hover:bg-black/80 text-rose-300 text-xs border border-white/20 backdrop-blur-md transition cursor-pointer" title="Reset to official NEC photo">
                        <RotateCcw className="w-3.5 h-3.5"/>
                      </button>)}
                  </div>
                </div>

                {/* Minimal Bottom Prompt on the Image (No Yellow Box) */}
                <div className="absolute bottom-3 sm:bottom-4 inset-x-3 sm:inset-x-5 flex items-center justify-between z-10 text-xs">
                  <div>
                    <p className="font-bold text-white drop-shadow-sm text-sm sm:text-base">
                      National Engineering College
                    </p>
                    <p className="text-slate-300 text-[11px]">K.R. Nagar, Kovilpatti · Accredited NAAC 'A+' & NBA</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-semibold text-slate-200 bg-black/50 px-2.5 py-1 rounded-lg border border-white/15 backdrop-blur-xs flex items-center gap-1 group-hover:text-white transition">
                      <span>Click to open workspace</span>
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform"/>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Hidden File Input */}
            <input type="file" ref={fileInputRef} onChange={handleImageFileChange} accept="image/*" className="hidden"/>
          </div>

          {/* Real-time Dynamic Placement Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 text-center">
              <p className="text-white font-black text-xl">94.6%</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Placement Rate</p>
            </div>
            <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 text-center">
              <p className="text-emerald-400 font-black text-xl">45+ LPA</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Highest Package</p>
            </div>
            <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 text-center">
              <p className="text-blue-300 font-black text-xl">120+</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Campus Recruiters</p>
            </div>
            <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 text-center">
              <p className="text-amber-300 font-black text-xl">850+</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Offers Conferred</p>
            </div>
          </div>
        </div>
      </section>

      {/* Real-time Placement Ticker */}
      <div className="bg-slate-100 text-slate-800 py-2 px-4 border-b border-slate-200">
        <div className="max-w-7xl mx-auto flex items-center gap-3 text-xs">
          <span className="bg-blue-900 text-white text-[10px] uppercase font-bold px-2 py-0.5 rounded shrink-0">
            Live Drives
          </span>
          <p className="truncate text-slate-600 font-medium">
            Zoho Corporation Day-1 drives active · TCS Digital slot booking live · Cognizant GenC registrations open · Weekly mock technical rounds.
          </p>
        </div>
      </div>

      {/* Minimal 4 Placement Pillars */}
      <section className="py-10 px-4 sm:px-6 max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div onClick={onEnterWorkspace} className="p-4 rounded-xl bg-white border border-slate-200 hover:border-blue-400 shadow-2xs hover:shadow-sm transition cursor-pointer space-y-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center font-bold">
              <Building2 className="w-4 h-4 text-blue-800"/>
            </div>
            <h4 className="font-bold text-sm text-slate-900">1. Discover</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Company cutoffs, hiring playbooks, and verified senior interview experiences.
            </p>
          </div>

          <div onClick={onEnterWorkspace} className="p-4 rounded-xl bg-white border border-slate-200 hover:border-indigo-400 shadow-2xs hover:shadow-sm transition cursor-pointer space-y-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-900 flex items-center justify-center font-bold">
              <Users className="w-4 h-4 text-indigo-800"/>
            </div>
            <h4 className="font-bold text-sm text-slate-900">2. Connect</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              1-on-1 technical mock interviews with Google Meet and senior mentorship.
            </p>
          </div>

          <div onClick={onEnterWorkspace} className="p-4 rounded-xl bg-white border border-slate-200 hover:border-emerald-400 shadow-2xs hover:shadow-sm transition cursor-pointer space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-900 flex items-center justify-center font-bold">
              <BookOpen className="w-4 h-4 text-emerald-800"/>
            </div>
            <h4 className="font-bold text-sm text-slate-900">3. Practice</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Speed aptitude practice, coding arena challenges, and daily tests.
            </p>
          </div>

          <div onClick={onEnterWorkspace} className="p-4 rounded-xl bg-white border border-slate-200 hover:border-amber-400 shadow-2xs hover:shadow-sm transition cursor-pointer space-y-2">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-900 flex items-center justify-center font-bold">
              <TrendingUp className="w-4 h-4 text-amber-800"/>
            </div>
            <h4 className="font-bold text-sm text-slate-900">4. Track</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Continuous placement readiness score, student leaderboard, and feedback.
            </p>
          </div>
        </div>
      </section>

      {/* Prominent Recruiters Minimal Strip */}
      <section className="py-6 px-4 sm:px-6 max-w-7xl mx-auto w-full border-t border-slate-200">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 text-center">
          Key Campus Recruiters
        </p>
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
          {['Zoho', 'TCS Digital', 'Cognizant', 'Infosys', 'Amazon', 'Soliton', 'Accenture', 'Kaar Tech'].map((c) => (<span key={c} className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 font-semibold text-xs shadow-2xs">
              {c}
            </span>))}
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-slate-950 text-slate-400 text-xs border-t border-slate-800 py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 pb-8 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-white font-extrabold text-sm mb-2">
              <GraduationCap className="w-5 h-5 text-amber-400"/>
              <span>National Engineering College</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              An Autonomous Institution Affiliated to Anna University, Chennai. Approved by AICTE, Accredited by NAAC 'A+' & NBA.
            </p>
          </div>

          <div>
            <p className="text-white font-bold text-xs mb-2">Campus Address</p>
            <p className="text-[11px] leading-relaxed text-slate-400">
              K.R. Nagar, Kovilpatti - 628 503<br />
              Thoothukudi District, Tamil Nadu, India.<br />
              Email: placement@nec.edu.in | Web: www.nec.edu.in
            </p>
          </div>

          <div>
            <p className="text-white font-bold text-xs mb-2">Placement Cell Quick Actions</p>
            <div className="space-y-1.5 text-[11px]">
              <button onClick={onEnterWorkspace} className="text-amber-400 hover:underline font-bold block cursor-pointer">
                ● Enter Student Preparation Workspace
              </button>
              <p>● Zoho, TCS & Cognizant Mock Question Bank</p>
              <p>● Google Meet Mock Interviews & GD Slots</p>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-4 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-500">
          <p>© {new Date().getFullYear()} National Engineering College, Kovilpatti. All Rights Reserved.</p>
          <p>Placement Training & Career Development Portal</p>
        </div>
      </footer>

      {/* FULL VIEW IMAGE LIGHTBOX MODAL */}
      {isFullViewOpen && (<div onClick={() => setIsFullViewOpen(false)} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in duration-200">
          <div onClick={(e) => e.stopPropagation()} className="relative max-w-5xl w-full max-h-[90vh] bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-700 flex flex-col">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-white">
                  National Engineering College — Full Campus Monument View
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-400 text-slate-950">
                  Full HD
                </span>
              </div>
              <button onClick={() => setIsFullViewOpen(false)} className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer">
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-auto p-2 bg-black flex items-center justify-center">
              <img src={heroImage} alt="National Engineering College Full View" className="max-h-[75vh] w-auto max-w-full object-contain rounded-xl shadow-lg"/>
            </div>
            <div className="p-3 bg-slate-950 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
              <span>National Engineering College, K.R. Nagar, Kovilpatti</span>
              <button onClick={() => {
                setIsFullViewOpen(false);
                onEnterWorkspace();
            }} className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg cursor-pointer">
                Enter Workspace
              </button>
            </div>
          </div>
        </div>)}
    </div>);
};
