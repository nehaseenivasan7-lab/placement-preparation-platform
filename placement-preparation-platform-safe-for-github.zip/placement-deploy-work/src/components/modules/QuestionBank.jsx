import React, { useState } from 'react';
import { HelpCircle, Search, CheckCircle, ChevronDown, ChevronUp, Lightbulb, FileText, Download, Printer, Eye, X, BookOpen, GraduationCap, } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
const PRE_BUILT_PDF_PAPERS = [
    {
        id: 'pdf_nec_coding_01',
        title: 'NEC Placement Cell - Master Coding Assessment Paper',
        category: 'Coding',
        company: 'Zoho / Amazon / CTS GenC Next',
        duration: '120 Minutes',
        totalMarks: 100,
        questionCount: 6,
        fileSize: '1.4 MB',
        description: 'Core problem-solving round covering Two Pointers, String manipulation, Recursion, and Binary Trees with sample test cases.',
        sections: [
            {
                sectionName: 'Section 1: Data Structures & Algorithms (50 Marks)',
                instructions: 'Write production-grade code in C, C++, Java, or Python. Optimal space and time complexities are mandatory.',
                questions: [
                    {
                        qNo: 1,
                        text: 'Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to target. You may not use the same element twice.',
                        testCases: [
                            { input: 'nums = [2,7,11,15], target = 9', output: '[0,1]' },
                            { input: 'nums = [3,2,4], target = 6', output: '[1,2]' },
                        ],
                        explanation: 'Use Hash Map to store complement (target - num). Time Complexity: O(N), Space: O(N).',
                    },
                    {
                        qNo: 2,
                        text: 'Write an algorithm to compress strings using counts of repeated characters. For example, "aabcccccaaa" becomes "a2b1c5a3". If compressed string is not smaller than original, return original.',
                        testCases: [
                            { input: '"aabcccccaaa"', output: '"a2b1c5a3"' },
                            { input: '"abcdef"', output: '"abcdef"' },
                        ],
                        explanation: 'Single-pass two pointer tracking character runs. Beware of string concatenation overhead in Java/C++.',
                    },
                    {
                        qNo: 3,
                        text: 'Given a binary tree, determine if it is height-balanced (a binary tree in which depth of two subtrees of every node never differs by more than one).',
                        testCases: [
                            { input: 'root = [3,9,20,null,null,15,7]', output: 'true' },
                            { input: 'root = [1,2,2,3,3,null,null,4,4]', output: 'false' },
                        ],
                        explanation: 'Bottom-up DFS calculating height. Return -1 early if subtree is unbalanced. Time: O(N).',
                    },
                ],
            },
            {
                sectionName: 'Section 2: Advanced Dynamic Programming & SQL (50 Marks)',
                instructions: 'Answer both questions. Focus on subproblem overlapping state diagrams.',
                questions: [
                    {
                        qNo: 4,
                        text: 'Given an integer array `coins` representing coins of different denominations and an integer `amount`, return the fewest number of coins that you need to make up that amount. If impossible, return -1.',
                        testCases: [
                            { input: 'coins = [1,2,5], amount = 11', output: '3 (5 + 5 + 1)' },
                            { input: 'coins = [2], amount = 3', output: '-1' },
                        ],
                        explanation: 'Bottom-up DP table: dp[i] = min(dp[i], dp[i - coin] + 1). Space: O(Amount), Time: O(N*Amount).',
                    },
                    {
                        qNo: 5,
                        text: 'Write a SQL query to find the N-th highest salary from an Employee table schema: Employee(id INT, salary INT). Return NULL if N-th highest does not exist.',
                        testCases: [
                            { input: 'N = 2, Salaries = [100, 200, 300]', output: '200' },
                        ],
                        explanation: 'Use `DENSE_RANK() OVER (ORDER BY salary DESC)` or `LIMIT 1 OFFSET N-1` with distinct ordering.',
                    },
                ],
            },
        ],
    },
    {
        id: 'pdf_nec_aptitude_01',
        title: 'NEC Placement Cell - Quantitative Aptitude & Speed Math Paper',
        category: 'Aptitude',
        company: 'TCS NQT / Infosys / Wipro / Accenture',
        duration: '60 Minutes',
        totalMarks: 50,
        questionCount: 8,
        fileSize: '1.1 MB',
        description: 'Comprehensive quantitative and logical reasoning paper featuring Time & Work, Speed Distance, Syllogisms, and DI charts.',
        sections: [
            {
                sectionName: 'Part A: Quantitative Aptitude (30 Marks)',
                instructions: 'Each question carries 3 marks. Negative marking 0.75 applies for incorrect answers.',
                questions: [
                    {
                        qNo: 1,
                        text: 'A can do a piece of work in 12 days and B can do it in 18 days. If they work together for 4 days, what fraction of work is left unfinished?',
                        options: ['A) 1/3', 'B) 4/9', 'C) 5/9', 'D) 2/3'],
                        correctAnswer: 'B) 4/9',
                        explanation: '1 day work = 1/12 + 1/18 = 5/36. In 4 days = 4 * (5/36) = 20/36 = 5/9. Work left = 1 - 5/9 = 4/9.',
                    },
                    {
                        qNo: 2,
                        text: 'A train 180 meters long is traveling at a speed of 54 km/hr. How much time will it take to pass a platform 270 meters long?',
                        options: ['A) 25 seconds', 'B) 30 seconds', 'C) 35 seconds', 'D) 20 seconds'],
                        correctAnswer: 'B) 30 seconds',
                        explanation: 'Speed in m/s = 54 * (5/18) = 15 m/s. Total distance = 180 + 270 = 450 m. Time = Distance/Speed = 450/15 = 30 seconds.',
                    },
                    {
                        qNo: 3,
                        text: 'A trader sells two articles at Rs. 1,980 each. On one he gains 10% and on the other he loses 10%. What is his overall gain or loss percentage?',
                        options: ['A) No profit, no loss', 'B) 1% Gain', 'C) 1% Loss', 'D) 2% Loss'],
                        correctAnswer: 'C) 1% Loss',
                        explanation: 'When selling prices are equal and profit% = loss% = x%, overall result is always a loss of (x/10)^2 % = (10/10)^2 = 1% loss.',
                    },
                    {
                        qNo: 4,
                        text: 'A mixture contains alcohol and water in the ratio 4:3. If 5 liters of water is added to the mixture, the ratio becomes 4:5. Find the quantity of alcohol in the given mixture.',
                        options: ['A) 10 Liters', 'B) 12 Liters', 'C) 15 Liters', 'D) 8 Liters'],
                        correctAnswer: 'A) 10 Liters',
                        explanation: 'Let alcohol = 4x, water = 3x. 4x / (3x + 5) = 4/5 => 20x = 12x + 20 => 8x = 20 => x = 2.5. Alcohol = 4 * 2.5 = 10 Liters.',
                    },
                ],
            },
            {
                sectionName: 'Part B: Logical Reasoning & Syllogisms (20 Marks)',
                instructions: 'Choose the logically valid conclusion following standard deduction principles.',
                questions: [
                    {
                        qNo: 5,
                        text: 'Statements: (1) All engineers are problem solvers. (2) Some problem solvers are designers. Conclusions: (I) Some engineers are designers. (II) Some designers are problem solvers.',
                        options: ['A) Only I follows', 'B) Only II follows', 'C) Both I and II follow', 'D) Neither follows'],
                        correctAnswer: 'B) Only II follows',
                        explanation: 'Statement 2 is a particular affirmative ("Some problem solvers are designers"), so its converse "Some designers are problem solvers" is directly true.',
                    },
                    {
                        qNo: 6,
                        text: 'Pointing to a photograph, a woman says: "He is the only son of my grandfather\'s only son." How is the man in the photograph related to the woman?',
                        options: ['A) Cousin', 'B) Brother', 'C) Uncle', 'D) Father'],
                        correctAnswer: 'B) Brother',
                        explanation: 'Woman\'s grandfather\'s only son = Woman\'s father. The only son of woman\'s father = Woman\'s brother.',
                    },
                ],
            },
        ],
    },
    {
        id: 'pdf_zoho_round23_01',
        title: 'Zoho Corporation - Technical & Application Coding Test (PDF)',
        category: 'Coding',
        company: 'Zoho Corporation',
        duration: '180 Minutes',
        totalMarks: 100,
        questionCount: 5,
        fileSize: '1.6 MB',
        description: 'Exact replica of Zoho Round 2 & Round 3 programming interview paper with railway reservation simulation and string patterns.',
        sections: [
            {
                sectionName: 'Zoho Round 2: Core C / C++ Problem Solving',
                instructions: 'Do not use standard built-in sorting or string library functions like strtok, qsort, reverse. Write manual algorithms.',
                questions: [
                    {
                        qNo: 1,
                        text: 'Print the following pattern for given input N = 4:\n4 4 4 4 4 4 4\n4 3 3 3 3 3 4\n4 3 2 2 2 3 4\n4 3 2 1 2 3 4\n4 3 2 2 2 3 4\n4 3 3 3 3 3 4\n4 4 4 4 4 4 4',
                        testCases: [{ input: 'N = 4', output: 'Concentric number matrix' }],
                        explanation: 'Each cell at (i, j) has value N - min(i, j, 2N-2-i, 2N-2-j).',
                    },
                    {
                        qNo: 2,
                        text: 'Given two dimensional string array of father-son relationships, find number of grandchildren of given person. Example: [["Luke","Shaw"],["Wayne","Rooney"],["Rooney","Ronaldo"],["Shaw","Ronaldo"]]. Input: "Ronaldo", find grandchildren.',
                        testCases: [{ input: 'Input: "Ronaldo"', output: 'Grandchildren: Wayne and Luke (Count: 2)' }],
                        explanation: 'Scan matrix to find all sons of Ronaldo (Rooney, Shaw), then scan again to find all sons of those sons.',
                    },
                ],
            },
            {
                sectionName: 'Zoho Round 3: Advanced Application Development (Module)',
                instructions: 'Implement modular console application with classes, data structures, and edge cases.',
                questions: [
                    {
                        qNo: 3,
                        text: 'Design a Railway Reservation System with following requirements:\n1. Total Berths: 63 Lower, Middle, Upper; RAC: 18; Waiting List (WL): 10.\n2. Senior citizens & women with children must receive lower berth priority.\n3. Implement Book, Cancel, and Print Chart commands.',
                        testCases: [{ input: 'Book Ticket for 3 passengers', output: 'Allocated berths with PNR number' }],
                        explanation: 'Maintain queues for Confirmed, RAC, and WL with status transition upon ticket cancellation.',
                    },
                ],
            },
        ],
    },
];
export const QuestionBank = () => {
    const { user } = useAuth();
    const [questions, setQuestions] = useState(() => storageService.getQuestions());
    const [activeTab, setActiveTab] = useState('pdf_papers');
    const [categoryFilter, setCategoryFilter] = useState('All');
    const [search, setSearch] = useState('');
    const [expandedId, setExpandedId] = useState(null);
    const [selectedPdf, setSelectedPdf] = useState(null);
    const categories = ['All', 'Coding', 'Aptitude', 'Technical', 'HR', 'Company-specific'];
    const filteredQuestions = questions.filter((q) => {
        const matchesCat = categoryFilter === 'All' || q.category === categoryFilter;
        const matchesSearch = q.title.toLowerCase().includes(search.toLowerCase()) ||
            q.subCategory.toLowerCase().includes(search.toLowerCase()) ||
            (q.companyTag && q.companyTag.toLowerCase().includes(search.toLowerCase()));
        return matchesCat && matchesSearch;
    });
    const filteredPdfPapers = PRE_BUILT_PDF_PAPERS.filter((p) => {
        const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) ||
            p.company.toLowerCase().includes(search.toLowerCase()) ||
            p.category.toLowerCase().includes(search.toLowerCase());
        return matchesSearch;
    });
    const handlePrintPdf = () => {
        window.print();
    };
    const handleDownloadPdf = (paper) => {
        // Generate clean printable text/html blob as downloadable PDF document
        const content = `
========================================================================
NATIONAL ENGINEERING COLLEGE (AUTONOMOUS) - KOVILPATTI
DEPARTMENT OF TRAINING AND PLACEMENT
CAMPUS RECRUITMENT EXAMINATION PAPER (PDF FORMAT)
========================================================================
PAPER TITLE: ${paper.title}
TARGET RECRUITERS: ${paper.company}
DURATION: ${paper.duration} | MAXIMUM MARKS: ${paper.totalMarks}
TOTAL QUESTIONS: ${paper.questionCount}
========================================================================

${paper.sections
            .map((sec) => `
------------------------------------------------------------------------
${sec.sectionName.toUpperCase()}
Instructions: ${sec.instructions}
------------------------------------------------------------------------
${sec.questions
            .map((q) => `
Question ${q.qNo}: ${q.text}
${q.options ? q.options.join('\n') : ''}
${q.testCases ? q.testCases.map((tc) => `Sample Input: ${tc.input} | Sample Output: ${tc.output}`).join('\n') : ''}

SOLUTION / EXPLANATION:
${q.correctAnswer ? `Correct Option: ${q.correctAnswer}\n` : ''}${q.explanation}
`)
            .join('\n')}`)
            .join('\n\n')}

========================================================================
END OF QUESTION PAPER - NATIONAL ENGINEERING COLLEGE
========================================================================
    `;
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${paper.title.replace(/\s+/g, '_')}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        alert(`Downloaded "${paper.title}" Question Paper successfully!`);
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <HelpCircle className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
              Practice Repository
            </span>
          </div>
          <h2 className="text-xl font-bold">Placement Question Bank (PDF & Interactive)</h2>
          <p className="text-xs text-blue-200">
            Downloadable official PDF question papers and interactive bank for Zoho, TCS, Cognizant, and Amazon.
          </p>
        </div>

        {/* Tab Toggle: PDF Papers vs Interactive List */}
        <div className="flex items-center gap-1.5 p-1 bg-black/20 backdrop-blur-md rounded-xl border border-white/20 self-start sm:self-auto">
          <button onClick={() => setActiveTab('pdf_papers')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${activeTab === 'pdf_papers'
            ? 'bg-amber-400 text-blue-950 shadow-xs'
            : 'text-white hover:bg-white/10'}`}>
            <FileText className="w-3.5 h-3.5"/>
            <span>PDF Question Papers</span>
          </button>
          <button onClick={() => setActiveTab('all_questions')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${activeTab === 'all_questions'
            ? 'bg-amber-400 text-blue-950 shadow-xs'
            : 'text-white hover:bg-white/10'}`}>
            <BookOpen className="w-3.5 h-3.5"/>
            <span>Interactive Bank ({questions.length})</span>
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
          <input type="text" placeholder={activeTab === 'pdf_papers'
            ? 'Search PDF papers by company (Zoho, TCS, CTS) or topic...'
            : 'Search individual questions by keyword...'} value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-600 transition"/>
        </div>

        {activeTab === 'all_questions' && (<div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs w-full sm:w-auto">
            {categories.map((c) => (<button key={c} onClick={() => setCategoryFilter(c)} className={`px-3 py-1.5 rounded-xl font-bold transition shrink-0 cursor-pointer ${categoryFilter === c
                    ? 'bg-blue-900 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                {c}
              </button>))}
          </div>)}
      </div>

      {/* TAB 1: PDF QUESTION PAPERS (REQUESTED FEATURE) */}
      {activeTab === 'pdf_papers' && (<div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <h3 className="font-bold text-sm text-slate-900">
                Official PDF Format Coding & Aptitude Papers
              </h3>
              <p className="text-xs text-slate-500">
                Print or download authentic past drive examination papers with full problem statements, options, test cases, and solution derivations.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              {filteredPdfPapers.length} Papers Available
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredPdfPapers.map((paper) => (<div key={paper.id} className="bg-white rounded-2xl border-2 border-slate-200 hover:border-blue-500 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4 text-xs">
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 border border-blue-100">
                      <FileText className="w-5 h-5 text-blue-800"/>
                    </div>
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                      PDF Document
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-900 leading-snug">{paper.title}</h4>
                    <p className="text-[11px] text-blue-800 font-semibold mt-0.5">
                      Target: {paper.company}
                    </p>
                  </div>

                  <p className="text-[11px] text-slate-600 line-clamp-3 leading-relaxed">
                    {paper.description}
                  </p>

                  <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-center text-[10px] font-semibold text-slate-600">
                    <div>
                      <p className="text-slate-400">Duration</p>
                      <p className="text-slate-800 font-bold">{paper.duration}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">Marks</p>
                      <p className="text-slate-800 font-bold">{paper.totalMarks}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">Questions</p>
                      <p className="text-slate-800 font-bold">{paper.questionCount} Qs</p>
                    </div>
                  </div>
                </div>

                {/* PDF Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <button onClick={() => setSelectedPdf(paper)} className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition cursor-pointer">
                    <Eye className="w-3.5 h-3.5"/>
                    <span>View PDF</span>
                  </button>
                  <button onClick={() => handleDownloadPdf(paper)} title="Download PDF" className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer border border-slate-200">
                    <Download className="w-4 h-4"/>
                  </button>
                </div>
              </div>))}
          </div>
        </div>)}

      {/* TAB 2: INTERACTIVE QUESTION ACCORDION LIST */}
      {activeTab === 'all_questions' && (<div className="space-y-3">
          {filteredQuestions.map((q) => {
                const isExpanded = expandedId === q.id;
                return (<div key={q.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs hover:border-slate-300 transition">
                <div onClick={() => setExpandedId(isExpanded ? null : q.id)} className="p-4 flex items-start justify-between gap-4 cursor-pointer">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-100">
                        {q.category}
                      </span>
                      <span className="text-[10px] font-medium text-slate-500">{q.subCategory}</span>
                      {q.companyTag && (<span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/60">
                          {q.companyTag}
                        </span>)}
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${q.difficulty === 'Easy'
                        ? 'bg-emerald-50 text-emerald-700'
                        : q.difficulty === 'Medium'
                            ? 'bg-amber-50 text-amber-700'
                            : 'bg-rose-50 text-rose-700'}`}>
                        {q.difficulty}
                      </span>
                    </div>
                    <h3 className="font-bold text-sm text-slate-900 leading-snug">{q.title}</h3>
                  </div>

                  <button className="text-slate-400 p-1">
                    {isExpanded ? <ChevronUp className="w-5 h-5"/> : <ChevronDown className="w-5 h-5"/>}
                  </button>
                </div>

                {isExpanded && (<div className="px-5 pb-5 pt-2 border-t border-slate-100 bg-slate-50/50 space-y-4 text-xs">
                    {q.options && q.options.length > 0 && (<div className="space-y-1.5">
                        <p className="font-bold text-slate-700">Multiple Choice Options:</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {q.options.map((opt, idx) => (<div key={idx} className={`p-2.5 rounded-xl border flex items-center justify-between ${idx === q.correctOptionIndex
                                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                                    : 'bg-white border-slate-200 text-slate-700'}`}>
                              <span>{opt}</span>
                              {idx === q.correctOptionIndex && (<CheckCircle className="w-4 h-4 text-emerald-600 shrink-0"/>)}
                            </div>))}
                        </div>
                      </div>)}

                    <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 text-slate-800 space-y-1">
                      <div className="flex items-center gap-1.5 text-blue-900 font-bold">
                        <Lightbulb className="w-4 h-4 text-amber-500"/>
                        <span>Official Solution & Explanation:</span>
                      </div>
                      <p className="text-slate-700 leading-relaxed whitespace-pre-line text-[11px]">
                        {q.solutionExplanation}
                      </p>
                    </div>
                  </div>)}
              </div>);
            })}
        </div>)}

      {/* PDF VIEWER MODAL */}
      {selectedPdf && (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden my-4 flex flex-col max-h-[92vh]">
            {/* PDF Header Controls */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400"/>
                <div>
                  <h3 className="font-bold text-sm truncate">{selectedPdf.title}</h3>
                  <p className="text-[10px] text-slate-400">PDF Question Paper · National Engineering College</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button onClick={handlePrintPdf} className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg border border-slate-700 cursor-pointer">
                  <Printer className="w-3.5 h-3.5"/>
                  <span>Print Paper</span>
                </button>
                <button onClick={() => handleDownloadPdf(selectedPdf)} className="flex items-center gap-1 px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-lg cursor-pointer">
                  <Download className="w-3.5 h-3.5"/>
                  <span>Download</span>
                </button>
                <button onClick={() => setSelectedPdf(null)} className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer">
                  <X className="w-5 h-5"/>
                </button>
              </div>
            </div>

            {/* Rendered PDF Document Sheet */}
            <div className="flex-1 p-6 sm:p-10 overflow-y-auto space-y-6 bg-slate-100 text-slate-900 font-serif">
              {/* Paper Letterhead */}
              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md border border-slate-300 space-y-6">
                <div className="text-center pb-4 border-b-2 border-slate-800 space-y-1">
                  <div className="flex items-center justify-center gap-2 text-slate-950 font-black text-lg uppercase tracking-tight">
                    <GraduationCap className="w-6 h-6 text-blue-950"/>
                    <span>National Engineering College (Autonomous)</span>
                  </div>
                  <p className="text-xs font-sans text-slate-600 font-semibold">
                    K.R. Nagar, Kovilpatti - 628 503 | Affiliated to Anna University, Chennai
                  </p>
                  <p className="text-xs font-sans text-blue-900 font-bold uppercase tracking-wider">
                    Department of Training & Placement Cell · Assessment Division
                  </p>
                </div>

                <div className="grid grid-cols-2 text-xs font-sans border-b border-slate-300 pb-3 gap-2">
                  <div>
                    <p><strong>Course/Paper:</strong> {selectedPdf.title}</p>
                    <p><strong>Target Drive:</strong> {selectedPdf.company}</p>
                  </div>
                  <div className="text-right">
                    <p><strong>Duration:</strong> {selectedPdf.duration}</p>
                    <p><strong>Maximum Marks:</strong> {selectedPdf.totalMarks}</p>
                  </div>
                </div>

                {/* Sections and Questions */}
                <div className="space-y-6 font-sans">
                  {selectedPdf.sections.map((sec, sIdx) => (<div key={sIdx} className="space-y-4">
                      <div className="bg-slate-100 p-2.5 rounded-lg border border-slate-200">
                        <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wide">
                          {sec.sectionName}
                        </h4>
                        <p className="text-[10px] text-slate-600 mt-0.5">{sec.instructions}</p>
                      </div>

                      <div className="space-y-4 pl-1">
                        {sec.questions.map((q) => (<div key={q.qNo} className="space-y-2 text-xs pb-3 border-b border-slate-100 last:border-0">
                            <p className="font-bold text-slate-900 leading-relaxed">
                              {q.qNo}. {q.text}
                            </p>

                            {q.options && (<div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-4">
                                {q.options.map((opt, oIdx) => (<p key={oIdx} className="text-slate-700 font-medium">
                                    {opt}
                                  </p>))}
                              </div>)}

                            {q.testCases && (<div className="pl-4 space-y-1">
                                {q.testCases.map((tc, tcIdx) => (<div key={tcIdx} className="p-2 rounded bg-slate-50 border border-slate-200 font-mono text-[10px]">
                                    <p><span className="text-slate-500">Input:</span> {tc.input}</p>
                                    <p><span className="text-slate-500">Output:</span> {tc.output}</p>
                                  </div>))}
                              </div>)}

                            <div className="mt-2 p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900">
                              <span className="font-bold">Solution Note: </span>
                              {q.correctAnswer && <span className="font-bold">[{q.correctAnswer}] </span>}
                              {q.explanation}
                            </div>
                          </div>))}
                      </div>
                    </div>))}
                </div>

                <div className="pt-4 border-t-2 border-slate-800 text-center text-[10px] font-sans text-slate-500 uppercase tracking-widest">
                  *** End of Question Paper · National Engineering College Placement Cell ***
                </div>
              </div>
            </div>
          </div>
        </div>)}
    </div>);
};
