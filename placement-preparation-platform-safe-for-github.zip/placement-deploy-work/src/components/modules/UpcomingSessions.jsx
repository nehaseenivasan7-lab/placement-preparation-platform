import React from 'react';
import { Calendar, Video, Users, ExternalLink } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const UpcomingSessions = () => {
    const { user } = useAuth();
    const mockInterviews = storageService.getMockInterviews();
    const mockGDs = storageService.getMockGDs();
    const mentorshipRequests = storageService.getMentorshipRequests();
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 17</span>
          </div>
          <h2 className="text-xl font-bold">Upcoming Placement Sessions</h2>
          <p className="text-xs text-blue-200">
            Consolidated timeline of all scheduled 1-on-1 mock interviews, group discussions, and mentor calls.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Mock Interviews Column */}
        <div className="space-y-3">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Video className="w-4 h-4 text-blue-700"/>
            <span>1-on-1 Mock Interviews ({mockInterviews.length})</span>
          </p>

          <div className="space-y-3">
            {mockInterviews.map((m) => (<div key={m.id} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-900">{m.roleOrCompany}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${m.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}`}>
                    {m.status}
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl space-y-1 text-[11px] text-slate-600">
                  <p>
                    <strong>Interviewer:</strong> {m.mentorName}
                  </p>
                  <p>
                    <strong>Candidate:</strong> {m.studentName}
                  </p>
                  <p className="font-mono text-slate-800">
                    <strong>Time:</strong> {m.scheduledDate} at {m.scheduledTime}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <a href={m.meetingLink} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-blue-700 font-bold hover:underline">
                    <ExternalLink className="w-3.5 h-3.5"/>
                    <span>Join Google Meet</span>
                  </a>
                  <span className="text-[10px] text-slate-400 font-mono">Verified ID: {m.id}</span>
                </div>
              </div>))}
          </div>
        </div>

        {/* Mock GD Cohorts Column */}
        <div className="space-y-3">
          <p className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-indigo-700"/>
            <span>Group Discussion Cohorts ({mockGDs.length})</span>
          </p>

          <div className="space-y-3">
            {mockGDs.map((gd) => (<div key={gd.id} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 line-clamp-1">{gd.topic}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                    {gd.category}
                  </span>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl space-y-1 text-[11px] text-slate-600">
                  <p>
                    <strong>Moderator:</strong> {gd.mentorName}
                  </p>
                  <p>
                    <strong>Seats:</strong> {gd.participants.length} / {gd.maxParticipants} students
                  </p>
                  <p className="font-mono text-slate-800">
                    <strong>Schedule:</strong> {gd.scheduledDate} at {gd.scheduledTime}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <a href={gd.meetingLink} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-blue-700 font-bold hover:underline">
                    <ExternalLink className="w-3.5 h-3.5"/>
                    <span>Enter Discussion Room</span>
                  </a>
                  <span className="text-[10px] text-emerald-700 font-semibold">{gd.status}</span>
                </div>
              </div>))}
          </div>
        </div>
      </div>
    </div>);
};
