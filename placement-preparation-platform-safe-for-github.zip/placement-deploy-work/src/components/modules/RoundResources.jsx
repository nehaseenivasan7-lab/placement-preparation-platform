import React, { useState } from 'react';
import { Layers, Download, CheckCircle, Plus, Search, BookOpen } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const RoundResources = () => {
    const { user } = useAuth();
    const [resources, setResources] = useState(() => storageService.getResources());
    const [activeRound, setActiveRound] = useState('All');
    const [search, setSearch] = useState('');
    const [showAddModal, setShowAddModal] = useState(false);
    const [selectedResource, setSelectedResource] = useState(null);
    const [downloadSuccess, setDownloadSuccess] = useState(false);
    const [markStudiedSuccess, setMarkStudiedSuccess] = useState(false);
    // New resource
    const [newTitle, setNewTitle] = useState('');
    const [newDesc, setNewDesc] = useState('');
    const [newRoundType, setNewRoundType] = useState('Aptitude');
    const [newResourceType, setNewResourceType] = useState('PDF Guide');
    const [newLink, setNewLink] = useState('');
    const rounds = ['All', 'Aptitude', 'Coding', 'Technical', 'HR', 'GD', 'Managerial'];
    const triggerFileDownload = (res) => {
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'resource',
                title: res.title,
                subtext: `${res.roundType} Resource`,
                link: 'roundResources',
            });
        }
        const textContent = `========================================================
NATIONAL ENGINEERING COLLEGE, KOVILPATTI
PLACEMENT PREPARATION PLATFORM - OFFICIAL ROUND RESOURCE
========================================================
Title: ${res.title}
Round Type: ${res.roundType}
Resource Format: ${res.resourceType}
Uploaded by: ${res.uploadedBySeniorName}
Created: ${res.createdAt}

OVERVIEW & HIGHLIGHTS:
${res.description}

CORE STUDY SYLLABUS & FORMULAS:
1. Mathematical Speed Math & Quantitative Shortcuts
   - Time & Work: Combined Rate = 1/A + 1/B
   - Profit & Loss: Selling Price = Cost Price * (1 + Profit% / 100)
   - Permutations & Combinations: nCr = n! / (r! * (n - r)!)

2. Coding Assessment Patterns
   - Two Pointer Technique for sorted arrays
   - Sliding Window for subarray and substring constraints
   - Hash Map frequency counting for O(N) lookup
   - Monotonic Stack for Next Greater Element

3. Technical & System Design
   - OOP 4 Pillars: Encapsulation, Inheritance, Polymorphism, Abstraction
   - SQL: 1NF, 2NF, 3NF Normalization rules, Inner vs Outer Joins
   - Operating Systems: Process vs Thread, Deadlock handling, Virtual Memory

4. HR & Group Discussion Etiquette
   - Use the STAR Method: Situation -> Task -> Action -> Result
   - In GD, acknowledge previous speaker before introducing a fresh perspective.

Verified and Published by Placed Alumni & Seniors of National Engineering College
========================================================`;
        const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${res.title.replace(/[^a-zA-Z0-9]/g, '_')}_NEC_Guide.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 3000);
    };
    const handleAccess = (res) => {
        setSelectedResource(res);
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'resource',
                title: res.title,
                subtext: `${res.roundType} Resource`,
                link: 'roundResources',
            });
        }
    };
    const handleAddSubmit = (e) => {
        e.preventDefault();
        const created = storageService.addResource({
            roundType: newRoundType,
            title: newTitle,
            description: newDesc,
            resourceType: newResourceType,
            link: newLink || '#resource',
            uploadedBySeniorId: user?.seniorId || 'SEN001',
            uploadedBySeniorName: user ? `${user.name} (${user.seniorId || 'Senior'})` : 'Senior Mentor',
        });
        setResources(storageService.getResources());
        setShowAddModal(false);
        // Update senior contribution counter if senior
        if (user?.seniorId) {
            const current = storageService.getSeniorContributions(user.seniorId);
            storageService.updateSeniorContribution(user.seniorId, {
                resourcesContributed: current.resourcesContributed + 1,
            });
        }
    };
    const filtered = resources.filter((r) => {
        const matchesRound = activeRound === 'All' || r.roundType === activeRound;
        const matchesSearch = r.title.toLowerCase().includes(search.toLowerCase()) ||
            r.description.toLowerCase().includes(search.toLowerCase());
        return matchesRound && matchesSearch;
    });
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 04</span>
          </div>
          <h2 className="text-xl font-bold">Round Resources</h2>
          <p className="text-xs text-blue-200">
            Organized placement preparation materials, formulas, cheatsheets, and syllabus notes for each drive stage.
          </p>
        </div>

        {user?.role === 'senior' && (<button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
            <Plus className="w-4 h-4"/>
            <span>Upload Round Resource</span>
          </button>)}
      </div>

      {/* Round Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {rounds.map((round) => (<button key={round} onClick={() => setActiveRound(round)} className={`px-3.5 py-1.5 rounded-xl font-bold transition shrink-0 cursor-pointer ${activeRound === round
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
            {round} {round !== 'All' && 'Round'}
          </button>))}
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
        <input type="text" placeholder="Filter resources by keyword, subject, or cheat sheet..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-600 transition"/>
      </div>

      {/* Resource Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((res) => (<div key={res.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-blue-300 transition">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-900 border border-blue-100">
                  {res.roundType}
                </span>
                <span className="text-[10px] font-mono text-slate-400 font-medium">{res.resourceType}</span>
              </div>
              <h4 className="font-bold text-sm text-slate-900 leading-snug">{res.title}</h4>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{res.description}</p>
            </div>

            <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between text-xs">
              <div className="text-[11px] text-slate-500">
                <span className="font-semibold text-slate-700">{res.uploadedBySeniorName}</span>
              </div>
              <button onClick={() => handleAccess(res)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-lg transition cursor-pointer text-[11px] shadow-xs">
                <BookOpen className="w-3.5 h-3.5"/>
                <span>Access Guide</span>
              </button>
            </div>
          </div>))}
      </div>

      {/* Interactive Resource Viewer Modal */}
      {selectedResource && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col text-xs">
            {/* Modal Header */}
            <div className="p-4 bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-white/20 text-white text-[10px] font-bold uppercase tracking-wider">
                  {selectedResource.roundType} Round
                </span>
                <span className="text-[11px] text-blue-200">
                  Format: {selectedResource.resourceType}
                </span>
              </div>
              <button onClick={() => setSelectedResource(null)} className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer">
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{selectedResource.title}</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Authored by <span className="font-semibold text-slate-800">{selectedResource.uploadedBySeniorName}</span> • Published for NEC Students
                </p>
              </div>

              {downloadSuccess && (<div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600"/>
                  <span>Resource downloaded successfully to your device!</span>
                </div>)}

              {markStudiedSuccess && (<div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-600"/>
                  <span>Marked as studied! Progress synchronized to your Placement Readiness score.</span>
                </div>)}

              {/* Study Description & Guide */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <p className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  Overview & Key Preparation Notes
                </p>
                <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                  {selectedResource.description}
                </p>
              </div>

              {/* Key Concept Syllabus Box */}
              <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 space-y-2">
                <p className="font-bold text-blue-900 uppercase tracking-wider text-[11px]">
                  Core Concepts Tested in this Round
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-xs text-blue-950">
                  <li><strong>Speed Math & Mental Calculations:</strong> Percentage fractions, ratio approximations, digit sums.</li>
                  <li><strong>Data Structures & Code Patterns:</strong> Two-pointer, sliding window, prefix sums, tree traversals.</li>
                  <li><strong>Technical Core CS:</strong> OOP 4 pillars with clean code, SQL indexing, ACID transactions.</li>
                  <li><strong>Interview Delivery:</strong> Structured answers using the STAR method (Situation, Task, Action, Result).</li>
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <button onClick={() => triggerFileDownload(selectedResource)} className="flex items-center gap-2 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl shadow-xs transition cursor-pointer">
                    <Download className="w-4 h-4"/>
                    <span>Download Complete Guide (.txt)</span>
                  </button>
                  <button onClick={() => {
                setMarkStudiedSuccess(true);
                setTimeout(() => {
                    setMarkStudiedSuccess(false);
                    setSelectedResource(null);
                }, 1800);
            }} className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold rounded-xl transition cursor-pointer">
                    <CheckCircle className="w-4 h-4 text-emerald-600"/>
                    <span>Mark as Studied</span>
                  </button>
                </div>
                <button onClick={() => setSelectedResource(null)} className="px-4 py-2 text-slate-600 hover:text-slate-900 font-semibold cursor-pointer">
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>)}

      {/* Senior Upload Modal */}
      {showAddModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl p-6 shadow-2xl border max-h-[85vh] overflow-y-auto text-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Add Placement Round Resource</h3>
            <p className="text-slate-500 mb-4">Upload syllabus, PDF guide, or formula sheet for student preparation.</p>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Resource Title</label>
                <input type="text" required placeholder="e.g. Master SQL Queries for Technical Rounds" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Target Placement Round</label>
                  <select value={newRoundType} onChange={(e) => setNewRoundType(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none font-semibold text-blue-900">
                    <option value="Aptitude">Aptitude</option>
                    <option value="Coding">Coding</option>
                    <option value="Technical">Technical</option>
                    <option value="HR">HR</option>
                    <option value="GD">GD</option>
                    <option value="Managerial">Managerial</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Format Type</label>
                  <select value={newResourceType} onChange={(e) => setNewResourceType(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none">
                    <option value="Cheatsheet">Cheatsheet</option>
                    <option value="PDF Guide">PDF Guide</option>
                    <option value="Notes">Notes</option>
                    <option value="Syllabus">Syllabus</option>
                    <option value="Video">Video Link</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Description / Key Highlights</label>
                <textarea rows={3} required placeholder="Explain what topics or formulas are included..." value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Link / Document URL</label>
                <input type="text" placeholder="Google Drive link or reference URL" value={newLink} onChange={(e) => setNewLink(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Upload Resource
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
