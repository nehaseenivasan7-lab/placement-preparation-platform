import React, { useState } from 'react';
import { Trophy, Flame } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const Leaderboard = () => {
    const { user } = useAuth();
    const [timeframe, setTimeframe] = useState('overall');
    const users = storageService.getUsers().filter((u) => u.role === 'junior' || u.role === 'pre_final');
    // Compute live scores based on genuine progress data from storage
    const rankedUsers = users
        .map((u) => {
        const p = storageService.getUserProgress(u.id);
        const points = p.questionsAttempted * 10 +
            p.dailyChallengesCompleted * 25 +
            p.mockInterviewsAttended * 50 +
            p.mockGDsAttended * 35 +
            p.studyStreakDays * 15;
        return {
            id: u.id,
            name: u.name,
            role: u.role,
            department: u.department || 'Engineering',
            avatar: u.avatar,
            points,
            readinessScore: p.readinessScore,
            streak: p.studyStreakDays,
            solved: p.questionsAttempted + p.dailyChallengesCompleted,
        };
    })
        .sort((a, b) => b.points - a.points);
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Trophy className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 16</span>
          </div>
          <h2 className="text-xl font-bold">Placement Preparation Leaderboard</h2>
          <p className="text-xs text-blue-200">
            Real peer rankings computed strictly from question attempts, challenge completions, and mock participation.
          </p>
        </div>

        {/* Timeframe selector */}
        <div className="flex gap-1.5 p-1 bg-white/10 rounded-xl border border-white/20 text-xs">
          {['overall', 'weekly', 'monthly'].map((t) => (<button key={t} onClick={() => setTimeframe(t)} className={`px-3 py-1.5 rounded-lg font-bold capitalize transition cursor-pointer ${timeframe === t ? 'bg-amber-400 text-blue-950 shadow-xs' : 'text-blue-100 hover:text-white'}`}>
              {t}
            </button>))}
        </div>
      </div>

      {/* Leaderboard Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden text-xs">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <p className="font-bold text-slate-800">Student Standings ({rankedUsers.length} Enrolled)</p>
          <span className="text-[11px] text-slate-400 font-medium">Rankings update dynamically with every activity</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Department & Role</th>
                <th className="py-3 px-4">Study Streak</th>
                <th className="py-3 px-4">Readiness</th>
                <th className="py-3 px-4 text-right">Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rankedUsers.map((student, index) => {
            const isCurrentUser = student.id === user?.id;
            return (<tr key={student.id} className={`hover:bg-slate-50 transition ${isCurrentUser ? 'bg-blue-50/70 font-semibold text-blue-950' : 'text-slate-700'}`}>
                    <td className="py-3.5 px-4">
                      {index === 0 ? (<div className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center font-black text-xs">
                          1
                        </div>) : index === 1 ? (<div className="w-6 h-6 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-black text-xs">
                          2
                        </div>) : index === 2 ? (<div className="w-6 h-6 rounded-full bg-amber-700/20 text-amber-900 flex items-center justify-center font-black text-xs">
                          3
                        </div>) : (<span className="font-bold text-slate-400 pl-2">#{index + 1}</span>)}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center font-bold text-[11px] text-blue-900">
                          {student.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">
                            {student.name} {isCurrentUser && '(You)'}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="truncate max-w-[180px]">{student.department}</p>
                      <span className="text-[10px] text-slate-400 capitalize">
                        {student.role.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-medium">
                      <div className="flex items-center gap-1 text-amber-700">
                        <Flame className="w-3.5 h-3.5"/>
                        <span>{student.streak} Days</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-blue-950 font-mono">{student.readinessScore}%</span>
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-600 rounded-full" style={{ width: `${student.readinessScore}%` }}/>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-right font-black text-blue-900 font-mono text-sm">
                      {student.points} pts
                    </td>
                  </tr>);
        })}
            </tbody>
          </table>
        </div>
      </div>
    </div>);
};
