import React, { useState } from 'react';
import { MessageSquare, ThumbsUp, Send, Plus } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const PeerCircle = () => {
    const { user } = useAuth();
    const [posts, setPosts] = useState(() => storageService.getPeerPosts());
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newTitle, setNewTitle] = useState('');
    const [newContent, setNewContent] = useState('');
    const [newTags, setNewTags] = useState('Placement Prep, Coding');
    const [replyTextMap, setReplyTextMap] = useState({});
    const handleCreatePost = (e) => {
        e.preventDefault();
        if (!user)
            return;
        storageService.createPeerPost({
            authorId: user.id,
            authorName: user.name,
            authorRole: user.role,
            title: newTitle,
            content: newContent,
            tags: newTags.split(',').map((t) => t.trim()),
        });
        setPosts(storageService.getPeerPosts());
        setShowCreateModal(false);
        setNewTitle('');
        setNewContent('');
    };
    const handleUpvote = (postId) => {
        storageService.upvotePeerPost(postId);
        setPosts(storageService.getPeerPosts());
    };
    const handleReplySubmit = (postId) => {
        const text = replyTextMap[postId];
        if (!text || !user)
            return;
        storageService.replyPeerPost(postId, {
            authorName: user.name,
            authorRole: user.role,
            text,
        });
        setPosts(storageService.getPeerPosts());
        setReplyTextMap({ ...replyTextMap, [postId]: '' });
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <MessageSquare className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 13</span>
          </div>
          <h2 className="text-xl font-bold">Peer Circle</h2>
          <p className="text-xs text-blue-200">
            Collaborative community discussions, doubts clarification, and study group discussions with college peers.
          </p>
        </div>

        <button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
          <Plus className="w-4 h-4"/>
          <span>New Discussion Thread</span>
        </button>
      </div>

      {/* Posts List */}
      <div className="space-y-4 max-w-3xl mx-auto">
        {posts.map((post) => (<div key={post.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3.5 text-xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs">
                  {post.authorName.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-xs">{post.authorName}</h4>
                  <p className="text-[10px] text-slate-400 font-medium capitalize">
                    {post.authorRole.replace('_', ' ')}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                {new Date(post.createdAt).toLocaleDateString()}
              </span>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-900 mb-1 leading-snug">{post.title}</h3>
              <p className="text-slate-700 leading-relaxed">{post.content}</p>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {post.tags.map((tag, tIdx) => (<span key={tIdx} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-medium border border-slate-200">
                  #{tag}
                </span>))}
            </div>

            {/* Replies section */}
            {post.replies.length > 0 && (<div className="pt-3 border-t border-slate-100 space-y-2">
                <p className="font-bold text-slate-700 text-[11px]">Replies ({post.replies.length}):</p>
                <div className="space-y-2">
                  {post.replies.map((r) => (<div key={r.id} className="p-3 bg-slate-50 rounded-xl space-y-1 border border-slate-100">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-bold text-slate-800">{r.authorName}</span>
                        <span className="text-[10px] text-slate-400 capitalize">{r.authorRole}</span>
                      </div>
                      <p className="text-slate-600 leading-relaxed text-xs">{r.text}</p>
                    </div>))}
                </div>
              </div>)}

            {/* Interaction footer */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-3">
              <button onClick={() => handleUpvote(post.id)} className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition cursor-pointer">
                <ThumbsUp className="w-3.5 h-3.5 text-blue-700"/>
                <span>{post.upvotes} Upvotes</span>
              </button>

              <div className="flex-1 flex items-center gap-2">
                <input type="text" placeholder="Write a helpful response..." value={replyTextMap[post.id] || ''} onChange={(e) => setReplyTextMap({ ...replyTextMap, [post.id]: e.target.value })} className="flex-1 px-3 py-1.5 border rounded-lg bg-slate-50 focus:bg-white outline-none"/>
                <button onClick={() => handleReplySubmit(post.id)} disabled={!replyTextMap[post.id]?.trim()} className="p-1.5 bg-blue-900 text-white rounded-lg disabled:opacity-50 hover:bg-blue-800 transition cursor-pointer">
                  <Send className="w-3.5 h-3.5"/>
                </button>
              </div>
            </div>
          </div>))}
      </div>

      {/* Create Modal */}
      {showCreateModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Start a Peer Circle Discussion</h3>
            <p className="text-slate-500">Ask questions, share interview tips, or coordinate study groups.</p>

            <form onSubmit={handleCreatePost} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Topic Title</label>
                <input type="text" required placeholder="e.g. Best resources for TCS NQT Verbal Section?" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Details & Thoughts</label>
                <textarea rows={4} required placeholder="Provide context or specific areas you want help with..." value={newContent} onChange={(e) => setNewContent(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Tags (comma-separated)</label>
                <input type="text" value={newTags} onChange={(e) => setNewTags(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowCreateModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Post Thread
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
