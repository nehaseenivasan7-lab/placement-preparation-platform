import React, { useState } from 'react';
import { BookOpen, Lightbulb, Sparkles, ChevronRight, User } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const CompanyPlaybook = () => {
    const { user } = useAuth();
    const [playbooks, setPlaybooks] = useState(() => storageService.getPlaybooks());
    const [selectedPlaybook, setSelectedPlaybook] = useState(playbooks[0] || null);
    const handleSelect = (pb) => {
        setSelectedPlaybook(pb);
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'resource',
                title: `${pb.companyName} Playbook`,
                subtext: 'Preparation Strategy Guide',
                link: 'companyPlaybook',
            });
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 02</span>
          </div>
          <h2 className="text-xl font-bold">Company Playbook</h2>
          <p className="text-xs text-blue-200">
            Company-specific preparation playbooks, tactical tips, and recommendations from placed NEC seniors.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Playbook Navigation */}
        <div className="lg:col-span-4 space-y-2.5">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">Company Guides</p>
          {playbooks.map((pb) => {
            const isSelected = selectedPlaybook?.id === pb.id;
            return (<div key={pb.id} onClick={() => handleSelect(pb)} className={`p-4 rounded-xl border transition cursor-pointer text-left ${isSelected
                    ? 'border-blue-700 bg-blue-50/70 shadow-xs ring-1 ring-blue-700'
                    : 'border-slate-200 bg-white hover:border-slate-300'}`}>
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-bold text-sm text-slate-900">{pb.companyName}</h4>
                  <ChevronRight className="w-4 h-4 text-slate-400"/>
                </div>
                <p className="text-[11px] text-slate-500 font-medium line-clamp-1">{pb.preparationStrategy}</p>
                <div className="flex items-center gap-1.5 mt-2 text-[10px] text-amber-800 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200/50 w-fit">
                  <User className="w-3 h-3"/>
                  <span>Curated by {pb.updatedBySenior}</span>
                </div>
              </div>);
        })}
        </div>

        {/* Selected Playbook Content */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs text-xs space-y-5">
          {selectedPlaybook ? (<>
              <div className="border-b border-slate-100 pb-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  Official Placement Strategy
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">{selectedPlaybook.companyName} Drive Playbook</h3>
                <p className="text-slate-600 mt-1 leading-relaxed">{selectedPlaybook.overview}</p>
              </div>

              {/* Master Preparation Strategy */}
              <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-100 space-y-1.5">
                <div className="flex items-center gap-1.5 text-blue-900 font-bold">
                  <Lightbulb className="w-4 h-4 text-amber-500"/>
                  <span>Core Preparation Blueprint</span>
                </div>
                <p className="text-slate-700 leading-relaxed">{selectedPlaybook.preparationStrategy}</p>
              </div>

              {/* Round-wise Important Topics */}
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-3">Round-Wise High Yield Topics</h4>
                <div className="space-y-3">
                  {selectedPlaybook.importantTopics.map((item, idx) => (<div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50">
                      <p className="font-bold text-slate-900 text-xs mb-1.5 text-blue-900">{item.round}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {item.topics.map((t, tIdx) => (<span key={tIdx} className="px-2.5 py-1 bg-white text-slate-700 rounded-md border border-slate-200 font-medium text-[11px]">
                            {t}
                          </span>))}
                      </div>
                    </div>))}
                </div>
              </div>

              {/* Placed Senior Recommendations */}
              <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200">
                <div className="flex items-center gap-1.5 text-amber-900 font-bold mb-1">
                  <Sparkles className="w-4 h-4 text-amber-600"/>
                  <span>Placed Senior Mentor Advice</span>
                </div>
                <p className="text-amber-950 font-medium leading-relaxed">
                  {selectedPlaybook.seniorRecommendations}
                </p>
              </div>
            </>) : (<p className="text-slate-400 italic">Select a playbook from the left panel.</p>)}
        </div>
      </div>
    </div>);
};
