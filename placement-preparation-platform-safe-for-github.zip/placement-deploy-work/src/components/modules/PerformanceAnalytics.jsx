import React, { useState, useEffect } from 'react';
import { BarChart3, Award, Flame, Brain, Video, Users } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const PerformanceAnalytics = () => {
    const { user } = useAuth();
    const [progress, setProgress] = useState(null);
    useEffect(() => {
        if (user) {
            setProgress(storageService.getUserProgress(user.id));
        }
    }, [user]);
    if (!progress)
        return null;
    const accuracy = progress.questionsAttempted > 0
        ? Math.round((progress.questionsCorrect / progress.questionsAttempted) * 100)
        : 0;
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 15</span>
          </div>
          <h2 className="text-xl font-bold">Performance Analytics & Readiness Engine</h2>
          <p className="text-xs text-blue-200">
            Real-time verified evaluation metrics, accuracy trajectories, and placement drive readiness indices.
          </p>
        </div>
      </div>

      {/* Main Readiness Gauge Card */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div className="space-y-2 text-xs md:col-span-2">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-700"/>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Verified Readiness Index
            </span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-4xl font-extrabold text-blue-950">{progress.readinessScore}%</span>
            <span className="text-xs font-semibold text-slate-500">
              {progress.readinessScore >= 75
            ? 'Excellent • Prime Placement Contender'
            : progress.readinessScore >= 40
                ? 'Moderate • Good Progress'
                : 'Developing • Start with Practice Studio'}
            </span>
          </div>
          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden mt-2">
            <div className="h-full bg-linear-to-r from-blue-600 via-indigo-600 to-emerald-500 rounded-full transition-all duration-500" style={{ width: `${progress.readinessScore}%` }}/>
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed pt-1">
            Formula weights: Question Practice & Accuracy (30%), Coding & Aptitude Balance (25%), Consistency & Daily Streak (15%), Mock Interviews & GDs (20%), Mentorship & Goals (10%).
          </p>
        </div>

        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2.5">
          <p className="font-bold text-slate-900 text-xs">Dynamic Breakdown:</p>
          <div className="flex items-center justify-between text-slate-600">
            <span>Overall Accuracy:</span>
            <span className="font-bold text-slate-900">{accuracy}%</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Study Streak:</span>
            <span className="font-bold text-amber-600">{progress.studyStreakDays} Days</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Mock Evaluations:</span>
            <span className="font-bold text-blue-900">{progress.mockInterviewsAttended + progress.mockGDsAttended} Sessions</span>
          </div>
        </div>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="font-bold text-[10px] uppercase">Questions Practiced</span>
            <Brain className="w-4 h-4 text-blue-600"/>
          </div>
          <p className="text-2xl font-extrabold text-slate-900">{progress.questionsAttempted}</p>
          <p className="text-[11px] text-emerald-700 font-semibold">{progress.questionsCorrect} Correct</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="font-bold text-[10px] uppercase">Daily Challenges</span>
            <Flame className="w-4 h-4 text-amber-500"/>
          </div>
          <p className="text-2xl font-extrabold text-slate-900">{progress.dailyChallengesCompleted}</p>
          <p className="text-[11px] text-slate-500 font-medium">Solved & verified</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="font-bold text-[10px] uppercase">Mock Interviews</span>
            <Video className="w-4 h-4 text-purple-600"/>
          </div>
          <p className="text-2xl font-extrabold text-slate-900">{progress.mockInterviewsAttended}</p>
          <p className="text-[11px] text-slate-500 font-medium">1-on-1 Senior Sessions</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-500">
            <span className="font-bold text-[10px] uppercase">Mock GDs</span>
            <Users className="w-4 h-4 text-indigo-600"/>
          </div>
          <p className="text-2xl font-extrabold text-slate-900">{progress.mockGDsAttended}</p>
          <p className="text-[11px] text-slate-500 font-medium">Cohorts attended</p>
        </div>
      </div>
    </div>);
};
