import React, { useState } from 'react';
import { Calculator, CheckCircle, ArrowRight, Lightbulb } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
const APTITUDE_DATA = [
    {
        id: 'apt_01',
        section: 'Quantitative',
        topic: 'Time, Speed and Distance',
        question: 'A train 125 m long passes a man, running at 5 km/hr in the same direction in which the train is going, in 10 seconds. What is the speed of the train in km/hr?',
        options: ['45 km/hr', '50 km/hr', '54 km/hr', '55 km/hr'],
        correct: 1,
        explanation: 'Relative speed = Distance / Time = 125 m / 10 s = 12.5 m/s. Converting to km/hr: 12.5 * (18/5) = 45 km/hr. Since both move in the same direction, Speed of Train - Speed of Man = 45. Hence, Speed of Train = 45 + 5 = 50 km/hr.',
        formulaHint: 'Relative speed in same direction = (S1 - S2). To convert m/s to km/hr, multiply by 18/5.',
    },
    {
        id: 'apt_02',
        section: 'Quantitative',
        topic: 'Profit, Loss and Discount',
        question: 'An article is sold at a profit of 20%. If both the cost price and selling price are Rs. 100 less, the profit would be 4% more. Find the cost price.',
        options: ['Rs. 500', 'Rs. 600', 'Rs. 700', 'Rs. 800'],
        correct: 1,
        explanation: 'Let CP = x. SP = 1.2x. New CP = x - 100, New SP = 1.2x - 100. New Profit % = 24%. Equation: (1.2x - 100) - (x - 100) = 0.24 * (x - 100). Solving gives x = Rs. 600.',
        formulaHint: 'Profit % = (SP - CP)/CP * 100.',
    },
    {
        id: 'apt_03',
        section: 'Logical Reasoning',
        topic: 'Syllogism',
        question: 'Statements: All engineers are innovators. Some innovators are leaders. Conclusions: I. Some engineers are leaders. II. Some leaders are innovators.',
        options: ['Only I follows', 'Only II follows', 'Both I and II follow', 'Neither follows'],
        correct: 1,
        explanation: '"Some innovators are leaders" directly converts to "Some leaders are innovators" (Conclusion II). Since the middle term is not distributed, Conclusion I does not necessarily follow.',
    },
    {
        id: 'apt_04',
        section: 'Verbal Ability',
        topic: 'Sentence Correction',
        question: 'Identify the error: Neither the placement coordinator (A) nor the student representatives (B) was present (C) at the orientation (D).',
        options: ['Part A', 'Part B', 'Part C (was present)', 'Part D'],
        correct: 2,
        explanation: 'In "Neither... nor" constructions, the verb agrees with the closer subject ("student representatives" is plural, so it must be "were present").',
    },
];
export const AptitudePractice = () => {
    const { user } = useAuth();
    const [sectionFilter, setSectionFilter] = useState('All');
    const [currentIdx, setCurrentIdx] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [showHint, setShowHint] = useState(false);
    const sections = ['All', 'Quantitative', 'Logical Reasoning', 'Verbal Ability', 'Data Interpretation'];
    const filtered = APTITUDE_DATA.filter((a) => (sectionFilter === 'All' ? true : a.section === sectionFilter));
    const currentItem = filtered[currentIdx] || filtered[0];
    const handleSubmit = () => {
        if (selectedOption === null || isSubmitted || !user || !currentItem)
            return;
        setIsSubmitted(true);
        const isCorrect = selectedOption === currentItem.correct;
        storageService.recordQuestionAttempt(user.id, isCorrect, 'Aptitude Practice');
    };
    const handleNext = () => {
        if (currentIdx + 1 < filtered.length) {
            setCurrentIdx((prev) => prev + 1);
            setSelectedOption(null);
            setIsSubmitted(false);
            setShowHint(false);
        }
        else {
            setCurrentIdx(0);
            setSelectedOption(null);
            setIsSubmitted(false);
            setShowHint(false);
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Calculator className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 09</span>
          </div>
          <h2 className="text-xl font-bold">Aptitude Practice</h2>
          <p className="text-xs text-blue-200">
            Speed math, logical analysis, verbal reasoning, and shortcuts for clearing first-round screening tests.
          </p>
        </div>
      </div>

      {/* Section Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        {sections.map((s) => (<button key={s} onClick={() => {
                setSectionFilter(s);
                setCurrentIdx(0);
                setSelectedOption(null);
                setIsSubmitted(false);
            }} className={`px-3.5 py-1.5 rounded-xl font-bold transition shrink-0 cursor-pointer ${sectionFilter === s
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
            {s}
          </button>))}
      </div>

      {currentItem ? (<div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6 text-xs max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-900 border border-blue-100">
                {currentItem.section}
              </span>
              <span className="text-slate-500 font-medium text-[11px]">{currentItem.topic}</span>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              Question {currentIdx + 1} of {filtered.length}
            </span>
          </div>

          {/* Question Text */}
          <h3 className="text-base font-bold text-slate-900 leading-snug">{currentItem.question}</h3>

          {/* Options */}
          <div className="space-y-2.5">
            {currentItem.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                const isCorrect = idx === currentItem.correct;
                let style = 'border-slate-200 bg-white hover:border-slate-300 text-slate-800';
                if (isSubmitted) {
                    if (isCorrect)
                        style = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold';
                    else if (isSelected)
                        style = 'border-rose-400 bg-rose-50 text-rose-950 font-bold';
                }
                else if (isSelected) {
                    style = 'border-blue-700 bg-blue-50/80 text-blue-900 font-bold ring-1 ring-blue-700';
                }
                return (<div key={idx} onClick={() => !isSubmitted && setSelectedOption(idx)} className={`p-3.5 rounded-xl border flex items-center justify-between transition cursor-pointer ${style}`}>
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded bg-slate-100 flex items-center justify-center font-bold text-slate-700 text-xs">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span>{opt}</span>
                  </div>
                  {isSubmitted && isCorrect && <CheckCircle className="w-4 h-4 text-emerald-600"/>}
                </div>);
            })}
          </div>

          {/* Formula Hint Button */}
          {currentItem.formulaHint && !isSubmitted && (<div>
              <button onClick={() => setShowHint(!showHint)} className="text-[11px] font-semibold text-blue-700 hover:underline flex items-center gap-1 cursor-pointer">
                <Lightbulb className="w-3.5 h-3.5 text-amber-500"/>
                <span>{showHint ? 'Hide Formula Hint' : 'Show Formula / Shortcut Hint'}</span>
              </button>
              {showHint && (<div className="mt-2 p-2.5 bg-amber-50/70 border border-amber-200 rounded-lg text-[11px] text-amber-900">
                  {currentItem.formulaHint}
                </div>)}
            </div>)}

          {/* Solution Explanation */}
          {isSubmitted && (<div className="p-4 bg-blue-50/80 rounded-xl border border-blue-200 space-y-1">
              <p className="font-bold text-blue-900">Step-by-Step Calculation:</p>
              <p className="text-slate-700 leading-relaxed">{currentItem.explanation}</p>
            </div>)}

          {/* Footer Action */}
          <div className="flex justify-end pt-2 border-t border-slate-100">
            {!isSubmitted ? (<button onClick={handleSubmit} disabled={selectedOption === null} className="px-5 py-2 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl transition cursor-pointer">
                Confirm Answer
              </button>) : (<button onClick={handleNext} className="flex items-center gap-1.5 px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl transition cursor-pointer">
                <span>{currentIdx + 1 < filtered.length ? 'Next Question' : 'Loop Set'}</span>
                <ArrowRight className="w-4 h-4"/>
              </button>)}
          </div>
        </div>) : (<p className="text-center text-slate-500 text-xs py-8">No aptitude questions found in this category.</p>)}
    </div>);
};
