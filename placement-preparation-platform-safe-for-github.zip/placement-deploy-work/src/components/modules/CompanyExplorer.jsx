import React, { useState } from 'react';
import { Building2, Search, Filter, ExternalLink, Plus } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const CompanyExplorer = ({ onOpenPlaybook }) => {
    const { user } = useAuth();
    const [companies, setCompanies] = useState(() => storageService.getCompanies());
    const [search, setSearch] = useState('');
    const [tierFilter, setTierFilter] = useState('all');
    const [selectedCompany, setSelectedCompany] = useState(companies[0] || null);
    // Senior add company modal
    const [showAddModal, setShowAddModal] = useState(false);
    const [newCompany, setNewCompany] = useState({
        name: '',
        industry: '',
        tier: 'Tier 1 / Product',
        packageRange: '',
        eligibilityCgpa: 6.5,
        branchesEligible: 'CSE, IT, ECE',
        jobRoles: 'Software Development Engineer',
        skillsRequired: 'C++, Java, DSA',
        selectionProcess: 'Aptitude, Coding, Technical, HR',
        overview: '',
        website: '',
    });
    const isSeniorCompanyExplorer = user?.role === 'senior' && (user.specialization === 'Company Explorer' || true);
    const handleAddCompany = (e) => {
        e.preventDefault();
        const created = storageService.addCompany({
            name: newCompany.name,
            industry: newCompany.industry,
            tier: newCompany.tier,
            packageRange: newCompany.packageRange,
            eligibilityCgpa: Number(newCompany.eligibilityCgpa),
            branchesEligible: newCompany.branchesEligible.split(',').map((b) => b.trim()),
            jobRoles: newCompany.jobRoles.split(',').map((r) => r.trim()),
            skillsRequired: newCompany.skillsRequired.split(',').map((s) => s.trim()),
            selectionProcess: newCompany.selectionProcess.split(',').map((p) => p.trim()),
            overview: newCompany.overview,
            website: newCompany.website,
            pastHiresCount: 15,
            addedBySeniorId: user?.seniorId || 'SEN001',
        });
        setCompanies(storageService.getCompanies());
        setSelectedCompany(created);
        setShowAddModal(false);
        // Track recently accessed
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'company',
                title: created.name,
                subtext: `Viewed details for ${created.name}`,
                link: 'companyExplorer',
            });
        }
    };
    const filtered = companies.filter((c) => {
        const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.industry.toLowerCase().includes(search.toLowerCase());
        const matchesTier = tierFilter === 'all' || c.tier === tierFilter;
        return matchesSearch && matchesTier;
    });
    const handleSelectCompany = (c) => {
        setSelectedCompany(c);
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'company',
                title: c.name,
                subtext: `${c.tier} - ${c.packageRange}`,
                link: 'companyExplorer',
            });
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Building2 className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 01</span>
          </div>
          <h2 className="text-xl font-bold">Company Explorer</h2>
          <p className="text-xs text-blue-200">
            Explore recruitment criteria, eligibility CGPA, selection rounds, and past hire trends at NEC.
          </p>
        </div>

        {isSeniorCompanyExplorer && (<button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
            <Plus className="w-4 h-4"/>
            <span>Add New Company (Senior Lead)</span>
          </button>)}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
          <input type="text" placeholder="Search company by name, sector, or role..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-600 transition"/>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0"/>
          <select value={tierFilter} onChange={(e) => setTierFilter(e.target.value)} className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none text-slate-700 font-semibold">
            <option value="all">All Company Tiers</option>
            <option value="Tier 1 / Product">Tier 1 / Product</option>
            <option value="Tier 2 / Tech">Tier 2 / Tech</option>
            <option value="Core Engineering">Core Engineering</option>
            <option value="Service Based">Service Based</option>
          </select>
        </div>
      </div>

      {/* Company Grid & Detail Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Company Cards List */}
        <div className="lg:col-span-5 space-y-3">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Companies Visiting NEC ({filtered.length})
          </p>
          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {filtered.map((c) => {
            const isSelected = selectedCompany?.id === c.id;
            return (<div key={c.id} onClick={() => handleSelectCompany(c)} className={`p-4 rounded-xl border text-left transition cursor-pointer ${isSelected
                    ? 'border-blue-700 bg-blue-50/60 shadow-xs ring-1 ring-blue-700'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'}`}>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{c.name}</h4>
                      <p className="text-[11px] text-slate-500 font-medium">{c.industry}</p>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 shrink-0">
                      {c.tier}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100 mt-2">
                    <span className="font-extrabold text-blue-900">{c.packageRange}</span>
                    <span className="text-[11px] text-emerald-700 font-semibold">
                      Min CGPA: {c.eligibilityCgpa}
                    </span>
                  </div>
                </div>);
        })}
          </div>
        </div>

        {/* Selected Company Deep Dive Details */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          {selectedCompany ? (<div className="space-y-5 text-xs">
              <div className="flex items-start justify-between border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-bold text-slate-900">{selectedCompany.name}</h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 font-semibold">
                      {selectedCompany.tier}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{selectedCompany.industry}</p>
                </div>
                {selectedCompany.website && (<a href={selectedCompany.website} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-blue-700 font-bold hover:underline">
                    <span>Website</span>
                    <ExternalLink className="w-3.5 h-3.5"/>
                  </a>)}
              </div>

              {/* Package and Eligibility Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">CTC Range</p>
                  <p className="text-xs font-extrabold text-slate-900 mt-0.5">{selectedCompany.packageRange}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Min Eligibility</p>
                  <p className="text-xs font-extrabold text-slate-900 mt-0.5">
                    {selectedCompany.eligibilityCgpa} CGPA (No History)
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">NEC Hires Trend</p>
                  <p className="text-xs font-extrabold text-emerald-700 mt-0.5">
                    {selectedCompany.pastHiresCount}+ Students
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Eligible Branches</p>
                  <p className="text-xs font-extrabold text-slate-900 mt-0.5 truncate">
                    {selectedCompany.branchesEligible.join(', ')}
                  </p>
                </div>
              </div>

              {/* Overview */}
              <div>
                <h4 className="font-bold text-slate-900 mb-1.5 text-xs">Company Overview & Culture</h4>
                <p className="text-slate-600 leading-relaxed">{selectedCompany.overview}</p>
              </div>

              {/* Selection Process Rounds */}
              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs">Drive Selection Process</h4>
                <div className="space-y-1.5">
                  {selectedCompany.selectionProcess.map((round, idx) => (<div key={idx} className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                      <span className="w-5 h-5 rounded-full bg-blue-900 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <span className="text-slate-700 font-medium">{round}</span>
                    </div>))}
                </div>
              </div>

              {/* Key Skills Required */}
              <div>
                <h4 className="font-bold text-slate-900 mb-2 text-xs">Key Evaluated Skills</h4>
                <div className="flex flex-wrap gap-1.5">
                  {(selectedCompany.skillsRequired || ['DSA', 'Problem Solving', 'Aptitude']).map((skill, idx) => (<span key={idx} className="px-2.5 py-1 bg-blue-50 text-blue-900 font-semibold rounded-lg border border-blue-200 text-[11px]">
                      {skill}
                    </span>))}
                </div>
              </div>

              {/* Job Roles */}
              <div>
                <h4 className="font-bold text-slate-900 mb-1 text-xs">Designated Job Roles</h4>
                <p className="text-slate-600">{selectedCompany.jobRoles.join(' • ')}</p>
              </div>
            </div>) : (<p className="text-slate-400 text-xs italic">Select a company from the left to view details.</p>)}
        </div>
      </div>

      {/* Senior Add Company Modal */}
      {showAddModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl p-6 shadow-2xl border max-h-[85vh] overflow-y-auto text-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Add Company to NEC Placement Explorer</h3>
            <p className="text-slate-500 mb-4">Authorized Senior Mentor Contribution (SEN Specialization)</p>

            <form onSubmit={handleAddCompany} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Company Name</label>
                <input type="text" required value={newCompany.name} onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Industry</label>
                  <input type="text" required value={newCompany.industry} onChange={(e) => setNewCompany({ ...newCompany, industry: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Tier</label>
                  <select value={newCompany.tier} onChange={(e) => setNewCompany({ ...newCompany, tier: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none">
                    <option value="Tier 1 / Product">Tier 1 / Product</option>
                    <option value="Tier 2 / Tech">Tier 2 / Tech</option>
                    <option value="Core Engineering">Core Engineering</option>
                    <option value="Service Based">Service Based</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Package Range</label>
                  <input type="text" required placeholder="e.g. ₹6.0 - ₹8.5 LPA" value={newCompany.packageRange} onChange={(e) => setNewCompany({ ...newCompany, packageRange: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Eligibility CGPA</label>
                  <input type="number" step="0.1" required value={newCompany.eligibilityCgpa} onChange={(e) => setNewCompany({ ...newCompany, eligibilityCgpa: Number(e.target.value) })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Selection Rounds (comma-separated)</label>
                <input type="text" required value={newCompany.selectionProcess} onChange={(e) => setNewCompany({ ...newCompany, selectionProcess: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Overview & Tips</label>
                <textarea rows={2} value={newCompany.overview} onChange={(e) => setNewCompany({ ...newCompany, overview: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border rounded-lg text-slate-700 font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Save Company
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
