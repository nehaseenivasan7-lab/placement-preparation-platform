import React, { useState, useEffect } from 'react';
import { CalendarCheck, Plus, CheckCircle2, Circle } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const StudyPlanner = () => {
    const { user } = useAuth();
    const [goals, setGoals] = useState([]);
    const [progress, setProgress] = useState(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [newTitle, setNewTitle] = useState('');
    const [newCategory, setNewCategory] = useState('Coding');
    const [newDeadline, setNewDeadline] = useState('2026-10-15');
    useEffect(() => {
        if (user) {
            setGoals(storageService.getStudyGoals(user.id));
            setProgress(storageService.getUserProgress(user.id));
        }
    }, [user]);
    const handleToggle = (goalId) => {
        if (!user)
            return;
        storageService.toggleStudyGoal(user.id, goalId);
        setGoals(storageService.getStudyGoals(user.id));
        setProgress(storageService.getUserProgress(user.id));
    };
    const handleAddSubmit = (e) => {
        e.preventDefault();
        if (!user)
            return;
        storageService.addStudyGoal(user.id, {
            title: newTitle,
            category: newCategory,
            deadline: newDeadline,
        });
        setGoals(storageService.getStudyGoals(user.id));
        setProgress(storageService.getUserProgress(user.id));
        setShowAddModal(false);
        setNewTitle('');
    };
    const completedCount = goals.filter((g) => g.isCompleted).length;
    const completionPercent = goals.length > 0 ? Math.round((completedCount / goals.length) * 100) : 0;
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CalendarCheck className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 14</span>
          </div>
          <h2 className="text-xl font-bold">Placement Study Planner</h2>
          <p className="text-xs text-blue-200">
            Set daily and weekly milestones. Completed targets directly enhance your overall readiness index.
          </p>
        </div>

        <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
          <Plus className="w-4 h-4"/>
          <span>Add Study Goal</span>
        </button>
      </div>

      {/* Progress Bar Widget */}
      <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-bold text-slate-900 text-sm">Milestone Completion Velocity</h4>
            <p className="text-slate-500 text-[11px]">
              {completedCount} of {goals.length} target tasks achieved
            </p>
          </div>
          <span className="text-base font-extrabold text-blue-900">{completionPercent}%</span>
        </div>

        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-linear-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-300" style={{ width: `${completionPercent}%` }}/>
        </div>
      </div>

      {/* Goals List */}
      <div className="space-y-3 max-w-2xl mx-auto">
        <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">Active Target Tasks</p>
        {goals.length === 0 ? (<div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-500 space-y-2">
            <CalendarCheck className="w-8 h-8 mx-auto text-slate-300"/>
            <p className="font-bold text-slate-800">No custom goals added yet</p>
            <p className="text-slate-400">Click "Add Study Goal" above to schedule tasks for your upcoming drives!</p>
          </div>) : (goals.map((g) => (<div key={g.id} onClick={() => handleToggle(g.id)} className={`p-4 rounded-xl border flex items-center justify-between transition cursor-pointer text-xs ${g.isCompleted
                ? 'bg-emerald-50/60 border-emerald-300'
                : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'}`}>
              <div className="flex items-center gap-3">
                {g.isCompleted ? (<CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0"/>) : (<Circle className="w-5 h-5 text-slate-300 shrink-0"/>)}
                <div>
                  <h4 className={`font-bold text-xs ${g.isCompleted ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                    {g.title}
                  </h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] px-2 py-0.5 rounded bg-blue-50 text-blue-900 font-semibold">
                      {g.category}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Deadline: {g.deadline}</span>
                  </div>
                </div>
              </div>

              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${g.isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                {g.isCompleted ? 'Done' : 'In Progress'}
              </span>
            </div>)))}
      </div>

      {/* Add Modal */}
      {showAddModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Add Milestone to Study Planner</h3>
            <p className="text-slate-500">Track and check off your preparation targets.</p>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Goal Statement</label>
                <input type="text" required placeholder="e.g. Solve 5 Two Pointer Problems in Practice Studio" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category</label>
                  <select value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg font-semibold bg-white">
                    <option value="Coding">Coding Practice</option>
                    <option value="Aptitude">Aptitude Math</option>
                    <option value="Company Prep">Company Prep</option>
                    <option value="Interview">Mock Interview</option>
                    <option value="Resume">Resume Review</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Target Deadline</label>
                  <input type="date" required value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Save Milestone
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
