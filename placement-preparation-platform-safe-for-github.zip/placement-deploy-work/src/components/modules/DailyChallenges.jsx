import React, { useState, useEffect } from 'react';
import { Flame, CheckCircle, Sparkles, Calendar, Lightbulb } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const DailyChallenges = () => {
    const { user } = useAuth();
    const [challenges, setChallenges] = useState(() => storageService.getChallenges());
    const [selectedChallenge, setSelectedChallenge] = useState(challenges[0] || null);
    const [selectedOption, setSelectedOption] = useState(null);
    const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
    const [solvedMap, setSolvedMap] = useState({});
    const [progress, setProgress] = useState(null);
    useEffect(() => {
        if (user) {
            setProgress(storageService.getUserProgress(user.id));
        }
    }, [user]);
    const handleSubmit = () => {
        if (selectedOption === null || !user || !selectedChallenge || isAnswerSubmitted)
            return;
        const isCorrect = selectedOption === selectedChallenge.correctAnswer;
        setIsAnswerSubmitted(true);
        if (isCorrect) {
            storageService.recordChallengeCompleted(user.id, selectedChallenge.xpReward);
            const updated = storageService.getUserProgress(user.id);
            setProgress(updated);
            setSolvedMap((prev) => ({ ...prev, [selectedChallenge.id]: true }));
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 07</span>
          </div>
          <h2 className="text-xl font-bold">Daily Placement Challenges</h2>
          <p className="text-xs text-blue-200">
            One curated challenge every single day to build consistent placement preparation discipline.
          </p>
        </div>

        {/* Live Streak Badge */}
        {progress && (<div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 flex items-center gap-3 text-xs">
            <div className="p-2 rounded-lg bg-amber-400 text-blue-950 font-bold">
              <Flame className="w-4 h-4"/>
            </div>
            <div>
              <p className="text-[10px] text-blue-200 font-bold uppercase">Active Study Streak</p>
              <p className="text-sm font-extrabold text-white">
                {progress.studyStreakDays} {progress.studyStreakDays === 1 ? 'Day' : 'Days'}
              </p>
            </div>
          </div>)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Challenge selector */}
        <div className="lg:col-span-4 space-y-2.5">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">Challenge Calendar</p>
          {challenges.map((ch) => {
            const isSelected = selectedChallenge?.id === ch.id;
            const isSolved = solvedMap[ch.id];
            return (<div key={ch.id} onClick={() => {
                    setSelectedChallenge(ch);
                    setSelectedOption(null);
                    setIsAnswerSubmitted(false);
                }} className={`p-4 rounded-xl border transition cursor-pointer text-left ${isSelected
                    ? 'border-blue-700 bg-blue-50/70 shadow-xs ring-1 ring-blue-700'
                    : 'border-slate-200 bg-white hover:border-slate-300'}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900">
                    {ch.type}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500">
                    <Calendar className="w-3 h-3"/>
                    <span>{ch.date}</span>
                  </div>
                </div>
                <h4 className="font-bold text-xs text-slate-900 leading-snug">{ch.title}</h4>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-[11px]">
                  <span className="text-amber-700 font-bold">+{ch.xpReward} XP</span>
                  {isSolved ? (<span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5"/>
                      <span>Completed</span>
                    </span>) : (<span className="text-slate-400">Unsolved</span>)}
                </div>
              </div>);
        })}
        </div>

        {/* Challenge Workspace */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs text-xs space-y-5">
          {selectedChallenge ? (<>
              <div className="border-b border-slate-100 pb-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    Daily Problem • {selectedChallenge.type}
                  </span>
                  <span className="font-mono text-slate-400">{selectedChallenge.date}</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mt-2">{selectedChallenge.title}</h3>
                <p className="text-slate-700 mt-2 leading-relaxed text-xs">{selectedChallenge.description}</p>
              </div>

              {/* Options */}
              {selectedChallenge.options && (<div className="space-y-2.5">
                  <p className="font-bold text-slate-700 text-xs">Select the optimal approach / answer:</p>
                  {selectedChallenge.options.map((opt, idx) => {
                    const isSelected = selectedOption === idx;
                    const isCorrect = idx === selectedChallenge.correctAnswer;
                    let style = 'border-slate-200 bg-white hover:border-slate-300 text-slate-800';
                    if (isAnswerSubmitted) {
                        if (isCorrect)
                            style = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold';
                        else if (isSelected)
                            style = 'border-rose-400 bg-rose-50 text-rose-950 font-bold';
                    }
                    else if (isSelected) {
                        style = 'border-blue-700 bg-blue-50/80 text-blue-900 font-bold';
                    }
                    return (<div key={idx} onClick={() => !isAnswerSubmitted && setSelectedOption(idx)} className={`p-3 rounded-xl border flex items-center justify-between transition cursor-pointer ${style}`}>
                        <div className="flex items-center gap-2.5">
                          <span className="w-5 h-5 rounded bg-slate-100 flex items-center justify-center font-bold text-slate-600 text-xs">
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span>{opt}</span>
                        </div>
                        {isAnswerSubmitted && isCorrect && <CheckCircle className="w-4 h-4 text-emerald-600"/>}
                      </div>);
                })}
                </div>)}

              {/* Explanation */}
              {isAnswerSubmitted && (<div className="p-4 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1">
                  <p className="font-bold text-blue-900 flex items-center gap-1">
                    <Lightbulb className="w-3.5 h-3.5 text-amber-500"/>
                    <span>Solution Rationale:</span>
                  </p>
                  <p className="text-slate-700 leading-relaxed">{selectedChallenge.explanation}</p>
                </div>)}

              {/* Action Buttons */}
              <div className="flex justify-end pt-2">
                {!isAnswerSubmitted ? (<button onClick={handleSubmit} disabled={selectedOption === null} className="px-5 py-2.5 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl transition cursor-pointer">
                    Submit Daily Challenge
                  </button>) : (<div className="flex items-center gap-2 text-emerald-700 font-bold">
                    <Sparkles className="w-4 h-4"/>
                    <span>Challenge Completed! Streak Maintained.</span>
                  </div>)}
              </div>
            </>) : (<p className="text-slate-400 italic">Select a challenge from the calendar.</p>)}
        </div>
      </div>
    </div>);
};
