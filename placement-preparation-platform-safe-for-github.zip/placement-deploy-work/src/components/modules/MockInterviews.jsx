import React, { useState } from 'react';
import { Video, Calendar, UserCheck, Plus, ExternalLink, Copy, Info, X, CheckCircle2, ChevronRight, } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
const INTERVIEW_PROCESS_PHASES = [
    {
        timeRange: '00:00 - 05:00 (5 mins)',
        phaseName: 'Phase 1: Identity & Professional Introduction',
        description: 'Icebreaking, self-introduction, resume walk-through, and verification of student portfolio projects.',
        interviewerChecks: [
            'Clarity of speech and elevator pitch structure',
            'Honesty and authenticity in academic credentials',
            'Overview of primary tech stack (Java/Python/MERN)',
        ],
    },
    {
        timeRange: '05:00 - 20:00 (15 mins)',
        phaseName: 'Phase 2: Live DSA & Problem Solving Round',
        description: 'Solving 1 to 2 algorithmic coding problems on a live shared whiteboard/editor. Edge-case reasoning and complexity analysis.',
        interviewerChecks: [
            'Thinking out loud and asking clarifying questions',
            'Optimal Time & Space complexity calculation',
            'Clean syntax, modular functions, and edge case handling',
        ],
    },
    {
        timeRange: '20:00 - 35:00 (15 mins)',
        phaseName: 'Phase 3: Core CS & System Architecture Defense',
        description: 'In-depth questions on Object-Oriented Programming, Database Normalization/Indexing, Operating Systems, and Final Year Project architecture.',
        interviewerChecks: [
            'Understanding of project architecture & schema design',
            'Explainability of tradeoffs (e.g. SQL vs NoSQL, REST APIs)',
            'Core fundamentals in OS threads and memory management',
        ],
    },
    {
        timeRange: '35:00 - 42:00 (7 mins)',
        phaseName: 'Phase 4: Behavioral & HR Scenarios (STAR Method)',
        description: 'Situational judgment questions, conflict resolution, work ethic, and company-specific culture fit.',
        interviewerChecks: [
            'Usage of Situation, Task, Action, Result (STAR) format',
            'Enthusiasm for Day-1 joining and relocation readiness',
            'Questions asked to the interviewer at the conclusion',
        ],
    },
    {
        timeRange: '42:00 - 50:00 (8 mins)',
        phaseName: 'Phase 5: Live Rubric Scoring & Constructive Feedback',
        description: 'Senior mentor summarizes performance, rates key competencies, assigns scores out of 100, and provides concrete improvement items.',
        interviewerChecks: [
            'Review of areas done well vs areas needing practice',
            'Direct recommendations for Day-1 clearance',
            'Immediate recording of score in Student Readiness Dashboard',
        ],
    },
];
export const MockInterviews = () => {
    const { user } = useAuth();
    const [sessions, setSessions] = useState(() => storageService.getMockInterviews());
    const [showBookModal, setShowBookModal] = useState(false);
    const [showEvaluateModal, setShowEvaluateModal] = useState(null);
    const [selectedProcessSession, setSelectedProcessSession] = useState(null);
    const [copiedId, setCopiedId] = useState(null);
    // Booking state
    const [targetCompany, setTargetCompany] = useState('Zoho Corporation');
    const [interviewType, setInterviewType] = useState('Technical (DSA & Core)');
    const [preferredDate, setPreferredDate] = useState('2026-10-06');
    const [preferredTime, setPreferredTime] = useState('06:00 PM IST');
    const [selectedMentor, setSelectedMentor] = useState({
        id: 'usr_senior_07',
        name: 'Sanjay Vignesh (Amazon SDE)',
    });
    // Senior evaluation state
    const [evalScore, setEvalScore] = useState(85);
    const [evalTech, setEvalTech] = useState(8);
    const [evalComm, setEvalComm] = useState(8);
    const [evalProblem, setEvalProblem] = useState(9);
    const [evalStrengths, setEvalStrengths] = useState('Strong logical clarity in pointer arithmetic and 2D arrays.');
    const [evalImprovements, setEvalImprovements] = useState('Explain edge cases aloud before diving into code.');
    const isSenior = user?.role === 'senior';
    const getGmeetId = (sessionId) => {
        // Generate standard gmeet ID pattern: meet.google.com/nec-xxx-yyy
        const cleanId = sessionId.replace(/[^a-zA-Z0-9]/g, '').slice(-6).toLowerCase() || 'mock01';
        return `nec-int-${cleanId}`;
    };
    const handleCopyGmeet = (gmeetId) => {
        navigator.clipboard.writeText(`https://meet.google.com/${gmeetId}`);
        setCopiedId(gmeetId);
        setTimeout(() => setCopiedId(null), 2000);
    };
    const handleBookSubmit = (e) => {
        e.preventDefault();
        if (!user)
            return;
        const booked = storageService.bookMockInterview({
            studentId: user.id,
            studentName: user.name,
            mentorId: selectedMentor.id,
            mentorName: selectedMentor.name,
            roleOrCompany: `${targetCompany} Mock Interview`,
            scheduledDate: preferredDate,
            scheduledTime: preferredTime,
            type: interviewType,
        });
        setSessions(storageService.getMockInterviews());
        setShowBookModal(false);
        alert('Mock interview booked successfully! A unique Google Meet room has been generated.');
    };
    const handleCompleteEvaluation = (e) => {
        e.preventDefault();
        if (!showEvaluateModal)
            return;
        storageService.updateMockInterview(showEvaluateModal.id, {
            status: 'Completed',
            score: evalScore,
            feedback: {
                technicalSkills: evalTech,
                communication: evalComm,
                problemSolving: evalProblem,
                strengths: evalStrengths,
                areasOfImprovement: evalImprovements,
                recommendationNotes: 'Recommended for Day-1 drive selection.',
            },
        });
        storageService.recordMockInterviewCompleted(showEvaluateModal.studentId);
        storageService.addFeedbackEntry({
            userId: showEvaluateModal.studentId,
            sourceType: 'Mock Interview',
            mentorName: showEvaluateModal.mentorName,
            topic: showEvaluateModal.roleOrCompany,
            score: evalScore,
            keyTakeaways: evalStrengths,
            actionItems: evalImprovements,
        });
        if (user?.seniorId) {
            const current = storageService.getSeniorContributions(user.seniorId);
            storageService.updateSeniorContribution(user.seniorId, {
                mockInterviewsConducted: current.mockInterviewsConducted + 1,
                feedbackSubmitted: current.feedbackSubmitted + 1,
            });
        }
        setSessions(storageService.getMockInterviews());
        setShowEvaluateModal(null);
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Video className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
              Placement Simulation
            </span>
          </div>
          <h2 className="text-xl font-bold">1-on-1 Mock Interviews with Google Meet</h2>
          <p className="text-xs text-blue-200">
            Real interview simulations with Google Meet IDs. Detailed process agendas and senior rubric scores.
          </p>
        </div>

        <button onClick={() => setShowBookModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
          <Plus className="w-4 h-4"/>
          <span>Book Mock Interview</span>
        </button>
      </div>

      {/* Complete Interview Process Overview Strip */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-blue-700"/>
            <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wide">
              Complete Mock Interview Process (50 Minutes Breakdown)
            </h3>
          </div>
          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            Standard Day-1 Protocol
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 text-xs">
          {INTERVIEW_PROCESS_PHASES.map((p, idx) => (<div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-[10px] font-mono font-bold text-blue-700 block">
                {p.timeRange}
              </span>
              <p className="font-bold text-slate-800 text-[11px] leading-tight">{p.phaseName.split(':')[1]}</p>
              <p className="text-[10px] text-slate-500 line-clamp-2">{p.description}</p>
            </div>))}
        </div>
      </div>

      {/* Sessions Grid */}
      <div className="space-y-3">
        <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">Scheduled & Past Mock Sessions</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sessions.map((s) => {
            const gmeetId = getGmeetId(s.id);
            return (<div key={s.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-100">
                        {s.type}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-1">{s.roleOrCompany}</h4>
                    </div>
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${s.status === 'Completed'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-blue-100 text-blue-800'}`}>
                      {s.status}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-slate-600 text-[11px]">
                    <div className="flex items-center gap-2">
                      <UserCheck className="w-3.5 h-3.5 text-slate-400"/>
                      <span>Senior Evaluator: <strong>{s.mentorName}</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400"/>
                      <span>Date & Time: {s.scheduledDate} · {s.scheduledTime}</span>
                    </div>
                  </div>

                  {/* GOOGLE MEET ID BADGE & DIRECT LINK */}
                  <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-200 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 truncate">
                      <Video className="w-4 h-4 text-blue-700 shrink-0"/>
                      <div className="truncate">
                        <span className="text-[10px] uppercase font-bold text-blue-800 block">
                          Google Meet Session ID
                        </span>
                        <code className="text-xs font-mono font-bold text-slate-900 truncate">
                          {gmeetId}
                        </code>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button onClick={() => handleCopyGmeet(gmeetId)} title="Copy GMeet Link" className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition cursor-pointer">
                        <Copy className="w-3.5 h-3.5 text-slate-600"/>
                      </button>
                      <a href={`https://meet.google.com/${gmeetId}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-lg transition text-[11px]">
                        <span>Join GMeet</span>
                        <ExternalLink className="w-3 h-3"/>
                      </a>
                    </div>
                  </div>

                  {copiedId === gmeetId && (<p className="text-[10px] text-emerald-600 font-bold">● Google Meet URL copied to clipboard!</p>)}

                  {s.status === 'Completed' && s.score && (<div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                      <span className="font-bold text-emerald-900">Score Conferred:</span>
                      <span className="font-black text-sm text-emerald-800">{s.score}/100</span>
                    </div>)}
                </div>

                {/* Process View Details and Senior Evaluate */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button onClick={() => setSelectedProcessSession(s)} className="flex items-center gap-1 text-blue-900 font-bold hover:underline cursor-pointer">
                    <span>View What Happens in this Session</span>
                    <ChevronRight className="w-3.5 h-3.5"/>
                  </button>

                  {isSenior && s.status === 'Scheduled' && (<button onClick={() => setShowEvaluateModal(s)} className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-bold rounded-lg transition cursor-pointer text-[11px]">
                      Evaluate Candidate
                    </button>)}
                </div>
              </div>);
        })}
        </div>
      </div>

      {/* MODAL: VIEW WHAT HAPPENS IN THIS SESSION (COMPLETE PROCESS) */}
      {selectedProcessSession && (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden my-4 text-xs space-y-4 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Video className="w-5 h-5 text-amber-400"/>
                <div>
                  <h3 className="font-bold text-sm">Session Flow & Agenda</h3>
                  <p className="text-[10px] text-slate-400">
                    {selectedProcessSession.roleOrCompany} · Mentor: {selectedProcessSession.mentorName}
                  </p>
                </div>
              </div>
              <button onClick={() => setSelectedProcessSession(null)} className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer">
                <X className="w-5 h-5"/>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Google Meet Connection Box */}
              <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] font-bold uppercase text-blue-800">Assigned Google Meet ID</p>
                  <p className="text-sm font-mono font-black text-slate-900 mt-0.5">
                    {getGmeetId(selectedProcessSession.id)}
                  </p>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Live video stream opens directly in your Google Meet browser or app.
                  </p>
                </div>

                <a href={`https://meet.google.com/${getGmeetId(selectedProcessSession.id)}`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl shadow-xs shrink-0">
                  <Video className="w-4 h-4"/>
                  <span>Launch Google Meet Room</span>
                </a>
              </div>

              {/* What Happens in that Session: Step-by-Step Agenda */}
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-slate-900">
                  What Happens in this Session (Step-by-Step Timeline):
                </h4>

                <div className="space-y-3">
                  {INTERVIEW_PROCESS_PHASES.map((phase, idx) => (<div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{phase.phaseName}</span>
                        <span className="text-[10px] font-mono font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
                          {phase.timeRange}
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px]">{phase.description}</p>

                      <div className="pt-2 border-t border-slate-100">
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Interviewer Checks:</p>
                        <ul className="mt-1 space-y-1 text-[11px] text-slate-700">
                          {phase.interviewerChecks.map((chk, cIdx) => (<li key={cIdx} className="flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0"/>
                              <span>{chk}</span>
                            </li>))}
                        </ul>
                      </div>
                    </div>))}
                </div>
              </div>

              {/* Candidate Preparation Checklist */}
              <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                <p className="font-bold text-amber-950">Pre-Session Student Checklist:</p>
                <div className="space-y-1 text-slate-700 text-[11px]">
                  <p>✔ Connect 5 minutes early to test microphone and camera.</p>
                  <p>✔ Have an IDE (VS Code, Eclipse, or online compiler) open to share screen.</p>
                  <p>✔ Keep a physical notepad and pen ready for tracing algorithms.</p>
                </div>
              </div>
            </div>
          </div>
        </div>)}

      {/* Senior Evaluation Modal */}
      {showEvaluateModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-4">
            <h3 className="text-base font-bold text-slate-900">Evaluate Candidate Mock Interview</h3>
            <p className="text-slate-500">Candidate: <strong>{showEvaluateModal.studentName}</strong></p>

            <form onSubmit={handleCompleteEvaluation} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Overall Placement Readiness Score (0 - 100)</label>
                <input type="number" min="0" max="100" value={evalScore} onChange={(e) => setEvalScore(Number(e.target.value))} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-slate-600 block mb-1">Tech (1-10)</label>
                  <input type="number" min="1" max="10" value={evalTech} onChange={(e) => setEvalTech(Number(e.target.value))} className="w-full px-2 py-1.5 border rounded-lg"/>
                </div>
                <div>
                  <label className="text-slate-600 block mb-1">Comm (1-10)</label>
                  <input type="number" min="1" max="10" value={evalComm} onChange={(e) => setEvalComm(Number(e.target.value))} className="w-full px-2 py-1.5 border rounded-lg"/>
                </div>
                <div>
                  <label className="text-slate-600 block mb-1">Logic (1-10)</label>
                  <input type="number" min="1" max="10" value={evalProblem} onChange={(e) => setEvalProblem(Number(e.target.value))} className="w-full px-2 py-1.5 border rounded-lg"/>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Key Strengths</label>
                <input type="text" value={evalStrengths} onChange={(e) => setEvalStrengths(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Action Items & Improvements</label>
                <textarea rows={3} value={evalImprovements} onChange={(e) => setEvalImprovements(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowEvaluateModal(null)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Submit Official Scorecard
                </button>
              </div>
            </form>
          </div>
        </div>)}

      {/* Book Mock Interview Modal */}
      {showBookModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Book 1-on-1 Mock Interview</h3>
            <p className="text-slate-500">
              A private Google Meet ID will be assigned automatically for your 50-minute slot.
            </p>

            <form onSubmit={handleBookSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Company</label>
                <select value={targetCompany} onChange={(e) => setTargetCompany(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white">
                  <option value="Zoho Corporation">Zoho Corporation (Round 2 & 3 DSA)</option>
                  <option value="TCS Digital">TCS Digital / Prime</option>
                  <option value="Cognizant GenC Next">Cognizant GenC Next</option>
                  <option value="Amazon SDE">Amazon SDE 1</option>
                  <option value="Soliton Technologies">Soliton Technologies</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Interview Type</label>
                <select value={interviewType} onChange={(e) => setInterviewType(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white">
                  <option value="Technical (DSA & Core)">Technical (DSA & Core CS)</option>
                  <option value="System Design">System Design & OOP</option>
                  <option value="HR & Behavioral">HR & Behavioral (STAR Method)</option>
                  <option value="Company-Specific Mock">Company-Specific Full Round Simulation</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Preferred Date</label>
                  <input type="date" required value={preferredDate} onChange={(e) => setPreferredDate(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Time Slot</label>
                  <input type="text" required value={preferredTime} onChange={(e) => setPreferredTime(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowBookModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Confirm & Generate GMeet
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
