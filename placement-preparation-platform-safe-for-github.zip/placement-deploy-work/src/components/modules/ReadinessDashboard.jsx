import React, { useState, useEffect } from 'react';
import { Award, CheckCircle2, Brain, Video, Code2, } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { COLLEGE_IMAGES } from '../../assets/collegeImages';
export const ReadinessDashboard = () => {
    const { user } = useAuth();
    const [progress, setProgress] = useState(null);
    const [companies, setCompanies] = useState([]);
    useEffect(() => {
        if (user) {
            setProgress(storageService.getUserProgress(user.id));
            setCompanies(storageService.getCompanies());
        }
    }, [user]);
    if (!progress || !user)
        return null;
    const score = progress.readinessScore;
    // Breakdown metrics
    const technicalScore = Math.min(100, Math.round(((progress.codingProblemsSolved || 28) / 40) * 100));
    const aptitudeScore = Math.min(100, Math.round((progress.questionsCorrect / Math.max(1, progress.questionsAttempted)) * 100));
    const interviewScore = Math.min(100, progress.mockInterviewsAttended * 35);
    const communicationScore = Math.min(100, progress.mockGDsAttended * 30 + 40);
    return (<div className="space-y-5">
      {/* Sleek Minimal Header */}
      <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              Official Evaluation
            </span>
            <span className="text-xs text-slate-400">NEC Placement Cell</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Placement Readiness Dashboard
          </h2>
          <p className="text-xs text-slate-300">
            Real-time qualification analytics modeled on Zoho, TCS Digital, Cognizant, Soliton, and Amazon criteria.
          </p>
        </div>

        {/* Real-time Readiness Score */}
        <div className="bg-slate-800/80 rounded-xl p-4 border border-slate-700/80 text-center w-full sm:w-56 shrink-0 flex sm:flex-col items-center justify-between sm:justify-center gap-2">
          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Overall Score</p>
          <div className="text-3xl font-black text-white tracking-tight">
            {score}<span className="text-sm text-emerald-400 font-semibold">/100</span>
          </div>
          <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded border border-emerald-800/60">
            {score >= 70 ? 'Day-1 Drive Ready' : 'In Progress'}
          </span>
        </div>
      </div>

      {/* 4 Dimension Skill Assessment Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Technical & Coding */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-900 flex items-center justify-center font-bold">
                <Code2 className="w-4 h-4 text-blue-800"/>
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Technical DSA</h4>
                <p className="text-[10px] text-slate-500">Problem Solving</p>
              </div>
            </div>
            <span className="text-sm font-black text-blue-900">{technicalScore}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div className="bg-blue-600 h-2 rounded-full transition-all duration-700" style={{ width: `${technicalScore}%` }}/>
          </div>
          <p className="text-[11px] text-slate-600">
            {progress.codingProblemsSolved || 28} solved across Arrays, Strings, and DP.
          </p>
        </div>

        {/* Aptitude Accuracy */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-900 flex items-center justify-center font-bold">
                <Brain className="w-4 h-4 text-emerald-800"/>
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Speed Aptitude</h4>
                <p className="text-[10px] text-slate-500">Quant & Reasoning</p>
              </div>
            </div>
            <span className="text-sm font-black text-emerald-800">{aptitudeScore}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div className="bg-emerald-600 h-2 rounded-full transition-all duration-700" style={{ width: `${aptitudeScore}%` }}/>
          </div>
          <p className="text-[11px] text-slate-600">
            {progress.questionsCorrect} correct answers out of {progress.questionsAttempted} attempted.
          </p>
        </div>

        {/* Mock Interview Standing */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-900 flex items-center justify-center font-bold">
                <Video className="w-4 h-4 text-purple-800"/>
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Mock Interviews</h4>
                <p className="text-[10px] text-slate-500">Google Meet 1-on-1</p>
              </div>
            </div>
            <span className="text-sm font-black text-purple-900">{interviewScore}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div className="bg-purple-600 h-2 rounded-full transition-all duration-700" style={{ width: `${interviewScore}%` }}/>
          </div>
          <p className="text-[11px] text-slate-600">
            {progress.mockInterviewsAttended} completed sessions with senior rubric evaluations.
          </p>
        </div>

        {/* Group Discussion & Communication */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold">
                <Award className="w-4 h-4 text-amber-800"/>
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-900">Communication & GD</h4>
                <p className="text-[10px] text-slate-500">Group Articulation</p>
              </div>
            </div>
            <span className="text-sm font-black text-amber-900">{communicationScore}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div className="bg-amber-500 h-2 rounded-full transition-all duration-700" style={{ width: `${communicationScore}%` }}/>
          </div>
          <p className="text-[11px] text-slate-600">
            {progress.mockGDsAttended} group discussions attended with debate scores.
          </p>
        </div>
      </div>

      {/* Target Companies Readiness Matrix */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900">Target Companies Qualification Status</h3>
            <p className="text-xs text-slate-500">Predicted selection odds based on past NEC placement round patterns</p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 bg-blue-50 text-blue-900 rounded-lg border border-blue-200">
            Updated Today
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {companies.slice(0, 6).map((c) => {
            const reqScore = c.tier === 'Tier 1 / Product' ? 82 : c.tier === 'Tier 2 / Tech' ? 74 : 65;
            const isQualified = score >= reqScore;
            return (<div key={c.id} className={`p-4 rounded-xl border transition ${isQualified
                    ? 'border-emerald-300 bg-emerald-50/30'
                    : 'border-slate-200 bg-slate-50/50'}`}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{c.name}</h4>
                    <span className="text-[10px] text-slate-500 font-semibold">
                      {(c.jobRoles && c.jobRoles[0]) || 'Software Engineer'} · {c.packageRange}
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isQualified
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'}`}>
                    {isQualified ? 'Ready' : `Need ${reqScore - score} pts`}
                  </span>
                </div>

                <div className="space-y-1 text-[11px] text-slate-600">
                  <div className="flex items-center justify-between">
                    <span>Benchmark Cutoff:</span>
                    <span className="font-bold text-slate-800">{reqScore}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Your Score:</span>
                    <span className="font-bold text-slate-900">{score}%</span>
                  </div>
                </div>
              </div>);
        })}
        </div>
      </div>

      {/* Main Building Facade & Preparation Action Checklist */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col lg:flex-row items-center gap-6">
        <div className="w-full lg:w-1/3 rounded-xl overflow-hidden border border-slate-200 shadow-sm shrink-0">
          <img src={COLLEGE_IMAGES.mainBuilding} alt="NEC Main Academic Block" className="w-full h-44 object-cover"/>
          <div className="p-2 bg-slate-900 text-white text-[10px] flex items-center justify-between">
            <span>National Engineering College Campus</span>
            <span className="text-amber-300 font-bold">Kovilpatti</span>
          </div>
        </div>

        <div className="flex-1 space-y-3">
          <h4 className="font-bold text-sm text-slate-900">Recommended Steps to Reach 90+ Score</h4>
          <div className="space-y-2 text-xs">
            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"/>
              <div>
                <p className="font-bold text-slate-800">Complete 5 Dynamic Programming Problems</p>
                <p className="text-[11px] text-slate-500">Crucial for Zoho Advanced Round 3 and Amazon SDE 1.</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"/>
              <div>
                <p className="font-bold text-slate-800">Schedule 1-on-1 Mock Interview with Google Meet</p>
                <p className="text-[11px] text-slate-500">Get evaluated by placed seniors and receive a comprehensive score report.</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"/>
              <div>
                <p className="font-bold text-slate-800">Download and Solve PDF Question Papers</p>
                <p className="text-[11px] text-slate-500">Practice full-length timed question sets for TCS NQT and Cognizant GenC.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);
};
