import React, { useState } from 'react';
import { Award, Plus } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const InterviewExperiences = () => {
    const { user } = useAuth();
    const [experiences, setExperiences] = useState(() => storageService.getInterviewExperiences());
    const [selectedExp, setSelectedExp] = useState(experiences[0] || null);
    const [showShareModal, setShowShareModal] = useState(false);
    // Contribution state
    const [newExp, setNewExp] = useState({
        companyName: 'Zoho Corporation',
        jobRole: 'Software Developer',
        packageOffered: '8.5 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        roundName: 'Round 1: Screening & C MCQs',
        questionsAsked: 'Pointers in C, 2D Array spiral traversal, Matrix logic',
        experienceText: 'Detailed technical discussion with the panel. Explaining time complexity helped me clear the round.',
        generalTips: 'Practice typing code without IDE autocomplete and review basics of pointers.',
    });
    const isSenior = user?.role === 'senior';
    const handleShareSubmit = (e) => {
        e.preventDefault();
        const created = storageService.addInterviewExperience({
            companyName: newExp.companyName,
            studentName: user ? `${user.name} (${user.seniorId || 'Senior'})` : 'Placed Senior',
            batch: '2026 Passout',
            jobRole: newExp.jobRole,
            packageOffered: newExp.packageOffered,
            verdict: newExp.verdict,
            difficulty: newExp.difficulty,
            rounds: [
                {
                    roundName: newExp.roundName,
                    type: 'Technical Round 1',
                    duration: '60 mins',
                    questionsAsked: newExp.questionsAsked.split(',').map((q) => q.trim()),
                    experience: newExp.experienceText,
                },
            ],
            generalTips: newExp.generalTips,
            verifiedByMentorId: user?.seniorId || 'SEN003',
        });
        setExperiences(storageService.getInterviewExperiences());
        setSelectedExp(created);
        setShowShareModal(false);
        // Update senior contribution counter if senior
        if (user?.seniorId) {
            const current = storageService.getSeniorContributions(user.seniorId);
            storageService.updateSeniorContribution(user.seniorId, {
                interviewExperiencesAdded: current.interviewExperiencesAdded + 1,
            });
        }
    };
    const handleSelectExp = (exp) => {
        setSelectedExp(exp);
        if (user) {
            storageService.recordRecentlyAccessed(user.id, {
                type: 'experience',
                title: `${exp.companyName} Interview Experience`,
                subtext: `Shared by ${exp.studentName}`,
                link: 'interviewExperiences',
            });
        }
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Award className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 03</span>
          </div>
          <h2 className="text-xl font-bold">Interview Experiences</h2>
          <p className="text-xs text-blue-200">
            Real interview debriefs, actual questions asked, and candidate advice from successful NEC placement drives.
          </p>
        </div>

        {isSenior && (<button onClick={() => setShowShareModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
            <Plus className="w-4 h-4"/>
            <span>Share My Interview Experience</span>
          </button>)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Experience List */}
        <div className="lg:col-span-5 space-y-3">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Verified Experiences ({experiences.length})
          </p>
          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {experiences.map((exp) => {
            const isSelected = selectedExp?.id === exp.id;
            return (<div key={exp.id} onClick={() => handleSelectExp(exp)} className={`p-4 rounded-xl border text-left transition cursor-pointer ${isSelected
                    ? 'border-blue-700 bg-blue-50/70 shadow-xs ring-1 ring-blue-700'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'}`}>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{exp.companyName}</h4>
                      <p className="text-[11px] text-slate-500 font-medium">By {exp.studentName}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${exp.verdict === 'Selected'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'}`}>
                      {exp.verdict}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100 mt-2">
                    <span className="font-bold text-slate-700">{exp.jobRole}</span>
                    <span className="font-extrabold text-blue-900">{exp.packageOffered}</span>
                  </div>
                </div>);
        })}
          </div>
        </div>

        {/* Experience Deep Dive Detail */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs text-xs space-y-5">
          {selectedExp ? (<>
              <div className="border-b border-slate-100 pb-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                    Drive Verdict: {selectedExp.verdict}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">Batch: {selectedExp.batch}</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-1.5">{selectedExp.companyName} Drive Breakdown</h3>
                <p className="text-slate-600 mt-0.5">
                  Role: <strong className="text-slate-800">{selectedExp.jobRole}</strong> ({selectedExp.packageOffered})
                </p>
              </div>

              {/* Rounds Breakdown */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 text-xs">Drive Rounds & Interview Log</h4>
                {selectedExp.rounds.map((round, idx) => (<div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 text-xs">{round.roundName}</span>
                      <span className="text-[10px] bg-white px-2 py-0.5 rounded border font-mono text-slate-500">
                        Duration: {round.duration}
                      </span>
                    </div>

                    <div>
                      <p className="font-bold text-slate-700 text-[11px] mb-1">Questions Asked by Panel:</p>
                      <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1">
                        {round.questionsAsked.map((q, qIdx) => (<li key={qIdx} className="leading-relaxed">
                            {q}
                          </li>))}
                      </ul>
                    </div>

                    <div className="pt-2 border-t border-slate-200/60">
                      <p className="font-bold text-slate-700 text-[11px] mb-0.5">Round Experience:</p>
                      <p className="text-slate-600 leading-relaxed italic">"{round.experience}"</p>
                    </div>
                  </div>))}
              </div>

              {/* Tips */}
              <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200">
                <p className="font-bold text-blue-900 mb-1">Key Advice for Juniors & Pre-Finals:</p>
                <p className="text-slate-700 leading-relaxed">{selectedExp.generalTips}</p>
              </div>
            </>) : (<p className="text-slate-400 italic">Select an interview experience from the left to read.</p>)}
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white rounded-2xl p-6 shadow-2xl border max-h-[85vh] overflow-y-auto text-xs">
            <h3 className="text-base font-bold text-slate-900 mb-1">Contribute Your Placement Experience</h3>
            <p className="text-slate-500 mb-4">Empower juniors at National Engineering College with real drive insights</p>

            <form onSubmit={handleShareSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Company Name</label>
                  <input type="text" required value={newExp.companyName} onChange={(e) => setNewExp({ ...newExp, companyName: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Job Role</label>
                  <input type="text" required value={newExp.jobRole} onChange={(e) => setNewExp({ ...newExp, jobRole: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">CTC Package Offered</label>
                  <input type="text" required placeholder="e.g. 7.5 LPA" value={newExp.packageOffered} onChange={(e) => setNewExp({ ...newExp, packageOffered: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Verdict</label>
                  <select value={newExp.verdict} onChange={(e) => setNewExp({ ...newExp, verdict: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none">
                    <option value="Selected">Selected</option>
                    <option value="Shortlisted for Next Round">Shortlisted for Next Round</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Round Name</label>
                <input type="text" required value={newExp.roundName} onChange={(e) => setNewExp({ ...newExp, roundName: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Questions Asked (comma-separated)</label>
                <textarea rows={2} required value={newExp.questionsAsked} onChange={(e) => setNewExp({ ...newExp, questionsAsked: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Interview Narrative</label>
                <textarea rows={2} required value={newExp.experienceText} onChange={(e) => setNewExp({ ...newExp, experienceText: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Advice for Juniors</label>
                <textarea rows={2} required value={newExp.generalTips} onChange={(e) => setNewExp({ ...newExp, generalTips: e.target.value })} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowShareModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Publish Experience
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
