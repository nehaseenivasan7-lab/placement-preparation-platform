import React, { useState } from 'react';
import { Users, Search, MessageSquare, Calendar } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const MentorshipView = () => {
    const { user } = useAuth();
    const [seniors, setSeniors] = useState(() => storageService.getUsers().filter((u) => u.role === 'senior'));
    const [specializationFilter, setSpecializationFilter] = useState('All');
    const [search, setSearch] = useState('');
    const [selectedSenior, setSelectedSenior] = useState(null);
    // Ask doubt modal state
    const [showDoubtModal, setShowDoubtModal] = useState(false);
    const [doubtSubject, setDoubtSubject] = useState('');
    const [doubtMessage, setDoubtMessage] = useState('');
    // 1-on-1 session modal state
    const [showSessionModal, setShowSessionModal] = useState(false);
    const [sessionTopic, setSessionTopic] = useState('');
    const [sessionTargetCompany, setSessionTargetCompany] = useState('Zoho Corporation');
    const [sessionDate, setSessionDate] = useState('2026-10-08');
    // Doubts tab state
    const [activeSubTab, setActiveSubTab] = useState('find');
    const [doubts, setDoubts] = useState(() => storageService.getDoubts());
    const specializations = [
        'All',
        'Company Explorer',
        'Interview Experience',
        'Question Bank',
        'Mock Interview',
        'Mock GD',
        'Round Resources',
    ];
    const filtered = seniors.filter((s) => {
        const matchesSpec = specializationFilter === 'All' || s.specialization === specializationFilter;
        const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
            (s.currentCompany && s.currentCompany.toLowerCase().includes(search.toLowerCase())) ||
            (s.skills && s.skills.some((sk) => sk.toLowerCase().includes(search.toLowerCase())));
        return matchesSpec && matchesSearch;
    });
    const handleAskDoubtSubmit = (e) => {
        e.preventDefault();
        if (!user || !selectedSenior)
            return;
        storageService.askDoubt({
            studentId: user.id,
            studentName: user.name,
            studentRole: user.role,
            mentorId: selectedSenior.id,
            mentorName: selectedSenior.name,
            specializationTarget: selectedSenior.specialization || 'Company Explorer',
            subject: doubtSubject,
            message: doubtMessage,
        });
        setDoubts(storageService.getDoubts());
        setShowDoubtModal(false);
        setDoubtSubject('');
        setDoubtMessage('');
        alert(`Your doubt has been submitted to ${selectedSenior.name}! You will be alerted when they reply.`);
    };
    const handleBookSessionSubmit = (e) => {
        e.preventDefault();
        if (!user || !selectedSenior)
            return;
        storageService.createMentorshipRequest({
            studentId: user.id,
            studentName: user.name,
            studentEmail: user.email,
            mentorId: selectedSenior.id,
            mentorName: selectedSenior.name,
            specialization: selectedSenior.specialization || 'General Guidance',
            targetCompany: sessionTargetCompany,
            topic: sessionTopic,
            preferredDate: sessionDate,
        });
        storageService.recordMentorshipSession(user.id);
        setShowSessionModal(false);
        setSessionTopic('');
        alert(`Mentorship request sent to ${selectedSenior.name}!`);
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 12</span>
          </div>
          <h2 className="text-xl font-bold">Specialized Senior Mentorship Ecosystem</h2>
          <p className="text-xs text-blue-200">
            Connect directly with verified placed NEC seniors according to their domain specializations.
          </p>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex gap-2 p-1 bg-white/10 rounded-xl border border-white/20 text-xs">
          <button onClick={() => setActiveSubTab('find')} className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${activeSubTab === 'find' ? 'bg-amber-400 text-blue-950 shadow-xs' : 'text-blue-100 hover:text-white'}`}>
            Find Placed Seniors
          </button>
          <button onClick={() => setActiveSubTab('my_doubts')} className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${activeSubTab === 'my_doubts' ? 'bg-amber-400 text-blue-950 shadow-xs' : 'text-blue-100 hover:text-white'}`}>
            My Doubts ({doubts.filter((d) => d.studentId === user?.id).length})
          </button>
        </div>
      </div>

      {activeSubTab === 'find' ? (<>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs w-full sm:w-auto">
              {specializations.map((spec) => (<button key={spec} onClick={() => setSpecializationFilter(spec)} className={`px-3 py-1.5 rounded-xl font-bold transition shrink-0 cursor-pointer ${specializationFilter === spec
                    ? 'bg-blue-900 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                  {spec}
                </button>))}
            </div>

            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
              <input type="text" placeholder="Search mentors by company (Zoho, TCS, Amazon), skill, or name..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-600 transition"/>
            </div>
          </div>

          {/* Mentors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((mentor) => (<div key={mentor.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-blue-300 transition space-y-4 text-xs">
                <div>
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-12 h-12 rounded-xl bg-linear-to-br from-blue-900 to-indigo-900 text-amber-300 flex items-center justify-center font-black text-sm shrink-0 border border-blue-800 shadow-2xs">
                      {mentor.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-sm text-slate-900 truncate">{mentor.name}</h4>
                        <span className="text-[10px] font-mono text-amber-700 font-bold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                          {mentor.seniorId}
                        </span>
                      </div>
                      <p className="text-[11px] font-semibold text-blue-800">{mentor.currentCompany}</p>
                      <p className="text-[10px] text-slate-500 truncate">{mentor.jobRole}</p>
                    </div>
                  </div>

                  {/* Specialization Badge */}
                  <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 space-y-1 mb-3">
                    <span className="text-[10px] uppercase font-bold text-blue-800 tracking-wider">
                      Primary Specialization:
                    </span>
                    <p className="font-bold text-slate-900 text-xs">{mentor.specialization || 'Company Explorer'}</p>
                  </div>

                  {/* Skills tags */}
                  <div className="flex flex-wrap gap-1">
                    {mentor.skills?.slice(0, 4).map((sk, idx) => (<span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[10px] font-medium rounded-md">
                        {sk}
                      </span>))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button onClick={() => {
                    setSelectedSenior(mentor);
                    setShowDoubtModal(true);
                }} className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer text-[11px]">
                    <MessageSquare className="w-3.5 h-3.5 text-blue-700"/>
                    <span>Ask Doubt</span>
                  </button>
                  <button onClick={() => {
                    setSelectedSenior(mentor);
                    setShowSessionModal(true);
                }} className="flex-1 py-1.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer text-[11px] shadow-xs">
                    <Calendar className="w-3.5 h-3.5 text-amber-300"/>
                    <span>1-on-1 Mentorship</span>
                  </button>
                </div>
              </div>))}
          </div>
        </>) : (
        /* My Doubts Panel */
        <div className="space-y-4">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Your Questions to Senior Mentors
          </p>
          {doubts.filter((d) => d.studentId === user?.id).length === 0 ? (<div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
              <MessageSquare className="w-8 h-8 mx-auto text-slate-300 mb-2"/>
              <p className="font-bold text-slate-800">No questions asked yet</p>
              <p className="text-slate-400 mt-0.5">
                Browse our placed seniors on the Find Mentors tab and ask your technical/interview doubts directly!
              </p>
            </div>) : (doubts
                .filter((d) => d.studentId === user?.id)
                .map((d) => (<div key={d.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900">
                        {d.specializationTarget}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-1">{d.subject}</h4>
                    </div>
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${d.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                      {d.status}
                    </span>
                  </div>

                  <p className="text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed">
                    "{d.message}"
                  </p>

                  {d.reply ? (<div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 space-y-1">
                      <p className="font-bold text-blue-900">
                        Mentor Reply from {d.mentorName}:
                      </p>
                      <p className="text-slate-800 leading-relaxed font-medium">{d.reply}</p>
                    </div>) : (<p className="text-slate-400 italic text-[11px]">
                      Awaiting response from Senior Mentor {d.mentorName}...
                    </p>)}
                </div>)))}
        </div>)}

      {/* Ask Doubt Modal */}
      {showDoubtModal && selectedSenior && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Ask Question to {selectedSenior.name}</h3>
            <p className="text-slate-500">
              Specialization: <strong>{selectedSenior.specialization}</strong> ({selectedSenior.currentCompany})
            </p>

            <form onSubmit={handleAskDoubtSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Subject</label>
                <input type="text" required placeholder="e.g. How to prepare for Zoho Round 3 Railway System?" value={doubtSubject} onChange={(e) => setDoubtSubject(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Your Detailed Query</label>
                <textarea rows={4} required placeholder="Explain your preparation background, where you are stuck, or what advice you need..." value={doubtMessage} onChange={(e) => setDoubtMessage(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowDoubtModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Send Query
                </button>
              </div>
            </form>
          </div>
        </div>)}

      {/* 1-on-1 Mentorship Request Modal */}
      {showSessionModal && selectedSenior && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Schedule 1-on-1 Mentorship Session</h3>
            <p className="text-slate-500">
              Request guidance from {selectedSenior.name} ({selectedSenior.currentCompany})
            </p>

            <form onSubmit={handleBookSessionSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Company</label>
                <input type="text" required value={sessionTargetCompany} onChange={(e) => setSessionTargetCompany(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Session Agenda / Topic</label>
                <input type="text" required placeholder="e.g. Resume Review & Technical Interview Strategy" value={sessionTopic} onChange={(e) => setSessionTopic(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Preferred Date</label>
                <input type="date" required value={sessionDate} onChange={(e) => setSessionDate(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowSessionModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Send Mentorship Request
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
