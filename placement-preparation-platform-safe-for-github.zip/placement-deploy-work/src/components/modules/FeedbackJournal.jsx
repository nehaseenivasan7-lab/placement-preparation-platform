import React, { useState, useEffect } from 'react';
import { History, BookOpen, Plus, CheckCircle, TrendingUp } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
export const FeedbackJournal = () => {
    const { user } = useAuth();
    const [entries, setEntries] = useState([]);
    const [progress, setProgress] = useState(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [activeTab, setActiveTab] = useState('journal');
    // New self-reflection entry
    const [topic, setTopic] = useState('');
    const [sourceType, setSourceType] = useState('Self-Reflection');
    const [keyTakeaways, setKeyTakeaways] = useState('');
    const [actionItems, setActionItems] = useState('');
    const [score, setScore] = useState(80);
    useEffect(() => {
        if (user) {
            setEntries(storageService.getFeedbackEntries(user.id));
            setProgress(storageService.getUserProgress(user.id));
        }
    }, [user]);
    const handleAddSubmit = (e) => {
        e.preventDefault();
        if (!user)
            return;
        const created = storageService.addFeedbackEntry({
            userId: user.id,
            sourceType,
            topic,
            score: Number(score),
            keyTakeaways,
            actionItems,
            mentorName: user.name,
        });
        setEntries(storageService.getFeedbackEntries(user.id));
        setShowAddModal(false);
        setTopic('');
        setKeyTakeaways('');
        setActionItems('');
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <History className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">Module 18</span>
          </div>
          <h2 className="text-xl font-bold">Feedback Journal & Rewinders</h2>
          <p className="text-xs text-blue-200">
            Chronological reflection diary and rewinders dashboard to analyze preparation progress and mentor feedback over time.
          </p>
        </div>

        <div className="flex gap-2">
          <div className="flex p-1 bg-white/10 rounded-xl border border-white/20 text-xs">
            <button onClick={() => setActiveTab('journal')} className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${activeTab === 'journal' ? 'bg-amber-400 text-blue-950 shadow-xs' : 'text-blue-100 hover:text-white'}`}>
              Feedback Journal
            </button>
            <button onClick={() => setActiveTab('rewinders')} className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${activeTab === 'rewinders' ? 'bg-amber-400 text-blue-950 shadow-xs' : 'text-blue-100 hover:text-white'}`}>
              Rewinders Dashboard
            </button>
          </div>

          <button onClick={() => setShowAddModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-800 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer">
            <Plus className="w-4 h-4"/>
            <span>New Reflection</span>
          </button>
        </div>
      </div>

      {activeTab === 'journal' ? (
        /* FEEDBACK JOURNAL VIEW */
        <div className="space-y-4 max-w-3xl mx-auto">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Verified Mentor Reviews & Student Reflection Logs
          </p>

          {entries.length === 0 ? (<div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-xs text-slate-500 space-y-2">
              <BookOpen className="w-8 h-8 mx-auto text-slate-300"/>
              <p className="font-bold text-slate-800">No journal logs recorded yet</p>
              <p className="text-slate-400">
                Feedback from your completed mock interviews and self-reflections will be preserved here!
              </p>
            </div>) : (entries.map((entry) => (<div key={entry.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-100">
                      {entry.sourceType}
                    </span>
                    <h4 className="font-bold text-sm text-slate-900 mt-1">{entry.topic}</h4>
                  </div>
                  {entry.score && (<span className="text-xs font-black text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      {entry.score}/100
                    </span>)}
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 border border-slate-100">
                  <p className="font-bold text-slate-800 text-[11px]">Strengths & Key Takeaways:</p>
                  <p className="text-slate-700 leading-relaxed">{entry.keyTakeaways}</p>
                </div>

                <div className="p-3 bg-amber-50/70 rounded-xl space-y-1 border border-amber-200/80">
                  <p className="font-bold text-amber-950 text-[11px]">Action Items for Next Drive:</p>
                  <p className="text-amber-900 leading-relaxed">{entry.actionItems}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Evaluator / Mentor: {entry.mentorName || 'Self Reflection'}</span>
                  <span>{new Date(entry.createdAt).toLocaleDateString()}</span>
                </div>
              </div>)))}
        </div>) : (
        /* REWINDERS DASHBOARD VIEW */
        <div className="space-y-6 max-w-4xl mx-auto text-xs">
          <p className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Rewinders Engine: Historical Progress Timeline
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Practice Cumulative</span>
              <p className="text-2xl font-black text-blue-950">{progress?.questionsAttempted || 0}</p>
              <p className="text-[11px] text-slate-500 font-medium">Questions attempted across all modules</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Active Study Habit</span>
              <p className="text-2xl font-black text-amber-600">{progress?.studyStreakDays || 0} Days</p>
              <p className="text-[11px] text-slate-500 font-medium">Consecutive campus preparation days</p>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400">Dynamic Readiness</span>
              <p className="text-2xl font-black text-emerald-700">{progress?.readinessScore || 0}%</p>
              <p className="text-[11px] text-slate-500 font-medium">Calculated from verified submissions</p>
            </div>
          </div>

          {/* Historical look back cards */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h4 className="font-bold text-slate-900 text-sm">Key Milestone Rewinders</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <CheckCircle className="w-5 h-5 text-blue-700 shrink-0 mt-0.5"/>
                <div>
                  <p className="font-bold text-slate-900 text-xs">Platform Enrollment & Account Verification</p>
                  <p className="text-slate-600 mt-0.5">
                    Registered as official student at National Engineering College under Training & Placement Cell.
                  </p>
                  <span className="text-[10px] font-mono text-slate-400">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Active'}</span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <TrendingUp className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5"/>
                <div>
                  <p className="font-bold text-slate-900 text-xs">First Practice Session Completed</p>
                  <p className="text-slate-600 mt-0.5">
                    Practice Studio and Aptitude Practice recorded {progress?.questionsAttempted || 0} questions with {progress?.questionsCorrect || 0} correct solutions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>)}

      {/* Add Reflection Modal */}
      {showAddModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Add Feedback Reflection Entry</h3>
            <p className="text-slate-500">Record insights after a practice test or mentor call.</p>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Session / Topic Title</label>
                <input type="text" required placeholder="e.g. Zoho Mock Technical Round 1 Reflection" value={topic} onChange={(e) => setTopic(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Source Type</label>
                  <select value={sourceType} onChange={(e) => setSourceType(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg font-semibold bg-white">
                    <option value="Self-Reflection">Self-Reflection</option>
                    <option value="Mock Interview">Mock Interview</option>
                    <option value="Mock GD">Mock GD</option>
                    <option value="Mentorship">Mentorship</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Self-Score (0-100)</label>
                  <input type="number" min="0" max="100" value={score} onChange={(e) => setScore(Number(e.target.value))} className="w-full px-3 py-1.5 border rounded-lg font-bold"/>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Key Strengths & Learnings</label>
                <textarea rows={2} required value={keyTakeaways} onChange={(e) => setKeyTakeaways(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Concrete Next Action Steps</label>
                <textarea rows={2} required value={actionItems} onChange={(e) => setActionItems(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg outline-none"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-900 text-white rounded-lg font-bold hover:bg-blue-800">
                  Save Reflection
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
