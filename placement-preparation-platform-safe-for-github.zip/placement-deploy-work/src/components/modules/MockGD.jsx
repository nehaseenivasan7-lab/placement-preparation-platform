import React, { useState } from 'react';
import { Users, Calendar, Plus, CheckCircle, ExternalLink, Video, Copy, Info, CheckCircle2, X, ChevronRight, } from 'lucide-react';
import { storageService } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
const GD_PROCESS_STAGES = [
    {
        stageRange: '00:00 - 03:00 (3 mins)',
        stageName: 'Stage 1: Topic Reveal & Silent Brainstorming',
        description: 'The senior moderator announces the elimination topic. Candidates are given 1 minute of silent preparation to jot down structure, pros/cons, and statistical points.',
        evaluationRubric: [
            'Maintaining calm composure and pen-to-paper organization',
            'No interrupting or speaking out of turn before moderator green signal',
        ],
    },
    {
        stageRange: '03:00 - 08:00 (5 mins)',
        stageName: 'Stage 2: Individual Opening Statements',
        description: 'Each candidate has 30 to 45 seconds to state their primary thesis, defining the scope without monopolizing airtime.',
        evaluationRubric: [
            'Voice clarity, modulation, and direct eye contact with the webcam',
            'Concise thesis statement without rambling',
        ],
    },
    {
        stageRange: '08:00 - 18:00 (10 mins)',
        stageName: 'Stage 3: Free-Flow Moderated Debate & Synthesis',
        description: 'Open discussion floor. Candidates build upon peer arguments, respectfully introduce counter-perspectives, and facilitate silent peers.',
        evaluationRubric: [
            'Active listening and nodding etiquette on video',
            'Civil disagreement ("I see your point, however consider...")',
            'Bringing back discussion to the core topic when derailed',
        ],
    },
    {
        stageRange: '18:00 - 21:00 (3 mins)',
        stageName: 'Stage 4: Balanced Concluding Summaries',
        description: 'Selected candidates or volunteers deliver an unbiased 45-second summary encompassing points raised by both sides.',
        evaluationRubric: [
            'Reflecting collective viewpoints rather than personal bias',
            'Constructive forward-looking closing recommendation',
        ],
    },
    {
        stageRange: '21:00 - 25:00 (4 mins)',
        stageName: 'Stage 5: Live Evaluator Rubric Feedback & Scores',
        description: 'The senior evaluator breaks down scores for Content, Body Language, Leadership, and Listening for each participant.',
        evaluationRubric: [
            'Scorecard recorded directly into student placement profile',
            'Actionable advice for Day-1 mass elimination GD rounds',
        ],
    },
];
export const MockGD = () => {
    const { user } = useAuth();
    const [sessions, setSessions] = useState(() => storageService.getMockGDs());
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [selectedProcessGd, setSelectedProcessGd] = useState(null);
    const [copiedId, setCopiedId] = useState(null);
    // Create GD state (for seniors)
    const [newTopic, setNewTopic] = useState('');
    const [newCategory, setNewCategory] = useState('Tech & AI Trends');
    const [newDate, setNewDate] = useState('2026-10-07');
    const [newTime, setNewTime] = useState('05:30 PM IST');
    const [maxParticipants, setMaxParticipants] = useState(8);
    const isSenior = user?.role === 'senior';
    const getGmeetId = (gdId) => {
        const clean = gdId.replace(/[^a-zA-Z0-9]/g, '').slice(-6).toLowerCase() || 'gd01';
        return `nec-gd-${clean}`;
    };
    const handleCopyGmeet = (gmeetId) => {
        navigator.clipboard.writeText(`https://meet.google.com/${gmeetId}`);
        setCopiedId(gmeetId);
        setTimeout(() => setCopiedId(null), 2000);
    };
    const handleJoin = (gdId) => {
        if (!user)
            return;
        const ok = storageService.joinMockGD(gdId, user.id, user.name);
        if (ok) {
            storageService.recordMockGDCompleted(user.id);
            setSessions(storageService.getMockGDs());
            alert('Enrolled in Group Discussion! Google Meet link is active.');
        }
        else {
            alert('This GD session is already at full capacity.');
        }
    };
    const handleCreateGD = (e) => {
        e.preventDefault();
        if (!user)
            return;
        storageService.addMockGD({
            topic: newTopic,
            category: newCategory,
            scheduledDate: newDate,
            scheduledTime: newTime,
            mentorId: user.id,
            mentorName: user.name,
            maxParticipants: Number(maxParticipants),
        });
        if (user.seniorId) {
            const current = storageService.getSeniorContributions(user.seniorId);
            storageService.updateSeniorContribution(user.seniorId, {
                gdsConducted: current.gdsConducted + 1,
            });
        }
        setSessions(storageService.getMockGDs());
        setShowCreateModal(false);
    };
    return (<div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-2xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-5 h-5 text-amber-400"/>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
              Interactive Group Discussion
            </span>
          </div>
          <h2 className="text-xl font-bold">Mock Group Discussions (GD) with Google Meet</h2>
          <p className="text-xs text-blue-200">
            Practice articulation, active listening, and constructive leadership with assigned Google Meet rooms.
          </p>
        </div>

        {isSenior && (<button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-bold rounded-xl shadow-xs transition self-start sm:self-auto cursor-pointer">
            <Plus className="w-4 h-4"/>
            <span>Host Mock GD Cohort</span>
          </button>)}
      </div>

      {/* Complete GD Process Overview */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-indigo-700"/>
            <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wide">
              Complete Mock GD Process (25 Minutes Stage-by-Stage Flow)
            </h3>
          </div>
          <span className="text-[10px] font-bold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
            Elimination Round Protocol
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 text-xs">
          {GD_PROCESS_STAGES.map((s, idx) => (<div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-[10px] font-mono font-bold text-indigo-700 block">
                {s.stageRange}
              </span>
              <p className="font-bold text-slate-800 text-[11px] leading-tight">{s.stageName.split(':')[1]}</p>
              <p className="text-[10px] text-slate-500 line-clamp-2">{s.description}</p>
            </div>))}
        </div>
      </div>

      {/* GD Sessions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sessions.map((gd) => {
            const isEnrolled = gd.participants.some((p) => p.studentId === user?.id);
            const isFull = gd.participants.length >= gd.maxParticipants;
            const gmeetId = getGmeetId(gd.id);
            return (<div key={gd.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-indigo-300 transition space-y-4 text-xs">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-900 border border-indigo-100">
                    {gd.category}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isFull ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                    {gd.participants.length} / {gd.maxParticipants} Enrolled
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-sm text-slate-900 leading-snug">{gd.topic}</h4>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Moderator: <strong>{gd.mentorName}</strong>
                  </p>
                </div>

                <div className="space-y-1 text-slate-600 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400"/>
                    <span>{gd.scheduledDate} · {gd.scheduledTime}</span>
                  </div>
                </div>

                {/* GOOGLE MEET ID BADGE */}
                <div className="p-3 rounded-xl bg-indigo-50/80 border border-indigo-200 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 truncate">
                    <Video className="w-4 h-4 text-indigo-700 shrink-0"/>
                    <div className="truncate">
                      <span className="text-[10px] uppercase font-bold text-indigo-800 block">
                        Google Meet Session ID
                      </span>
                      <code className="text-xs font-mono font-bold text-slate-900 truncate">
                        {gmeetId}
                      </code>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button onClick={() => handleCopyGmeet(gmeetId)} title="Copy GMeet Link" className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition cursor-pointer">
                      <Copy className="w-3.5 h-3.5 text-slate-600"/>
                    </button>
                    <a href={`https://meet.google.com/${gmeetId}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 px-3 py-1.5 bg-indigo-900 hover:bg-indigo-800 text-white font-bold rounded-lg transition text-[11px]">
                      <span>Join GMeet</span>
                      <ExternalLink className="w-3 h-3"/>
                    </a>
                  </div>
                </div>

                {copiedId === gmeetId && (<p className="text-[10px] text-emerald-600 font-bold">● Google Meet URL copied!</p>)}

                {/* Enrolled participants counter */}
                <div className="flex items-center gap-1.5 text-slate-500 text-[10px]">
                  <span>Participants:</span>
                  <div className="flex items-center -space-x-1 overflow-hidden">
                    {gd.participants.map((p, idx) => (<span key={idx} title={p.studentName} className="inline-block h-5 w-5 rounded-full ring-2 ring-white bg-indigo-600 text-white font-bold text-[9px] text-center leading-5">
                        {p.studentName.charAt(0)}
                      </span>))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button onClick={() => setSelectedProcessGd(gd)} className="flex items-center gap-1 text-indigo-900 font-bold hover:underline cursor-pointer">
                  <span>View What Happens in this GD</span>
                  <ChevronRight className="w-3.5 h-3.5"/>
                </button>

                {isEnrolled ? (<span className="flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    <CheckCircle className="w-3.5 h-3.5"/>
                    <span>Enrolled</span>
                  </span>) : (<button disabled={isFull} onClick={() => handleJoin(gd.id)} className="px-4 py-1.5 bg-indigo-900 hover:bg-indigo-800 disabled:opacity-40 text-white font-bold rounded-xl transition cursor-pointer">
                    {isFull ? 'Cohort Full' : 'Join Cohort'}
                  </button>)}
              </div>
            </div>);
        })}
      </div>

      {/* MODAL: VIEW WHAT HAPPENS IN THIS GD SESSION */}
      {selectedProcessGd && (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden my-4 text-xs space-y-4 max-h-[90vh] flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400"/>
                <div>
                  <h3 className="font-bold text-sm">GD Room Agenda & Flow</h3>
                  <p className="text-[10px] text-slate-400">
                    {selectedProcessGd.topic} · Moderator: {selectedProcessGd.mentorName}
                  </p>
                </div>
              </div>
              <button onClick={() => setSelectedProcessGd(null)} className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer">
                <X className="w-5 h-5"/>
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Google Meet Info Box */}
              <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] font-bold uppercase text-indigo-800">Assigned Google Meet ID</p>
                  <p className="text-sm font-mono font-black text-slate-900 mt-0.5">
                    {getGmeetId(selectedProcessGd.id)}
                  </p>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Direct video link with 6-8 participant screen view.
                  </p>
                </div>

                <a href={`https://meet.google.com/${getGmeetId(selectedProcessGd.id)}`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-900 hover:bg-indigo-800 text-white font-bold rounded-xl shadow-xs shrink-0">
                  <Video className="w-4 h-4"/>
                  <span>Launch Google Meet Room</span>
                </a>
              </div>

              {/* What Happens in this GD Session */}
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-slate-900">
                  What Happens in this GD Session (Step-by-Step Flow):
                </h4>

                <div className="space-y-3">
                  {GD_PROCESS_STAGES.map((stg, idx) => (<div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{stg.stageName}</span>
                        <span className="text-[10px] font-mono font-bold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded">
                          {stg.stageRange}
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px]">{stg.description}</p>

                      <div className="pt-2 border-t border-slate-100">
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Evaluator Checks:</p>
                        <ul className="mt-1 space-y-1 text-[11px] text-slate-700">
                          {stg.evaluationRubric.map((rubric, rIdx) => (<li key={rIdx} className="flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0"/>
                              <span>{rubric}</span>
                            </li>))}
                        </ul>
                      </div>
                    </div>))}
                </div>
              </div>

              {/* Enrolled Candidate List */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <p className="font-bold text-slate-900">Registered Candidates in this Cohort:</p>
                <div className="flex flex-wrap gap-2">
                  {selectedProcessGd.participants.map((p, idx) => (<span key={idx} className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-slate-800 font-semibold text-[11px]">
                      {p.studentName}
                    </span>))}
                </div>
              </div>
            </div>
          </div>
        </div>)}

      {/* Create GD Modal */}
      {showCreateModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border text-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Host New Mock GD Session</h3>
            <p className="text-slate-500">As a Senior, facilitate a live Google Meet group discussion.</p>

            <form onSubmit={handleCreateGD} className="space-y-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">GD Topic</label>
                <input type="text" required placeholder="e.g. Will Artificial Intelligence create or displace engineering jobs?" value={newTopic} onChange={(e) => setNewTopic(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Category</label>
                <select value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white">
                  <option value="Tech & AI Trends">Tech & AI Trends</option>
                  <option value="Current Affairs">Current Affairs & Economic Policy</option>
                  <option value="Social & Ethics">Social, Ethics & Tech Impact</option>
                  <option value="Case Study">Corporate Case Study Problem</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Date</label>
                  <input type="date" required value={newDate} onChange={(e) => setNewDate(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Time Slot</label>
                  <input type="text" required value={newTime} onChange={(e) => setNewTime(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg"/>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Max Participants (6 - 10)</label>
                <input type="number" min="4" max="12" value={maxParticipants} onChange={(e) => setMaxParticipants(Number(e.target.value))} className="w-full px-3 py-1.5 border rounded-lg"/>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowCreateModal(false)} className="px-4 py-2 border rounded-lg font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-indigo-900 text-white rounded-lg font-bold hover:bg-indigo-800">
                  Create Session & GMeet
                </button>
              </div>
            </form>
          </div>
        </div>)}
    </div>);
};
