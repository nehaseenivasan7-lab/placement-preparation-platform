import React, { useState } from 'react';
import { User as UserIcon, Check, Eye, EyeOff, ChevronDown, Key, CheckCircle2, } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import necLogo from '../assets/images/real/nec_official_logo.png';
import { GOOGLE_CLIENT_ID, DEFAULT_GOOGLE_ACCOUNTS } from '../config/googleAuth';
const SENIOR_SPECIALIZATIONS = [
    'Company Explorer',
    'Company Playbook',
    'Interview Experience',
    'Round Resources',
    'Question Bank',
    'Practice Studio',
    'Daily Challenges',
    'Coding Arena',
    'Aptitude Practice',
    'Mock Interview',
    'Mock GD',
    'Mentorship',
    'Resume Guidance',
    'Technical Interview',
    'HR Interview',
];
export const AuthModal = ({ initialMode = 'login', onSuccess, onClose }) => {
    const { login, register, loginWithGoogle } = useAuth();
    const [mode, setMode] = useState(initialMode);
    const [showPassword, setShowPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(true);
    const [errorMsg, setErrorMsg] = useState('');
    const [loading, setLoading] = useState(false);
    // Single Login input state (defaults to '24104009' and password '123' as requested)
    const [loginIdentifier, setLoginIdentifier] = useState(() => {
        if (typeof window !== 'undefined') {
            return localStorage.getItem('necpp_saved_email') || '24104009';
        }
        return '24104009';
    });
    const [loginPassword, setLoginPassword] = useState('123');
    // Automatic Role Detection based on Roll Number / Email:
    // Junior: starts with 25 (e.g. 25104009, 25104001 - 25104005)
    // Pre-Final: starts with 24 (e.g. 24105001, 24104009, 24105002 - 24105005)
    // Senior: starts with 22 (e.g. 22104001, 22104002 - 22104005, or SEN)
    // Admin: admin@nec.edu.in or admin
    const getDetectedRole = (val) => {
        const clean = (val || '').trim().toLowerCase();
        const local = clean.includes('@') ? clean.split('@')[0] : clean;
        if (local.startsWith('25'))
            return 'junior';
        if (local.startsWith('24'))
            return 'pre_final';
        if (local.startsWith('22') || local.startsWith('23') || local.startsWith('sen'))
            return 'senior';
        if (local.includes('admin') || local.startsWith('adm'))
            return 'admin';
        return 'pre_final';
    };
    const detectedRole = getDetectedRole(loginIdentifier);
    const [role, setRole] = useState(detectedRole);
    // Sync role when loginIdentifier changes in login mode
    React.useEffect(() => {
        if (mode === 'login') {
            setRole(getDetectedRole(loginIdentifier));
        }
    }, [loginIdentifier, mode]);
    // Common Registration State
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [college, setCollege] = useState('National Engineering College, Kovilpatti');
    const [degree, setDegree] = useState('B.E.');
    const [department, setDepartment] = useState('Computer Science & Engineering');
    const [graduationYear, setGraduationYear] = useState(2028);
    const [currentSemester, setCurrentSemester] = useState(3);
    const [skills, setSkills] = useState('');
    const [preferredCompanies, setPreferredCompanies] = useState('');
    const [preferredJobRoles, setPreferredJobRoles] = useState('');
    const [careerInterests, setCareerInterests] = useState('');
    const [resumeUrl, setResumeUrl] = useState('');
    const [linkedin, setLinkedin] = useState('');
    const [github, setGithub] = useState('');
    const [portfolio, setPortfolio] = useState('');
    const [bio, setBio] = useState('');
    // Senior Specific State
    const [seniorId, setSeniorId] = useState('');
    const [currentCompany, setCurrentCompany] = useState('');
    const [placementStatus, setPlacementStatus] = useState('Placed via On-Campus Drive');
    const [jobRole, setJobRole] = useState('');
    const [experience, setExperience] = useState('Fresher (2026 Batch)');
    const [specialization, setSpecialization] = useState('Company Explorer');
    const [mentoringAreas, setMentoringAreas] = useState('');
    const [companiesExperienced, setCompaniesExperienced] = useState('');
    // Admin Specific State
    const [adminId, setAdminId] = useState('');
    const [adminSecretCode, setAdminSecretCode] = useState('');
    const handleLoginSubmit = async (e) => {
        e.preventDefault();
        setErrorMsg('');
        setLoading(true);
        if (rememberMe && loginIdentifier) {
            localStorage.setItem('necpp_saved_email', loginIdentifier.trim());
        }
        const res = await login(loginIdentifier, loginPassword, role, rememberMe);
        setLoading(false);
        if (res.success) {
            if (onSuccess)
                onSuccess();
        }
        else {
            setErrorMsg(res.error || 'Login failed.');
        }
    };
    // Original Google Account Chooser (Image 2) State
    const [showGoogleOAuthModal, setShowGoogleOAuthModal] = useState(false);
    const [oauthView, setOauthView] = useState('chooser');
    const [selectedGoogleAccount, setSelectedGoogleAccount] = useState(null);
    const [googleAccounts, setGoogleAccounts] = useState(DEFAULT_GOOGLE_ACCOUNTS);
    const [googleClientId, setGoogleClientId] = useState(() => {
        if (typeof window !== 'undefined') {
            return localStorage.getItem('necpp_google_client_id') || GOOGLE_CLIENT_ID;
        }
        return GOOGLE_CLIENT_ID;
    });
    const [customEmail, setCustomEmail] = useState('anand.kumar@gmail.com');
    const [customPassword, setCustomPassword] = useState('123');
    const [showOauthPassword, setShowOauthPassword] = useState(false);
    const [oauthError, setOauthError] = useState('');
    const [clientIdInput, setClientIdInput] = useState('');
    const [clientIdSavedSuccess, setClientIdSavedSuccess] = useState(false);
    const startGoogleOAuthFlow = () => {
        setSelectedGoogleAccount(null);
        setOauthView('chooser');
        setOauthError('');
        setShowGoogleOAuthModal(true);
    };
    const handleSelectGoogleAccount = async (account) => {
        setSelectedGoogleAccount(account);
        setOauthError('');
        if (account.status === 'Signed out') {
            setCustomEmail(account.email);
            setCustomPassword('123');
            setOauthView('password');
        }
        else {
            // Immediate authentic session login
            setOauthView('loading');
            setTimeout(async () => {
                const effectiveRole = account.role || getDetectedRole(account.email);
                const res = await loginWithGoogle(effectiveRole, account.email, '123');
                if (res.success) {
                    setShowGoogleOAuthModal(false);
                    if (onSuccess)
                        onSuccess();
                }
                else {
                    setOauthError('Google sign in failed. Please try again.');
                    setOauthView('chooser');
                }
            }, 600);
        }
    };
    const handleGooglePasswordSubmit = async (e) => {
        e.preventDefault();
        if (!customPassword) {
            setOauthError('Enter a password');
            return;
        }
        setOauthView('loading');
        setTimeout(async () => {
            const email = selectedGoogleAccount ? selectedGoogleAccount.email : customEmail;
            const effectiveRole = getDetectedRole(email);
            const res = await loginWithGoogle(effectiveRole, email, customPassword);
            if (res.success) {
                setShowGoogleOAuthModal(false);
                if (onSuccess)
                    onSuccess();
            }
            else {
                setOauthError('Sign-in failed. Please verify your credentials.');
                setOauthView('password');
            }
        }, 600);
    };
    const handleCustomEmailSubmit = (e) => {
        e.preventDefault();
        if (!customEmail.trim() || !customEmail.includes('@')) {
            setOauthError('Enter a valid email address');
            return;
        }
        setOauthError('');
        setCustomPassword('123');
        setOauthView('password');
    };
    const handleSaveClientId = (e) => {
        e.preventDefault();
        if (clientIdInput.trim()) {
            const trimmed = clientIdInput.trim();
            setGoogleClientId(trimmed);
            if (typeof window !== 'undefined') {
                localStorage.setItem('necpp_google_client_id', trimmed);
            }
            setClientIdSavedSuccess(true);
            setTimeout(() => {
                setClientIdSavedSuccess(false);
                setOauthView('chooser');
            }, 1000);
        }
    };
    const handleGoogleLogin = () => {
        startGoogleOAuthFlow();
    };
    const handleRegisterSubmit = async (e) => {
        e.preventDefault();
        setErrorMsg('');
        if (password !== confirmPassword) {
            setErrorMsg('Passwords do not match.');
            return;
        }
        if (password.length < 6) {
            setErrorMsg('Password must be at least 6 characters long.');
            return;
        }
        if (role === 'admin' && adminSecretCode !== 'NECADMIN2026') {
            setErrorMsg('Invalid Admin Invitation Code. Please contact College Administration.');
            return;
        }
        setLoading(true);
        const baseData = {
            name: fullName,
            email,
            phone,
            role,
            college,
            degree,
            department,
            graduationYear: Number(graduationYear),
            currentSemester: Number(currentSemester),
            skills: skills ? skills.split(',').map((s) => s.trim()).filter(Boolean) : [],
            preferredCompanies: preferredCompanies
                ? preferredCompanies.split(',').map((s) => s.trim()).filter(Boolean)
                : [],
            preferredJobRoles: preferredJobRoles
                ? preferredJobRoles.split(',').map((s) => s.trim()).filter(Boolean)
                : [],
            careerInterests: careerInterests
                ? careerInterests.split(',').map((s) => s.trim()).filter(Boolean)
                : [],
            resumeUrl,
            linkedin,
            github,
            portfolio,
            bio,
        };
        let fullPayload = { ...baseData };
        if (role === 'senior') {
            fullPayload = {
                ...fullPayload,
                seniorId: seniorId || `SEN${Math.floor(100 + Math.random() * 900)}`,
                currentCompany,
                placementStatus,
                jobRole,
                experience,
                specialization,
                mentoringAreas: mentoringAreas ? mentoringAreas.split(',').map((s) => s.trim()) : [],
                companiesExperienced: companiesExperienced ? companiesExperienced.split(',').map((s) => s.trim()) : [],
                badges: ['Active Mentor'],
            };
        }
        else if (role === 'admin') {
            fullPayload = {
                ...fullPayload,
                adminId: adminId || `ADM${Math.floor(100 + Math.random() * 900)}`,
            };
        }
        const res = await register(fullPayload, password);
        setLoading(false);
        if (res.success) {
            if (onSuccess)
                onSuccess();
        }
        else {
            setErrorMsg(res.error || 'Registration failed.');
        }
    };
    return (<div className={onClose
            ? 'fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200'
            : 'min-h-screen flex items-center justify-center p-4 bg-college-pattern'}>
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 animate-in fade-in duration-200">
        {/* Top Close bar */}
        <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 bg-blue-100/70 px-2 py-0.5 rounded">
              NEC Campus Portal
            </span>
          </div>
          {onClose && (<button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition cursor-pointer text-xs" title="Close">
              ✕
            </button>)}
        </div>

        {/* Card Body */}
        <div className="p-6 sm:p-8">
          {/* NEC Emblem matching Image #2 */}
          <div className="text-center mb-6">
            <img src={necLogo} alt="National Engineering College, Kovilpatti" className="w-24 h-24 sm:w-28 sm:h-28 object-contain mx-auto mb-2 drop-shadow-xs"/>
          </div>

          {errorMsg && (<div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {errorMsg}
            </div>)}

          {/* ===================== LOGIN FORM (Matches Image #2) ===================== */}
          {mode === 'login' ? (<form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Username Input Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Username
                </label>
                <input type="text" required placeholder="e.g. 24104009, 25104001, SEN001, admin@nec.edu.in" value={loginIdentifier} onChange={(e) => {
                setLoginIdentifier(e.target.value);
                const clean = e.target.value.trim().toLowerCase();
                if (clean === 'admin@nec.edu.in' || clean.includes('admin'))
                    setRole('admin');
                else if (clean.startsWith('sen'))
                    setRole('senior');
                else if (clean.startsWith('251'))
                    setRole('junior');
                else if (clean.startsWith('241'))
                    setRole('pre_final');
            }} className="w-full px-4 py-2.5 bg-[#eef3fb] border border-[#d6e3f8] focus:border-blue-500 focus:bg-white text-slate-800 font-medium rounded-lg text-sm outline-none transition"/>
              </div>

              {/* Password Input Field */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700">
                    Password
                  </label>
                  <span className="text-[10px] text-slate-400">
                    Saved for next time
                  </span>
                </div>
                <div className="relative">
                  <input type={showPassword ? 'text' : 'password'} required placeholder="Password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} className="w-full px-4 py-2.5 bg-[#eef3fb] border border-[#d6e3f8] focus:border-blue-500 focus:bg-white text-slate-800 font-medium rounded-lg text-sm outline-none transition"/>
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer">
                    {showPassword ? <EyeOff className="w-4 h-4"/> : <Eye className="w-4 h-4"/>}
                  </button>
                </div>
              </div>

              {/* Senior Personalization Card (Visible only when Senior is entered) */}
              {role === 'senior' && (<div className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl flex items-center gap-3 animate-in fade-in duration-200">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center font-bold text-amber-900 shrink-0 text-sm">
                    {loginIdentifier.toUpperCase().startsWith('SEN001') ? 'PM' : loginIdentifier.toUpperCase().startsWith('SEN002') ? 'KS' : loginIdentifier.toUpperCase().startsWith('SEN003') ? 'KR' : 'SM'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-800 truncate">
                        {loginIdentifier.toUpperCase().startsWith('SEN001')
                    ? 'Priya Muthuraman'
                    : loginIdentifier.toUpperCase().startsWith('SEN002')
                        ? 'Karthik Subramanian'
                        : loginIdentifier.toUpperCase().startsWith('SEN003')
                            ? 'Karthik Raja S'
                            : loginIdentifier.toUpperCase().startsWith('SEN004')
                                ? 'Deepa Rajan'
                                : 'Senior Placement Mentor'}
                      </span>
                      <span className="text-[10px] bg-amber-200/80 text-amber-900 px-1.5 py-0.5 rounded font-bold">
                        Mentor
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 truncate">
                      {loginIdentifier.toUpperCase().startsWith('SEN001')
                    ? 'Placed at Zoho Corporation (8.5 LPA) • Company Explorer Lead'
                    : loginIdentifier.toUpperCase().startsWith('SEN002')
                        ? 'Placed at TCS Digital (7.5 LPA) • Playbook Lead'
                        : loginIdentifier.toUpperCase().startsWith('SEN003')
                            ? 'Placed at TCS Digital (7.2 LPA) • Interview Mentor'
                            : loginIdentifier.toUpperCase().startsWith('SEN004')
                                ? 'Placed at Infosys (9.5 LPA) • Question Bank Lead'
                                : 'NEC Placed Mentor • Ready to guide juniors'}
                    </p>
                  </div>
                </div>)}

              {/* Log in Button and Lost Password Link */}
              <div className="pt-1 flex flex-col items-start gap-2">
                <button type="submit" disabled={loading} className="w-full sm:w-auto px-7 py-2.5 bg-[#1b66f1] hover:bg-[#1556d1] disabled:opacity-50 text-white font-semibold rounded-lg text-sm shadow-xs transition cursor-pointer">
                  {loading ? 'Logging in...' : 'Log in'}
                </button>

                <a href="#forgot-password" onClick={(e) => {
                e.preventDefault();
                setLoginPassword('123');
                setErrorMsg('Password auto-filled as 123.');
            }} className="text-blue-600 hover:underline text-xs font-normal">
                  Lost password?
                </a>
              </div>

              {/* Real-Time Google Authentication Matching Reference Image */}
              <div className="border-t border-slate-200 pt-4 mt-2">
                <p className="text-[#1b4396] font-semibold text-xs mb-2.5">
                  Log in using your account on:
                </p>

                <button type="button" onClick={handleGoogleLogin} className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-700 font-semibold rounded-lg border border-slate-300 shadow-2xs transition cursor-pointer flex items-center justify-center gap-2 text-xs">
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>Google</span>
                </button>
              </div>

              {/* Switch to Register link */}
              <div className="text-center pt-2">
                <button type="button" onClick={() => {
                setMode('register');
                setErrorMsg('');
            }} className="text-[11px] text-slate-500 hover:text-blue-700 font-medium cursor-pointer">
                  New student? <span className="font-bold underline text-blue-600">Register campus account</span>
                </button>
              </div>
            </form>) : (
        /* ===================== REGISTRATION FORM ===================== */
        <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs max-h-[60vh] overflow-y-auto pr-1">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="font-bold text-slate-800 text-sm">New Student Registration</span>
                <button type="button" onClick={() => setMode('login')} className="text-blue-600 hover:underline text-xs font-semibold">
                  Back to Sign In
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Full Name *</label>
                  <input type="text" required placeholder="e.g. Anandha Selvan" value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Email Address *</label>
                  <input type="email" required placeholder="e.g. anand@nec.edu.in" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Phone Number *</label>
                  <input type="tel" required placeholder="+91 98401 XXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">College *</label>
                  <input type="text" required value={college} onChange={(e) => setCollege(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Degree *</label>
                  <select value={degree} onChange={(e) => setDegree(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50">
                    <option value="B.E.">B.E.</option>
                    <option value="B.Tech">B.Tech</option>
                    <option value="M.E.">M.E.</option>
                    <option value="MCA">MCA</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Department / Branch *</label>
                  <select value={department} onChange={(e) => setDepartment(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50">
                    <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                    <option value="Information Technology">Information Technology</option>
                    <option value="Electronics & Communication Engineering">Electronics & Communication Engineering</option>
                    <option value="Electrical & Electronics Engineering">Electrical & Electronics Engineering</option>
                    <option value="Mechanical Engineering">Mechanical Engineering</option>
                    <option value="Civil Engineering">Civil Engineering</option>
                    <option value="Artificial Intelligence & Data Science">Artificial Intelligence & Data Science</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Graduation Year *</label>
                  <input type="number" required value={graduationYear} onChange={(e) => setGraduationYear(Number(e.target.value))} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Current Semester</label>
                  <input type="number" value={currentSemester} onChange={(e) => setCurrentSemester(Number(e.target.value))} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>

                {/* Senior-Specific Fields */}
                {role === 'senior' && (<>
                    <div className="sm:col-span-2 p-3 bg-amber-50/60 rounded-xl border border-amber-200">
                      <p className="font-bold text-amber-900 text-xs mb-2">Senior Mentor Specialization Setup</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Senior ID *</label>
                          <input type="text" required placeholder="e.g. SEN010" value={seniorId} onChange={(e) => setSeniorId(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none"/>
                        </div>
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Primary Specialization *</label>
                          <select value={specialization} onChange={(e) => setSpecialization(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none font-semibold text-blue-900">
                            {SENIOR_SPECIALIZATIONS.map((s) => (<option key={s} value={s}>
                                {s}
                              </option>))}
                          </select>
                        </div>
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Placed / Current Company *</label>
                          <input type="text" required placeholder="e.g. Zoho / TCS / Amazon" value={currentCompany} onChange={(e) => setCurrentCompany(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none"/>
                        </div>
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Job Role *</label>
                          <input type="text" required placeholder="e.g. Software Development Engineer" value={jobRole} onChange={(e) => setJobRole(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none"/>
                        </div>
                      </div>
                    </div>
                  </>)}

                {/* Admin-Specific Fields */}
                {role === 'admin' && (<>
                    <div className="sm:col-span-2 p-3 bg-purple-50/60 rounded-xl border border-purple-200">
                      <p className="font-bold text-purple-900 text-xs mb-2">Admin Security Verification</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Admin ID *</label>
                          <input type="text" required placeholder="e.g. ADM002" value={adminId} onChange={(e) => setAdminId(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none"/>
                        </div>
                        <div>
                          <label className="font-semibold text-slate-700 block mb-1">Admin Invitation Secret *</label>
                          <input type="password" required placeholder="Enter College Admin Code" value={adminSecretCode} onChange={(e) => setAdminSecretCode(e.target.value)} className="w-full px-3 py-1.5 border rounded-lg bg-white outline-none"/>
                        </div>
                      </div>
                      <p className="text-[10px] text-purple-700 mt-1 font-mono">
                        Note: College Admin Secret Code is: NECADMIN2026
                      </p>
                    </div>
                  </>)}

                {/* Student specific fields */}
                {(role === 'junior' || role === 'pre_final') && (<>
                    <div className="sm:col-span-2">
                      <label className="font-bold text-slate-700 block mb-1">Preferred Companies (comma-separated)</label>
                      <input type="text" placeholder="e.g. Zoho, TCS, Kaar Tech, Bosch, Amazon" value={preferredCompanies} onChange={(e) => setPreferredCompanies(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="font-bold text-slate-700 block mb-1">Key Technical Skills</label>
                      <input type="text" placeholder="e.g. Java, C++, Python, Data Structures, SQL" value={skills} onChange={(e) => setSkills(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                    </div>
                  </>)}

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Create Password *</label>
                  <input type="password" required placeholder="Min 6 characters" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Confirm Password *</label>
                  <input type="password" required placeholder="Re-enter password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full px-3 py-2 border rounded-xl outline-none focus:border-blue-600 bg-slate-50 focus:bg-white"/>
                </div>
              </div>

              <button type="submit" disabled={loading} className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2 mt-4">
                <span>{loading ? 'Creating Account...' : 'Complete Official Registration'}</span>
                <Check className="w-4 h-4"/>
              </button>
            </form>)}
        </div>
      </div>

      {/* ===================== ORIGINAL GOOGLE OAUTH MODAL (MATCHING IMAGE 2) ===================== */}
      {showGoogleOAuthModal && (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-[440px] bg-[#131314] text-[#e3e3e3] rounded-3xl shadow-2xl border border-[#2f3033] overflow-hidden p-6 sm:p-8 font-sans">
            
            {/* Top Bar: Google G Logo + Title */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span className="text-sm font-medium text-[#e3e3e3]">Sign in with Google</span>
              </div>

              <button type="button" onClick={() => setShowGoogleOAuthModal(false)} className="text-[#9aa0a6] hover:text-white transition p-1 text-sm cursor-pointer" title="Close">
                ✕
              </button>
            </div>

            {oauthError && (<div className="mt-4 p-2.5 rounded-lg bg-rose-950/70 border border-rose-800 text-rose-300 text-xs">
                {oauthError}
              </div>)}

            {/* VIEW 1: CHOOSE AN ACCOUNT (EXACT MATCH OF IMAGE 2) */}
            {oauthView === 'chooser' && (<div className="mt-6">
                <h2 className="text-2xl font-normal text-white">Choose an account</h2>
                <p className="text-sm text-[#8ab4f8] mt-1 hover:underline cursor-pointer">
                  to continue to EL Project
                </p>

                {/* Account Chooser List */}
                <div className="mt-6 divide-y divide-[#2f3033] border-t border-b border-[#2f3033]">
                  {googleAccounts.map((acc, index) => (<div key={index} onClick={() => handleSelectGoogleAccount(acc)} className="py-3.5 px-2 flex items-center justify-between hover:bg-[#202124] rounded-xl cursor-pointer transition">
                      <div className="flex items-center gap-3.5 min-w-0">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-white font-semibold text-xs shrink-0 shadow-xs" style={{ backgroundColor: acc.avatarColor }}>
                          {acc.avatarLetter}
                        </div>
                        <div className="truncate">
                          <p className="text-sm font-medium text-white truncate leading-snug">
                            {acc.name}
                          </p>
                          <p className="text-xs text-[#9aa0a6] truncate leading-tight mt-0.5">
                            {acc.email}
                          </p>
                        </div>
                      </div>

                      {acc.status && (<span className="text-xs text-[#9aa0a6] shrink-0 ml-2">
                          {acc.status}
                        </span>)}
                    </div>))}

                  {/* Use another account row */}
                  <div onClick={() => {
                    setOauthError('');
                    setCustomEmail('');
                    setOauthView('custom_email');
                }} className="py-3.5 px-2 flex items-center gap-3.5 hover:bg-[#202124] rounded-xl cursor-pointer transition text-[#e3e3e3]">
                    <div className="w-8 h-8 rounded-full border border-[#5f6368] flex items-center justify-center text-[#e3e3e3] shrink-0">
                      <UserIcon className="w-4 h-4 text-[#bdc1c6]"/>
                    </div>
                    <span className="text-sm font-medium">Use another account</span>
                  </div>
                </div>

                {/* Footer (English, Help, Privacy, Terms) */}
                <div className="mt-6 flex items-center justify-between text-xs text-[#9aa0a6]">
                  <div className="flex items-center gap-1 cursor-pointer hover:text-white">
                    <span>English (United States)</span>
                    <ChevronDown className="w-3.5 h-3.5"/>
                  </div>
                  <div className="flex items-center gap-4">
                    <a href="#help" className="hover:underline">Help</a>
                    <a href="#privacy" className="hover:underline">Privacy</a>
                    <a href="#terms" className="hover:underline">Terms</a>
                  </div>
                </div>

                {/* Editable Google Client ID Bar */}
                <div className="mt-6 pt-3 border-t border-[#2f3033] flex items-center justify-between text-[11px] text-[#9aa0a6]">
                  <div className="flex items-center gap-1.5 truncate mr-2">
                    <Key className="w-3.5 h-3.5 text-amber-400 shrink-0"/>
                    <span className="font-mono text-[10px] truncate max-w-[200px]">
                      {googleClientId.startsWith('YOUR_') ? 'Client ID: Not set' : googleClientId}
                    </span>
                  </div>
                  <button type="button" onClick={() => {
                    setClientIdInput(googleClientId.startsWith('YOUR_') ? '' : googleClientId);
                    setOauthView('client_id');
                }} className="px-2.5 py-1 rounded bg-[#202124] hover:bg-[#303134] text-[#8ab4f8] text-[11px] font-medium border border-[#3c4043] transition cursor-pointer shrink-0">
                    Edit Client ID
                  </button>
                </div>
              </div>)}

            {/* VIEW 2: PASSWORD ENTRY FOR SIGNED OUT ACCOUNT */}
            {oauthView === 'password' && (<form onSubmit={handleGooglePasswordSubmit} className="mt-6 space-y-5">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#202124] border border-[#3c4043] text-xs text-[#e3e3e3] mb-4">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span className="font-medium truncate max-w-[240px]">
                      {selectedGoogleAccount ? selectedGoogleAccount.email : customEmail}
                    </span>
                  </div>
                  <h2 className="text-2xl font-normal text-white">Welcome</h2>
                  <p className="text-xs text-[#9aa0a6] mt-1">To continue, first verify it’s you</p>
                </div>

                <div>
                  <input type={showOauthPassword ? 'text' : 'password'} required placeholder="Enter your password" value={customPassword} onChange={(e) => setCustomPassword(e.target.value)} className="w-full px-4 py-3 bg-[#1e1f20] border border-[#5f6368] focus:border-[#8ab4f8] focus:ring-1 focus:ring-[#8ab4f8] text-white rounded-md text-sm outline-none transition"/>
                  <div className="mt-2.5 flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 text-[#bdc1c6] cursor-pointer select-none">
                      <input type="checkbox" checked={showOauthPassword} onChange={(e) => setShowOauthPassword(e.target.checked)} className="rounded border-[#5f6368] bg-[#1e1f20] text-[#8ab4f8]"/>
                      <span>Show password</span>
                    </label>
                    <a href="#forgot" onClick={(e) => {
                    e.preventDefault();
                    setCustomPassword('123');
                }} className="text-[#8ab4f8] hover:underline">
                      Forgot password?
                    </a>
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button type="button" onClick={() => setOauthView('chooser')} className="text-xs font-medium text-[#8ab4f8] hover:underline cursor-pointer">
                    Back
                  </button>
                  <button type="submit" className="px-6 py-2 bg-[#8ab4f8] hover:bg-[#a8c7fa] text-[#001d35] font-medium rounded-full text-xs transition cursor-pointer">
                    Next
                  </button>
                </div>
              </form>)}

            {/* VIEW 3: USE ANOTHER ACCOUNT (CUSTOM EMAIL) */}
            {oauthView === 'custom_email' && (<form onSubmit={handleCustomEmailSubmit} className="mt-6 space-y-5">
                <div>
                  <h2 className="text-2xl font-normal text-white">Sign in with Google</h2>
                  <p className="text-sm text-[#8ab4f8] mt-1 hover:underline cursor-pointer">
                    to continue to EL Project
                  </p>
                </div>

                <div>
                  <input type="email" required placeholder="Email or phone" value={customEmail} onChange={(e) => setCustomEmail(e.target.value)} className="w-full px-4 py-3 bg-[#1e1f20] border border-[#5f6368] focus:border-[#8ab4f8] focus:ring-1 focus:ring-[#8ab4f8] text-white rounded-md text-sm outline-none transition"/>
                  <p className="text-xs text-[#9aa0a6] mt-2">
                    Enter any Google or institutional account (e.g. name@gmail.com or roll@nec.edu.in)
                  </p>
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button type="button" onClick={() => setOauthView('chooser')} className="text-xs font-medium text-[#8ab4f8] hover:underline cursor-pointer">
                    Back
                  </button>
                  <button type="submit" className="px-6 py-2 bg-[#8ab4f8] hover:bg-[#a8c7fa] text-[#001d35] font-medium rounded-full text-xs transition cursor-pointer">
                    Next
                  </button>
                </div>
              </form>)}

            {/* VIEW 4: EDIT GOOGLE CLIENT ID */}
            {oauthView === 'client_id' && (<form onSubmit={handleSaveClientId} className="mt-6 space-y-4">
                <div>
                  <h2 className="text-xl font-normal text-white">Configure Google Client ID</h2>
                  <p className="text-xs text-[#9aa0a6] mt-1">
                    Enter your Google Cloud OAuth 2.0 Web Client ID:
                  </p>
                </div>

                {clientIdSavedSuccess && (<div className="p-2.5 rounded-lg bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400"/>
                    <span>Client ID successfully saved!</span>
                  </div>)}

                <div>
                  <textarea rows={3} placeholder="e.g. 123456789-abcdefg.apps.googleusercontent.com" value={clientIdInput} onChange={(e) => setClientIdInput(e.target.value)} className="w-full px-3.5 py-2.5 bg-[#1e1f20] border border-[#5f6368] focus:border-[#8ab4f8] text-white font-mono text-xs rounded-md outline-none transition"/>
                  <p className="text-[11px] text-[#9aa0a6] mt-1">
                    Saved in local configuration and synchronized with your project setup.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button type="button" onClick={() => setOauthView('chooser')} className="text-xs font-medium text-[#8ab4f8] hover:underline cursor-pointer">
                    Cancel
                  </button>
                  <button type="submit" className="px-5 py-2 bg-[#8ab4f8] hover:bg-[#a8c7fa] text-[#001d35] font-medium rounded-full text-xs transition cursor-pointer">
                    Save Client ID
                  </button>
                </div>
              </form>)}

            {/* VIEW 5: AUTHENTICATING SPINNER */}
            {oauthView === 'loading' && (<div className="py-16 text-center space-y-4">
                <div className="w-10 h-10 border-3 border-[#8ab4f8] border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-sm text-white font-medium">Signing in with Google...</p>
                <p className="text-xs text-[#9aa0a6]">Connecting to EL Project & issuing JWT session</p>
              </div>)}
          </div>
        </div>)}
    </div>);
};
