import React, { useState } from 'react';
import { X, HelpCircle, ChevronDown, ChevronUp, Phone, Mail, Building } from 'lucide-react';
export const HelpCenterModal = ({ isOpen, onClose }) => {
    const [openFaq, setOpenFaq] = useState(0);
    if (!isOpen)
        return null;
    const faqs = [
        {
            q: 'How does the Specialized Senior Mentor Ecosystem work?',
            a: 'Unlike generic platforms where seniors review everything, each Senior Mentor at NEC is designated for a specific placement domain based on their placed company (e.g. Priya SEN001 handles Company Explorer for Zoho, Sanjay SEN007 conducts Amazon SDE Mock Interviews, Deepa SEN004 manages the Question Bank). You receive tailored guidance from seniors who cleared that exact drive.',
        },
        {
            q: 'Why did my Readiness Score start at 0%?',
            a: 'The platform strictly enforces zero fake progress! Your Readiness Score is an authentic measure calculated dynamically as you practice aptitude questions, submit code solutions, attend mock interviews, and maintain daily challenge streaks. Every point reflects verified student effort.',
        },
        {
            q: 'How do I schedule a 1-on-1 Mock Interview with a senior?',
            a: 'Go to Workspace → Mock Interviews or Mentorship, pick your target company or domain, select an available date/time slot with our placed seniors, and submit your request. You will receive an instant Google Meet link and in-app reminder.',
        },
        {
            q: 'Can 2nd Year (Junior) students access all 18 modules?',
            a: 'Yes! While the Junior dashboard prioritizes fundamentals (C programming, aptitude basics, study planner, company explorer), all 18 modules remain fully unlocked so motivated 2nd years can explore advanced challenges anytime.',
        },
        {
            q: 'Where do I report discrepancies in company package details?',
            a: 'You can submit a ticket to the Training & Placement Cell directly via the contact details below, or send a direct doubt to our Senior Company Explorer mentors.',
        },
    ];
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 bg-linear-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-5 h-5 text-amber-400"/>
            <div>
              <h3 className="font-bold text-base">NEC Placement Help & Support Center</h3>
              <p className="text-xs text-blue-200">Guidance for students, senior mentors, and placement coordinators</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer">
            <X className="w-5 h-5"/>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs">
          {/* Official Contact Box */}
          <div className="p-4 bg-blue-50/70 rounded-xl border border-blue-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex items-center gap-2 text-slate-800">
              <Building className="w-4 h-4 text-blue-800 shrink-0"/>
              <div>
                <p className="font-bold text-[11px] text-slate-900">Training & Placement Cell</p>
                <p className="text-[10px] text-slate-600">Admin Block, 1st Floor</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-slate-800">
              <Mail className="w-4 h-4 text-blue-800 shrink-0"/>
              <div>
                <p className="font-bold text-[11px] text-slate-900">Official Placement Email</p>
                <p className="text-[10px] text-slate-600">placement@nec.edu.in</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-slate-800">
              <Phone className="w-4 h-4 text-blue-800 shrink-0"/>
              <div>
                <p className="font-bold text-[11px] text-slate-900">Helpline</p>
                <p className="text-[10px] text-slate-600">+91 (04632) 222502</p>
              </div>
            </div>
          </div>

          {/* FAQs */}
          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-3">Frequently Asked Questions</h4>
            <div className="space-y-2">
              {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (<div key={index} className="border border-slate-200 rounded-xl overflow-hidden transition">
                    <button onClick={() => setOpenFaq(isOpen ? null : index)} className="w-full p-3.5 flex items-center justify-between text-left font-bold text-slate-800 hover:bg-slate-50 transition cursor-pointer">
                      <span>{faq.q}</span>
                      {isOpen ? (<ChevronUp className="w-4 h-4 text-blue-600 shrink-0 ml-2"/>) : (<ChevronDown className="w-4 h-4 text-slate-400 shrink-0 ml-2"/>)}
                    </button>
                    {isOpen && (<div className="px-3.5 pb-3.5 pt-1 text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                        {faq.a}
                      </div>)}
                  </div>);
        })}
            </div>
          </div>
        </div>
      </div>
    </div>);
};
