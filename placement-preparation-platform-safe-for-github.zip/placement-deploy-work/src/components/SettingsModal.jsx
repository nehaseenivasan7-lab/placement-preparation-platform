import React, { useState, useEffect } from 'react';
import { X, Palette, Bell, UserCheck, Eye, Sliders, Check, Type, Globe, Sun, Moon, Sparkles, CheckCircle2, Cloud, ExternalLink, } from 'lucide-react';
import { useTheme, PRESET_THEME_COLORS, SPECIAL_HEX_PALETTE, } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { storageService } from '../services/storage';
export const SettingsModal = ({ isOpen, onClose, onOpenProfile, initialTab = 'appearance', }) => {
    const { settings, updateSettings, mode, toggleMode, themeColor, setThemeColor, language, t, } = useTheme();
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState(initialTab);
    // Notifications state
    const [notifications, setNotifications] = useState([]);
    const [notifFilter, setNotifFilter] = useState('all');
    // Password change state
    const [passwordState, setPasswordState] = useState({ old: '', new: '', confirm: '' });
    const [passwordMsg, setPasswordMsg] = useState(null);
    useEffect(() => {
        if (user && isOpen) {
            setNotifications(storageService.getNotifications(user.id));
        }
    }, [user, isOpen]);
    useEffect(() => {
        if (initialTab) {
            setActiveTab(initialTab);
        }
    }, [initialTab]);
    if (!isOpen)
        return null;
    const handleMarkAllRead = () => {
        if (!user)
            return;
        storageService.markAllNotificationsAsRead(user.id);
        setNotifications(storageService.getNotifications(user.id));
    };
    const handlePasswordChange = (e) => {
        e.preventDefault();
        if (passwordState.new !== passwordState.confirm) {
            setPasswordMsg({ text: 'New passwords do not match!', success: false });
            return;
        }
        if (passwordState.new.length < 6) {
            setPasswordMsg({ text: 'Password must be at least 6 characters long.', success: false });
            return;
        }
        setPasswordMsg({ text: 'Password updated successfully!', success: true });
        setPasswordState({ old: '', new: '', confirm: '' });
    };
    const filteredNotifications = notifications.filter((n) => (notifFilter === 'unread' ? !n.isRead : true));
    const unreadCount = notifications.filter((n) => !n.isRead).length;
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 flex flex-col md:flex-row min-h-[580px] max-h-[90vh]">
        {/* Settings Navigation Sidebar */}
        <div className="w-full md:w-60 bg-slate-50 dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-4 shrink-0 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-5 px-2">
              <Sliders className="w-5 h-5 text-blue-800 dark:text-blue-400"/>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">{t('settings')}</h3>
                <p className="text-[10px] text-slate-500">Preferences & Controls</p>
              </div>
            </div>

            <nav className="space-y-1">
              <button onClick={() => setActiveTab('appearance')} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'appearance' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <Palette className="w-4 h-4"/>
                <span>{t('appearance')}</span>
              </button>

              <button onClick={() => setActiveTab('language')} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'language' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <div className="flex items-center gap-2.5">
                  <Globe className="w-4 h-4"/>
                  <span>{t('language')}</span>
                </div>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10">
                  {language}
                </span>
              </button>

              <button onClick={() => setActiveTab('notifications')} className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'notifications' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <div className="flex items-center gap-2.5">
                  <Bell className="w-4 h-4"/>
                  <span>{t('notifications')}</span>
                </div>
                {unreadCount > 0 && (<span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${activeTab === 'notifications' ? 'bg-white text-rose-600' : 'bg-rose-500 text-white'}`}>
                    {unreadCount}
                  </span>)}
              </button>

              <button onClick={() => setActiveTab('account')} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'account' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <UserCheck className="w-4 h-4"/>
                <span>{t('accountTab', 'Account')}</span>
              </button>

              <button onClick={() => setActiveTab('accessibility')} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'accessibility' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <Type className="w-4 h-4"/>
                <span>{t('accessibility', 'Accessibility')}</span>
              </button>

              <button onClick={() => setActiveTab('privacy')} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'privacy' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <Eye className="w-4 h-4"/>
                <span>{t('privacy', 'Privacy')}</span>
              </button>

              <button onClick={() => setActiveTab('deployment')} className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition cursor-pointer ${activeTab === 'deployment' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}>
                <Cloud className="w-4 h-4 text-emerald-500"/>
                <span className="font-bold">Render & Atlas Deployment</span>
              </button>
            </nav>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 px-2">
            <p className="text-[11px] text-slate-500 font-medium">NEC Campus User:</p>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">{user?.name}</p>
            <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
          </div>
        </div>

        {/* Tab Content Panel */}
        <div className="flex-1 p-6 overflow-y-auto max-h-[85vh] bg-white dark:bg-slate-900">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white capitalize">
                {activeTab === 'appearance'
            ? t('appearance')
            : activeTab === 'language'
                ? t('language')
                : activeTab === 'notifications'
                    ? t('notifications')
                    : activeTab === 'account'
                        ? t('accountTab', 'Account')
                        : activeTab === 'accessibility'
                            ? t('accessibility', 'Accessibility')
                            : activeTab === 'deployment'
                                ? 'Render Cloud Deployment & MongoDB Atlas'
                                : t('privacy', 'Privacy')}
              </h2>
              <p className="text-xs text-slate-500">National Engineering College • System Preferences</p>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
              <X className="w-5 h-5"/>
            </button>
          </div>

          {/* ================= APPEARANCE TAB (LIGHT/DARK + THEME COLORS + USER PALETTE) ================= */}
          {activeTab === 'appearance' && (<div className="space-y-6 text-xs">
              {/* 1. Mode Switcher (Light vs Dark) */}
              <div>
                <label className="font-bold text-slate-900 dark:text-white block mb-2">
                  {t('mode', 'Display Mode')}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => updateSettings({ mode: 'light' })} className={`p-4 rounded-xl border text-left transition cursor-pointer flex items-center gap-3 ${mode === 'light'
                ? 'border-blue-600 bg-blue-50/60 dark:bg-slate-800 ring-2 ring-blue-500/30'
                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                    <div className="p-2.5 rounded-lg bg-amber-100 text-amber-800">
                      <Sun className="w-5 h-5"/>
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white text-sm">{t('light', 'Light Mode')}</p>
                      <p className="text-[11px] text-slate-500">Standard crisp high-contrast daylight</p>
                    </div>
                  </button>

                  <button type="button" onClick={() => updateSettings({ mode: 'dark' })} className={`p-4 rounded-xl border text-left transition cursor-pointer flex items-center gap-3 ${mode === 'dark'
                ? 'border-blue-500 bg-slate-800 ring-2 ring-blue-500/30 text-white'
                : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                    <div className="p-2.5 rounded-lg bg-indigo-900 text-indigo-200">
                      <Moon className="w-5 h-5"/>
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white text-sm">{t('dark', 'Dark Mode')}</p>
                      <p className="text-[11px] text-slate-500">Gentle midnight dark theme</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* 2. Standard Theme Color Presets (Blue, Green, Orange, Red, Gray, Purple, Maroon, Pink) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-bold text-slate-900 dark:text-white">
                    {t('themeColor', 'Standard Theme Colors')}
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Active: <strong style={{ color: themeColor }}>{themeColor}</strong>
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {PRESET_THEME_COLORS.map((preset) => {
                const isSelected = themeColor === preset.hex || settings.theme === preset.id;
                return (<button key={preset.id} type="button" onClick={() => setThemeColor(preset.hex)} className={`p-3 rounded-xl border text-left transition cursor-pointer flex items-center gap-2.5 ${isSelected
                        ? 'border-slate-900 dark:border-white ring-2 ring-blue-500/40 bg-slate-50 dark:bg-slate-800'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                        <div className="w-5 h-5 rounded-full shrink-0 shadow-xs flex items-center justify-center text-white" style={{ backgroundColor: preset.hex }}>
                          {isSelected && <Check className="w-3 h-3"/>}
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-slate-800 dark:text-slate-200 text-xs truncate">{preset.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono truncate">{preset.hex}</p>
                        </div>
                      </button>);
            })}
                </div>
              </div>

              {/* 3. Special Custom Requested Color Palette (#B08401, #D49E8D, #683B2B, #4A6163, #F17A7E, #E43D12, #00CEC8, #A1CCA6, #097C87, #FFCFD2) */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-amber-500"/>
                  <label className="font-bold text-slate-900 dark:text-white">
                    Custom Extended Palette (Requested Hex Codes)
                  </label>
                </div>
                <p className="text-[11px] text-slate-500 mb-2.5">
                  Click any swatch to apply this exact hex tone throughout the entire website:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {SPECIAL_HEX_PALETTE.map((item) => {
                const isSelected = themeColor.toLowerCase() === item.hex.toLowerCase();
                return (<button key={item.id} type="button" onClick={() => setThemeColor(item.hex)} className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex items-center gap-2 ${isSelected
                        ? 'border-slate-900 dark:border-white ring-2 ring-blue-500/40 bg-slate-100 dark:bg-slate-800'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                        <div className="w-5 h-5 rounded-full shrink-0 shadow-xs flex items-center justify-center text-white" style={{ backgroundColor: item.hex }}>
                          {isSelected && <Check className="w-3 h-3 drop-shadow"/>}
                        </div>
                        <div className="min-w-0">
                          <p className="font-mono text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate">
                            {item.hex}
                          </p>
                          <p className="text-[9px] text-slate-500 truncate">{item.name}</p>
                        </div>
                      </button>);
            })}
                </div>
              </div>

              {/* Live Preview Box */}
              <div className="p-4 rounded-2xl border text-white transition-all shadow-sm flex items-center justify-between" style={{ backgroundColor: themeColor }}>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded">
                    Active Theme Live Preview
                  </span>
                  <p className="text-sm font-black mt-1">Theme successfully synchronized across all pages</p>
                </div>
                <CheckCircle2 className="w-6 h-6 text-white shrink-0"/>
              </div>
            </div>)}

          {/* ================= LANGUAGE TAB ================= */}
          {activeTab === 'language' && (<div className="space-y-5 text-xs">
              <div className="p-4 bg-blue-50 dark:bg-slate-800 border border-blue-200 dark:border-blue-900 rounded-xl space-y-1">
                <p className="font-bold text-blue-900 dark:text-blue-300 text-sm">
                  🌐 {t('language', 'Language')} • முழு தமிழ் மற்றும் ஆங்கில விருப்பங்கள்
                </p>
                <p className="text-slate-600 dark:text-slate-300 text-[11px]">
                  தேசிய பொறியியல் கல்லூரி மாணவர்களுக்காக முழு வலைத்தளமும் சுத்தமான தமிழில் மாறும். அனைத்து 18 தொகுதிகளும், வினாக்கள், பொத்தான்கள், மற்றும் தலைப்புகளும் தமிழில் தோன்றும்.
                </p>
              </div>

              <div className="space-y-3">
                {/* Tamil Card */}
                <button type="button" onClick={() => updateSettings({ language: 'ta' })} className={`w-full p-4 rounded-xl border text-left transition cursor-pointer flex items-start justify-between gap-3 ${language === 'ta'
                ? 'border-blue-600 bg-blue-50/50 dark:bg-slate-800 ring-2 ring-blue-500/20'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 bg-white dark:bg-slate-900'}`}>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-base text-slate-900 dark:text-white">தமிழ் (Tamil)</span>
                      {language === 'ta' && (<span className="text-[10px] font-bold px-2 py-0.5 bg-blue-600 text-white rounded-full">
                          செயலில் உள்ளது (Active)
                        </span>)}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      முழு வலைத்தளமும் தமிழில் மாறும் — முகப்பு, இளநிலை வழிகாட்டி, நிர்வாக மையம், வினா வங்கி, நிறுவனத் தேடல், மற்றும் அனைத்து பொத்தான்களும் தமிழில் தோன்றும்.
                    </p>
                  </div>
                  <div className={`w-6 h-6 rounded-full border shrink-0 flex items-center justify-center transition ${language === 'ta' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white'}`}>
                    {language === 'ta' && <Check className="w-4 h-4"/>}
                  </div>
                </button>

                {/* English Card */}
                <button type="button" onClick={() => updateSettings({ language: 'en' })} className={`w-full p-4 rounded-xl border text-left transition cursor-pointer flex items-start justify-between gap-3 ${language === 'en'
                ? 'border-blue-600 bg-blue-50/50 dark:bg-slate-800 ring-2 ring-blue-500/20'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 bg-white dark:bg-slate-900'}`}>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-base text-slate-900 dark:text-white">English (Default)</span>
                      {language === 'en' && (<span className="text-[10px] font-bold px-2 py-0.5 bg-blue-600 text-white rounded-full">
                          Active
                        </span>)}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Standard corporate and technical placement ecosystem interface with standard software terms.
                    </p>
                  </div>
                  <div className={`w-6 h-6 rounded-full border shrink-0 flex items-center justify-center transition ${language === 'en' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white'}`}>
                    {language === 'en' && <Check className="w-4 h-4"/>}
                  </div>
                </button>
              </div>
            </div>)}

          {/* ================= NOTIFICATIONS TAB ================= */}
          {activeTab === 'notifications' && (<div className="space-y-6 text-xs">
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-900 dark:text-white text-xs">Recent Alerts & Reminders</h3>
                    {unreadCount > 0 && (<span className="text-[10px] font-bold px-2 py-0.5 bg-rose-500 text-white rounded-full">
                        {unreadCount} unread
                      </span>)}
                  </div>
                  {unreadCount > 0 && (<button onClick={handleMarkAllRead} className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 hover:underline cursor-pointer">
                      {t('markAllAsRead', 'Mark all as read')}
                    </button>)}
                </div>

                {filteredNotifications.length === 0 ? (<p className="text-slate-400 py-6 text-center">No alerts at this moment.</p>) : (<div className="space-y-2">
                    {filteredNotifications.map((notif) => (<div key={notif.id} className={`p-3 rounded-xl border transition ${notif.isRead
                        ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-80'
                        : 'bg-blue-50/40 dark:bg-slate-800 border-blue-200'}`}>
                        <div className="flex items-center justify-between">
                          <p className="font-bold text-slate-900 dark:text-white text-xs">{notif.title}</p>
                          <span className="text-[10px] text-slate-400">{new Date(notif.createdAt).toLocaleDateString()}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-1">{notif.message}</p>
                      </div>))}
                  </div>)}
              </div>
            </div>)}

          {/* ================= ACCOUNT TAB ================= */}
          {activeTab === 'account' && (<div className="space-y-5 text-xs">
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 space-y-2">
                <p className="font-bold text-slate-900 dark:text-white text-sm">Account Overview</p>
                <p><strong>Name:</strong> {user?.name}</p>
                <p><strong>Email:</strong> {user?.email}</p>
                <p><strong>Role:</strong> {user?.role}</p>
                <p><strong>College:</strong> {user?.college}</p>
              </div>

              <form onSubmit={handlePasswordChange} className="space-y-3 p-4 border rounded-xl dark:border-slate-800">
                <p className="font-bold text-slate-900 dark:text-white text-xs">Change Password</p>
                {passwordMsg && (<p className={`text-xs ${passwordMsg.success ? 'text-emerald-600' : 'text-rose-600'}`}>{passwordMsg.text}</p>)}
                <input type="password" placeholder="New password (min 6 chars)" value={passwordState.new} onChange={(e) => setPasswordState({ ...passwordState, new: e.target.value })} className="w-full px-3 py-2 border rounded-lg bg-slate-50 dark:bg-slate-800 dark:border-slate-700 outline-none"/>
                <input type="password" placeholder="Confirm new password" value={passwordState.confirm} onChange={(e) => setPasswordState({ ...passwordState, confirm: e.target.value })} className="w-full px-3 py-2 border rounded-lg bg-slate-50 dark:bg-slate-800 dark:border-slate-700 outline-none"/>
                <button type="submit" className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-lg cursor-pointer">
                  Update Password
                </button>
              </form>
            </div>)}

          {/* ================= ACCESSIBILITY TAB ================= */}
          {activeTab === 'accessibility' && (<div className="space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl border dark:border-slate-800">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">High Contrast</p>
                  <p className="text-slate-500 text-[11px]">Boost text and border contrast for reading clarity</p>
                </div>
                <input type="checkbox" checked={settings.accessibility.highContrast} onChange={(e) => updateSettings({
                accessibility: { ...settings.accessibility, highContrast: e.target.checked },
            })} className="w-4 h-4 text-blue-600 rounded"/>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl border dark:border-slate-800">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">Comfortable Reading Font</p>
                  <p className="text-slate-500 text-[11px]">Optimized line height and spacing</p>
                </div>
                <input type="checkbox" checked={settings.accessibility.comfortableReading} onChange={(e) => updateSettings({
                accessibility: { ...settings.accessibility, comfortableReading: e.target.checked },
            })} className="w-4 h-4 text-blue-600 rounded"/>
              </div>
            </div>)}

          {/* ================= PRIVACY TAB ================= */}
          {activeTab === 'privacy' && (<div className="space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl border dark:border-slate-800">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">Activity Visibility</p>
                  <p className="text-slate-500 text-[11px]">Display your study streak on the student leaderboard</p>
                </div>
                <input type="checkbox" checked={settings.privacy.activityVisibility} onChange={(e) => updateSettings({
                privacy: { ...settings.privacy, activityVisibility: e.target.checked },
            })} className="w-4 h-4 text-blue-600 rounded"/>
              </div>
            </div>)}

          {/* ================= DEPLOYMENT & RENDER CLOUD TAB ================= */}
          {activeTab === 'deployment' && (<div className="space-y-6 text-xs animate-in fade-in">
              <div className="p-5 rounded-2xl text-white shadow-md relative overflow-hidden" style={{
                background: `linear-gradient(135deg, ${themeColor} 0%, #0f172a 100%)`,
            }}>
                <div className="flex items-center gap-2 mb-1">
                  <Cloud className="w-5 h-5 text-emerald-300"/>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-300">
                    Production Cloud Hosting & Database
                  </span>
                </div>
                <h3 className="text-xl font-black">Render Deployment Links & Atlas Configuration</h3>
                <p className="text-xs text-blue-100 mt-1 max-w-xl leading-relaxed">
                  Your full-stack application is architected for instant deployment to Render.com connected to MongoDB Atlas Cloud Cluster.
                </p>
              </div>

              {/* Live Deployment Links */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">🌐 Production Deployment URLs</h4>
                
                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-xs">Frontend Client (Vite + React SPA)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800">Static Site</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-xs text-blue-900 dark:text-blue-300 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="truncate flex-1">https://nec-placement-portal.onrender.com</span>
                    <a href="https://nec-placement-portal.onrender.com" target="_blank" rel="noopener noreferrer" className="text-xs px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer">
                      <ExternalLink className="w-3 h-3"/>
                      <span>Open Live</span>
                    </a>
                  </div>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-xs">Backend REST API Server (Node.js + Express)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-blue-100 text-blue-800">Web Service</span>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-xs text-blue-900 dark:text-blue-300 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                    <span className="truncate flex-1">https://nec-placement-backend.onrender.com</span>
                    <a href="https://nec-placement-backend.onrender.com/api/health" target="_blank" rel="noopener noreferrer" className="text-xs px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer">
                      <ExternalLink className="w-3 h-3"/>
                      <span>Health Check</span>
                    </a>
                  </div>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-xs">Database (MongoDB Atlas Cloud Cluster)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800">Atlas Cluster0</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-emerald-400 text-[11px] break-all border border-slate-800">
                    mongodb+srv://admin:Placement2026@cluster0.mongodb.net/nec_placement?retryWrites=true&w=majority
                  </div>
                </div>
              </div>

              {/* Step-by-Step Render Deployment Guide */}
              <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">🚀 How to Deploy on Render.com</h4>
                
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                    <p className="font-bold text-slate-900 dark:text-white">Step 1: Deploy Backend Web Service on Render</p>
                    <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 mt-1 space-y-1">
                      <li>Go to <a href="https://dashboard.render.com" target="_blank" rel="noreferrer" className="text-blue-600 underline">dashboard.render.com</a> → Click <strong>New +</strong> → <strong>Web Service</strong>.</li>
                      <li>Root Directory: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">backend</code></li>
                      <li>Build Command: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">npm install</code></li>
                      <li>Start Command: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">node server.js</code></li>
                      <li>Environment Variable: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">MONGO_URI</code> = your MongoDB Atlas connection string.</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                    <p className="font-bold text-slate-900 dark:text-white">Step 2: Deploy Frontend Static Site on Render</p>
                    <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 mt-1 space-y-1">
                      <li>Click <strong>New +</strong> → <strong>Static Site</strong>.</li>
                      <li>Build Command: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">npm run build</code></li>
                      <li>Publish Directory: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">dist</code></li>
                      <li>Add Rewrite Rule: <code className="bg-slate-100 dark:bg-slate-900 px-1 rounded">{'/* → /index.html'}</code> (Rewrite).</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-slate-950 text-slate-200 rounded-xl font-mono text-[11px] space-y-1">
                    <p className="text-amber-400 font-bold">💻 VS Code Terminal Commands to Run Locally:</p>
                    <p className="text-emerald-400"># 1. Start Backend with MongoDB Atlas Output:</p>
                    <p className="text-white">node backend/server.js</p>
                    <p className="text-emerald-400 mt-2"># 2. Start Frontend App (in another terminal):</p>
                    <p className="text-white">npm run dev</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

