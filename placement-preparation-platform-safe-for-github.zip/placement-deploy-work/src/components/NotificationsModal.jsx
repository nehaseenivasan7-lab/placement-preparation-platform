import React, { useState, useEffect } from 'react';
import { X, Bell, CheckCheck, MessageSquare, Calendar, Award } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { storageService } from '../services/storage';
export const NotificationsModal = ({ isOpen, onClose, onSelectAction }) => {
    const { user } = useAuth();
    const [notifications, setNotifications] = useState([]);
    const [filter, setFilter] = useState('all');
    useEffect(() => {
        if (user && isOpen) {
            setNotifications(storageService.getNotifications(user.id));
        }
    }, [user, isOpen]);
    if (!isOpen || !user)
        return null;
    const handleMarkAllRead = () => {
        storageService.markAllNotificationsAsRead(user.id);
        setNotifications(storageService.getNotifications(user.id));
    };
    const handleMarkOneRead = (id) => {
        storageService.markNotificationAsRead(user.id, id);
        setNotifications(storageService.getNotifications(user.id));
    };
    const filtered = notifications.filter((n) => (filter === 'unread' ? !n.isRead : true));
    const getIcon = (type) => {
        switch (type) {
            case 'mock':
            case 'gd':
                return <Calendar className="w-4 h-4 text-purple-600"/>;
            case 'mentorship':
            case 'doubt':
                return <MessageSquare className="w-4 h-4 text-blue-600"/>;
            case 'challenge':
                return <Award className="w-4 h-4 text-emerald-600"/>;
            default:
                return <Bell className="w-4 h-4 text-amber-600"/>;
        }
    };
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-400"/>
            <h3 className="font-bold text-sm">Notifications & Alerts</h3>
            {notifications.some((n) => !n.isRead) && (<span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.5 rounded-full font-bold">
                {notifications.filter((n) => !n.isRead).length} new
              </span>)}
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer">
            <X className="w-4 h-4"/>
          </button>
        </div>

        {/* Filter bar */}
        <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5">
            <button onClick={() => setFilter('all')} className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${filter === 'all' ? 'bg-white shadow-xs text-blue-900 border border-slate-200' : 'text-slate-600 hover:bg-slate-200/60'}`}>
              All ({notifications.length})
            </button>
            <button onClick={() => setFilter('unread')} className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${filter === 'unread' ? 'bg-white shadow-xs text-blue-900 border border-slate-200' : 'text-slate-600 hover:bg-slate-200/60'}`}>
              Unread ({notifications.filter((n) => !n.isRead).length})
            </button>
          </div>

          <button onClick={handleMarkAllRead} className="flex items-center gap-1 text-[11px] font-semibold text-blue-700 hover:underline cursor-pointer">
            <CheckCheck className="w-3.5 h-3.5"/>
            <span>Mark all read</span>
          </button>
        </div>

        {/* Notification list */}
        <div className="divide-y divide-slate-100 max-h-[60vh] overflow-y-auto">
          {filtered.length === 0 ? (<div className="p-8 text-center text-slate-500 text-xs">
              <Bell className="w-8 h-8 mx-auto text-slate-300 mb-2"/>
              <p className="font-semibold text-slate-700">No notifications right now</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                You'll receive alerts for mock interview slots, challenge completions, and senior answers here.
              </p>
            </div>) : (filtered.map((item) => (<div key={item.id} onClick={() => handleMarkOneRead(item.id)} className={`p-3.5 flex items-start gap-3 transition cursor-pointer hover:bg-slate-50 ${!item.isRead ? 'bg-blue-50/40' : 'bg-white'}`}>
                <div className="p-2 rounded-xl bg-slate-100 shrink-0 mt-0.5">{getIcon(item.type)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <p className={`text-xs ${!item.isRead ? 'font-bold text-slate-900' : 'font-semibold text-slate-700'}`}>
                      {item.title}
                    </p>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{item.message}</p>
                </div>
                {!item.isRead && <div className="w-2 h-2 rounded-full bg-blue-600 shrink-0 mt-2"/>}
              </div>)))}
        </div>
      </div>
    </div>);
};
