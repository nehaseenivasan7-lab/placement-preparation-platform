import React, { useState } from 'react';
import { X, Award, Briefcase, GraduationCap, Link2, Edit3, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { storageService } from '../services/storage';
export const ProfileModal = ({ isOpen, onClose }) => {
    const { user, updateProfile } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState({
        name: user?.name || '',
        phone: user?.phone || '',
        degree: user?.degree || 'B.E.',
        department: user?.department || 'Computer Science & Engineering',
        graduationYear: user?.graduationYear || 2027,
        currentSemester: user?.currentSemester || 5,
        bio: user?.bio || '',
        linkedin: user?.linkedin || '',
        github: user?.github || '',
        portfolio: user?.portfolio || '',
        skills: user?.skills?.join(', ') || '',
        preferredCompanies: user?.preferredCompanies?.join(', ') || '',
        preferredJobRoles: user?.preferredJobRoles?.join(', ') || '',
        jobRole: user?.jobRole || '',
        currentCompany: user?.currentCompany || '',
    });
    if (!isOpen || !user)
        return null;
    const progress = storageService.getUserProgress(user.id);
    const handleSave = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await updateProfile({
                name: formData.name,
                phone: formData.phone,
                degree: formData.degree,
                department: formData.department,
                graduationYear: Number(formData.graduationYear),
                currentSemester: Number(formData.currentSemester),
                bio: formData.bio,
                linkedin: formData.linkedin,
                github: formData.github,
                portfolio: formData.portfolio,
                skills: formData.skills ? formData.skills.split(',').map((s) => s.trim()).filter(Boolean) : [],
                preferredCompanies: formData.preferredCompanies
                    ? formData.preferredCompanies.split(',').map((s) => s.trim()).filter(Boolean)
                    : [],
                preferredJobRoles: formData.preferredJobRoles
                    ? formData.preferredJobRoles.split(',').map((s) => s.trim()).filter(Boolean)
                    : [],
                jobRole: formData.jobRole,
                currentCompany: formData.currentCompany,
            });
            setIsEditing(false);
        }
        catch (err) {
            console.error(err);
        }
        finally {
            setSaving(false);
        }
    };
    return (<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Banner with college aesthetic */}
        <div className="h-28 bg-linear-to-r from-blue-900 via-indigo-900 to-slate-900 px-6 py-4 flex items-start justify-between relative">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
              National Engineering College
            </span>
            <h3 className="text-white text-lg font-bold mt-1">Official Student & Mentor Profile</h3>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer">
            <X className="w-5 h-5"/>
          </button>
        </div>

        {/* Profile Header Details */}
        <div className="px-6 pt-0 pb-6 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-12 mb-4 gap-4">
            <div className="flex items-end gap-4">
              <div className="w-24 h-24 rounded-2xl bg-white p-1 shadow-lg border-2 border-white shrink-0 overflow-hidden">
                {user.avatar ? (<img src={user.avatar} alt={user.name} className="w-full h-full object-cover rounded-xl"/>) : (<div className="w-full h-full bg-blue-100 text-blue-900 flex items-center justify-center text-3xl font-extrabold rounded-xl">
                    {user.name.charAt(0)}
                  </div>)}
              </div>
              <div className="mb-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold text-slate-900">{user.name}</h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 font-semibold border border-blue-200 capitalize">
                    {user.role === 'junior'
            ? 'Junior · 2nd Year'
            : user.role === 'pre_final'
                ? 'Pre-Final Year'
                : user.role === 'senior'
                    ? `Senior · ${user.specialization || 'Mentor'}`
                    : 'Administrator'}
                  </span>
                </div>
                <p className="text-xs text-slate-500">{user.email}</p>
                {user.seniorId && (<p className="text-[11px] font-mono text-amber-700 font-semibold mt-0.5">
                    Senior Mentor ID: {user.seniorId}
                  </p>)}
              </div>
            </div>

            <button onClick={() => setIsEditing(!isEditing)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 hover:bg-slate-50 transition cursor-pointer self-start sm:self-auto">
              <Edit3 className="w-3.5 h-3.5"/>
              <span>{isEditing ? 'Cancel Edit' : 'Edit Profile'}</span>
            </button>
          </div>

          {/* Readiness Score Pill for Students */}
          {user.role !== 'admin' && (<div className="p-3 bg-linear-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100 flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-blue-700"/>
                <div>
                  <p className="text-xs font-bold text-slate-900">Placement Readiness Status</p>
                  <p className="text-[11px] text-slate-500">Calculated from genuine test attempts & mock sessions</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xl font-extrabold text-blue-900">{progress.readinessScore}%</span>
                <p className="text-[10px] text-slate-500 font-medium">Readiness Index</p>
              </div>
            </div>)}

          {/* Profile Form (Edit Mode or View Mode) */}
          {isEditing ? (<form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Full Name</label>
                  <input type="text" required value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Phone Number</label>
                  <input type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Department / Branch</label>
                  <input type="text" value={formData.department} onChange={(e) => setFormData({ ...formData, department: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Graduation Year</label>
                  <input type="number" value={formData.graduationYear} onChange={(e) => setFormData({ ...formData, graduationYear: Number(e.target.value) })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div className="sm:col-span-2">
                  <label className="font-semibold text-slate-700 block mb-1">Technical Skills (comma separated)</label>
                  <input type="text" value={formData.skills} placeholder="Java, Python, DSA, SQL, Web" onChange={(e) => setFormData({ ...formData, skills: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div className="sm:col-span-2">
                  <label className="font-semibold text-slate-700 block mb-1">Target Companies (comma separated)</label>
                  <input type="text" value={formData.preferredCompanies} placeholder="Zoho, TCS, Amazon, Bosch" onChange={(e) => setFormData({ ...formData, preferredCompanies: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">LinkedIn Profile</label>
                  <input type="url" value={formData.linkedin} placeholder="https://linkedin.com/in/username" onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">GitHub Profile</label>
                  <input type="url" value={formData.github} placeholder="https://github.com/username" onChange={(e) => setFormData({ ...formData, github: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
                <div className="sm:col-span-2">
                  <label className="font-semibold text-slate-700 block mb-1">Brief Bio</label>
                  <textarea rows={2} value={formData.bio} onChange={(e) => setFormData({ ...formData, bio: e.target.value })} className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"/>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 text-xs font-semibold rounded-lg border text-slate-700 hover:bg-slate-50 transition">
                  Cancel
                </button>
                <button type="submit" disabled={saving} className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-blue-700 hover:bg-blue-800 text-white shadow-xs transition">
                  <Check className="w-3.5 h-3.5"/>
                  <span>{saving ? 'Saving...' : 'Save Profile'}</span>
                </button>
              </div>
            </form>) : (<div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <GraduationCap className="w-4 h-4 text-blue-700 mt-0.5 shrink-0"/>
                  <div>
                    <p className="font-bold text-slate-800">Academic Background</p>
                    <p className="text-slate-600 mt-0.5">{user.degree} in {user.department}</p>
                    <p className="text-[11px] text-slate-500">Graduation Year: {user.graduationYear} (Semester {user.currentSemester || 'N/A'})</p>
                    <p className="text-[11px] text-slate-500">{user.college}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <Briefcase className="w-4 h-4 text-blue-700 mt-0.5 shrink-0"/>
                  <div>
                    <p className="font-bold text-slate-800">
                      {user.role === 'senior' ? 'Placement & Experience' : 'Target Career Goals'}
                    </p>
                    {user.role === 'senior' ? (<>
                        <p className="text-slate-700 font-semibold mt-0.5">{user.currentCompany || 'Placed Senior'}</p>
                        <p className="text-[11px] text-slate-600">{user.jobRole || 'Software Engineer'}</p>
                        <p className="text-[11px] text-emerald-700 font-semibold">{user.placementStatus}</p>
                      </>) : (<>
                        <p className="text-slate-700 mt-0.5">
                          Target: {user.preferredCompanies?.join(', ') || 'Zoho, TCS, Amazon'}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Roles: {user.preferredJobRoles?.join(', ') || 'Software Engineer'}
                        </p>
                      </>)}
                  </div>
                </div>
              </div>

              {/* Skills Tags */}
              <div>
                <p className="font-bold text-slate-800 mb-2">Technical Skills & Competencies</p>
                <div className="flex flex-wrap gap-1.5">
                  {user.skills && user.skills.length > 0 ? (user.skills.map((skill, idx) => (<span key={idx} className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium text-[11px] border border-slate-200">
                        {skill}
                      </span>))) : (<span className="text-slate-400 italic">No skills added yet. Click Edit Profile.</span>)}
                </div>
              </div>

              {/* Bio & Social Links */}
              {user.bio && (<div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="font-bold text-slate-800 mb-1">About</p>
                  <p className="text-slate-600 leading-relaxed">{user.bio}</p>
                </div>)}

              <div className="flex items-center gap-3 pt-2 border-t border-slate-100">
                {user.linkedin && (<a href={user.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-blue-700 hover:underline font-semibold">
                    <Link2 className="w-3.5 h-3.5"/>
                    <span>LinkedIn Profile</span>
                  </a>)}
                {user.github && (<a href={user.github} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-slate-800 hover:underline font-semibold">
                    <Link2 className="w-3.5 h-3.5"/>
                    <span>GitHub</span>
                  </a>)}
              </div>
            </div>)}
        </div>
      </div>
    </div>);
};
