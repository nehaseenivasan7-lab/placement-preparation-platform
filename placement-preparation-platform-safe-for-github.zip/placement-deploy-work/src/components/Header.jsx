import React, { useState } from 'react';
import { Settings as SettingsIcon, User as UserIcon, Search, LogOut, HelpCircle, ChevronDown, Bell, Globe, Sun, Moon, Palette, } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { storageService } from '../services/storage';
export const Header = ({ onOpenProfile, onOpenSettings, onOpenHelp, searchQuery, setSearchQuery, }) => {
    const { user, logout } = useAuth();
    const { language, toggleLanguage, mode, toggleMode, themeColor, t } = useTheme();
    const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
    const notifications = user ? storageService.getNotifications(user.id) : [];
    const unreadCount = notifications.filter((n) => !n.isRead).length;
    const getRoleBadge = () => {
        if (!user)
            return null;
        switch (user.role) {
            case 'junior':
                return (<span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-semibold border border-blue-200">
            {t('junior', 'Junior · 2nd Year')}
          </span>);
            case 'pre_final':
                return (<span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-semibold border border-indigo-200">
            {t('pre_final', 'Pre-Final Year')}
          </span>);
            case 'senior':
                return (<span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 font-semibold border border-amber-200">
            {t('senior', 'Senior Mentor')}
          </span>);
            case 'admin':
                return (<span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-900 font-semibold border border-purple-200">
            {t('admin', 'Placement Admin')}
          </span>);
            default:
                return null;
        }
    };
    return (<header className="sticky top-0 z-30 flex items-center justify-between px-4 lg:px-6 py-2.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs transition-colors">
      {/* College Identity / Branding */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl text-white font-bold shadow-md shrink-0 transition-colors" style={{ backgroundColor: themeColor }}>
          <span className="text-sm tracking-wider font-extrabold text-amber-300">NEC</span>
        </div>
        <div className="hidden sm:block">
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-slate-900 dark:text-white tracking-tight leading-none">
              {t('platformTitle', 'Placement Preparation Platform')}
            </h1>
            <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded">
              NEC
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            {t('collegeName', 'National Engineering College, Kovilpatti')}
          </p>
        </div>
      </div>

      {/* Global Search Bar */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
          <input type="text" placeholder={t('search')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-100 focus:bg-white dark:focus:bg-slate-800 border border-transparent focus:border-blue-400 rounded-lg outline-none transition-all dark:text-white"/>
        </div>
      </div>

      {/* Action Icons & Quick Control Buttons */}
      <div className="flex items-center gap-2 lg:gap-2.5">
        {/* Quick Language Toggle Button (EN <-> தமிழ்) */}
        <button onClick={toggleLanguage} title="Switch Language (English / தமிழ்)" className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${language === 'ta'
            ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-200'}`}>
          <Globe className="w-3.5 h-3.5"/>
          <span>{language === 'ta' ? 'தமிழ்' : 'English'}</span>
        </button>

        {/* Quick Light / Dark Mode Toggle Button */}
        <button onClick={toggleMode} title={`Switch to ${mode === 'light' ? 'Dark' : 'Light'} Mode`} className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer border border-slate-200 dark:border-slate-800">
          {mode === 'light' ? (<Moon className="w-4 h-4 text-slate-700"/>) : (<Sun className="w-4 h-4 text-amber-400"/>)}
        </button>

        {/* Settings button */}
        <button onClick={() => onOpenSettings()} title={t('settings')} className="relative p-2 text-slate-600 dark:text-slate-300 hover:text-blue-900 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer flex items-center gap-1.5 border border-slate-200 dark:border-slate-800">
          <SettingsIcon className="w-4 h-4"/>
          <span className="text-xs font-semibold hidden lg:inline text-slate-700 dark:text-slate-300">
            {t('settings')}
          </span>
          {unreadCount > 0 && (<span className="flex h-2 w-2 rounded-full bg-rose-600"/>)}
        </button>

        {/* Profile Menu Dropdown */}
        <div className="relative">
          <button onClick={() => setProfileDropdownOpen(!profileDropdownOpen)} className="flex items-center gap-2 pl-2 pr-2.5 py-1 text-left rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-200 border border-slate-300 shrink-0">
              {user?.avatar ? (<img src={user.avatar} alt={user.name} className="w-full h-full object-cover"/>) : (<div className="w-full h-full flex items-center justify-center font-bold text-xs text-white" style={{ backgroundColor: themeColor }}>
                  {user?.name?.charAt(0) || 'U'}
                </div>)}
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight flex items-center gap-1.5">
                {user?.name || 'Guest'}
                <ChevronDown className="w-3 h-3 text-slate-400"/>
              </div>
              <div className="mt-0.5">{getRoleBadge()}</div>
            </div>
          </button>

          {/* Profile Dropdown Menu */}
          {profileDropdownOpen && (<div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-50">
              <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <p className="text-xs font-bold text-slate-900 dark:text-white">{user?.name}</p>
                <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
                <div className="mt-1.5">{getRoleBadge()}</div>
              </div>
              <button onClick={() => {
                setProfileDropdownOpen(false);
                onOpenProfile();
            }} className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800 transition">
                <UserIcon className="w-4 h-4 text-slate-500"/>
                <span>{t('profile')}</span>
              </button>
              <button onClick={() => {
                setProfileDropdownOpen(false);
                onOpenSettings('appearance');
            }} className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800 transition">
                <Palette className="w-4 h-4 text-slate-500"/>
                <span>{t('themeColor', 'Themes & Mode')}</span>
              </button>
              <button onClick={() => {
                setProfileDropdownOpen(false);
                onOpenSettings('notifications');
            }} className="w-full flex items-center justify-between px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800 transition">
                <div className="flex items-center gap-2.5">
                  <Bell className="w-4 h-4 text-slate-500"/>
                  <span>{t('notifications')}</span>
                </div>
                {unreadCount > 0 && (<span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.2 rounded-full font-bold">
                    {unreadCount}
                  </span>)}
              </button>
              <button onClick={() => {
                setProfileDropdownOpen(false);
                onOpenHelp();
            }} className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800 transition">
                <HelpCircle className="w-4 h-4 text-slate-500"/>
                <span>{t('help')}</span>
              </button>
              <div className="my-1 border-t border-slate-100 dark:border-slate-800"/>
              <button onClick={() => {
                setProfileDropdownOpen(false);
                logout();
            }} className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition">
                <LogOut className="w-4 h-4 text-rose-500"/>
                <span>{t('logout')}</span>
              </button>
            </div>)}
        </div>
      </div>
    </header>);
};
