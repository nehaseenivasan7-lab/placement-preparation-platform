const STORAGE_KEYS = {
    USERS: 'necpp_users',
    CURRENT_USER: 'necpp_current_user',
    TOKEN: 'necpp_jwt_token',
    PROGRESS: 'necpp_progress_',
    SETTINGS: 'necpp_settings_',
    COMPANIES: 'necpp_companies',
    PLAYBOOKS: 'necpp_playbooks',
    EXPERIENCES: 'necpp_experiences',
    RESOURCES: 'necpp_resources',
    QUESTIONS: 'necpp_questions',
    CHALLENGES: 'necpp_challenges',
    MOCK_INTERVIEWS: 'necpp_mock_interviews',
    MOCK_GDS: 'necpp_mock_gds',
    MENTORSHIP_REQUESTS: 'necpp_mentorship_requests',
    DOUBTS: 'necpp_doubts',
    PEER_POSTS: 'necpp_peer_posts',
    STUDY_GOALS: 'necpp_study_goals',
    NOTIFICATIONS: 'necpp_notifications',
    FEEDBACK: 'necpp_feedback',
    RECENTLY_ACCESSED: 'necpp_recently_accessed',
    SENIOR_CONTRIBUTIONS: 'necpp_senior_contributions',
    USER_PASSWORDS: 'necpp_user_passwords',
    // Placement Ecosystem Keys
    ALUMNI_SESSIONS: 'necpp_alumni_sessions',
    ALUMNI_FEEDBACK: 'necpp_alumni_feedback',
    ORGANIZATIONS: 'necpp_organizations',
    COMPANY_REQUIREMENTS: 'necpp_company_requirements',
    COMPANY_INTERACTIONS: 'necpp_company_interactions',
    COMPANY_DRIVE_FEEDBACK: 'necpp_company_drive_feedback',
    PLACEMENT_DRIVES: 'necpp_placement_drives',
    DRIVE_PARTICIPATION: 'necpp_drive_participation',
    PLACEMENT_RESULTS: 'necpp_placement_results',
};
// Initial Verified Test Users
const INITIAL_USERS = [
    {
        id: 'usr_junior_25104001',
        name: 'Dinesh Kumar V',
        email: '25104001@nec.edu.in',
        phone: '+91 98401 23451',
        role: 'junior',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2028,
        currentSemester: 4,
        preferredCompanies: ['Zoho', 'TCS', 'Amazon'],
        preferredJobRoles: ['Software Development Engineer', 'Full Stack Developer'],
        skills: ['C++', 'Python', 'Data Structures', 'Web Basics'],
        careerInterests: ['Product Development', 'Cloud Computing'],
        bio: 'Junior 2nd year student (Batch 25).',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_junior_25104002',
        name: 'Deepika M',
        email: '25104002@nec.edu.in',
        phone: '+91 98401 23452',
        role: 'junior',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2028,
        currentSemester: 4,
        preferredCompanies: ['Zoho', 'Accenture', 'Cognizant'],
        preferredJobRoles: ['Software Engineer', 'Data Analyst'],
        skills: ['Java', 'SQL', 'Python', 'HTML/CSS'],
        careerInterests: ['Frontend Development', 'Database Administration'],
        bio: 'Junior 2nd year student (Batch 25).',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_prefinal_24104009',
        name: 'Karthik Raja M',
        email: '24104009@nec.edu.in',
        phone: '+91 94432 56789',
        role: 'pre_final',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2027,
        currentSemester: 6,
        preferredCompanies: ['Zoho', 'TCS', 'Accenture', 'Amazon'],
        preferredJobRoles: ['Full Stack Developer', 'Cloud Engineer'],
        skills: ['React', 'Node.js', 'MongoDB', 'Python', 'DSA', 'SQL'],
        careerInterests: ['Full Stack Web Development', 'AI/ML Applications'],
        bio: 'Pre-final year CSE student actively preparing for campus recruitment drives.',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_prefinal_24104001',
        name: 'Arun Kumar S',
        email: '24104001@nec.edu.in',
        phone: '+91 94432 56781',
        role: 'pre_final',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2027,
        currentSemester: 6,
        preferredCompanies: ['Zoho', 'TCS', 'L&T'],
        preferredJobRoles: ['Software Engineer', 'Backend Developer'],
        skills: ['C++', 'Java', 'SQL', 'Operating Systems'],
        careerInterests: ['Core Software', 'System Engineering'],
        bio: 'Pre-final year student preparing for Day-1 companies.',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_prefinal_24104002',
        name: 'Bavithra K',
        email: '24104002@nec.edu.in',
        phone: '+91 94432 56782',
        role: 'pre_final',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Information Technology',
        graduationYear: 2027,
        currentSemester: 6,
        preferredCompanies: ['Accenture', 'Cognizant', 'TCS'],
        preferredJobRoles: ['Software Engineer', 'Associate Consultant'],
        skills: ['Python', 'SQL', 'DBMS', 'Web Development'],
        careerInterests: ['Software Engineering', 'Data Analytics'],
        bio: 'Pre-final year IT student preparing for online assessments and interviews.',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_prefinal_24104003',
        name: 'Chandran P',
        email: '24104003@nec.edu.in',
        phone: '+91 94432 56783',
        role: 'pre_final',
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2027,
        currentSemester: 6,
        preferredCompanies: ['Zoho', 'Kaar Tech', 'Virtusa'],
        preferredJobRoles: ['Product Engineer', 'Full Stack Developer'],
        skills: ['Java', 'Spring Boot', 'React', 'DSA'],
        careerInterests: ['Enterprise Software', 'Product Development'],
        bio: 'Pre-final year CSE student aiming for Product companies.',
        createdAt: '2026-08-01T10:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_senior_02',
        name: 'Karthik Subramanian',
        email: 'sen002@nec.edu.in',
        phone: '+91 97890 54321',
        role: 'senior',
        seniorId: 'SEN002',
        specialization: 'Company Playbook',
        secondarySpecializations: ['Interview Experience', 'Coding Arena'],
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.Tech',
        department: 'Information Technology',
        graduationYear: 2026,
        currentCompany: 'TCS Digital',
        placementStatus: 'Placed (Digital Cadre)',
        jobRole: 'Systems Engineer - Digital',
        experience: 'Placed in TCS Digital with 7.5 LPA CTC.',
        skills: ['Java', 'Spring', 'Algorithms', 'Microservices'],
        companiesExperienced: ['TCS Digital', 'Accenture'],
        bio: 'Senior Mentor placed at TCS Digital. Mentoring pre-final & junior students.',
        createdAt: '2026-07-15T10:00:00Z',
        badges: ['Active Mentor', 'TCS Specialist'],
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_senior_01',
        name: 'Priya Muthuraman',
        email: 'priya.explorer@nec.edu.in',
        phone: '+91 97890 12345',
        role: 'senior',
        seniorId: 'SEN001',
        specialization: 'Company Explorer',
        secondarySpecializations: ['Company Playbook', 'Round Resources'],
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.Tech',
        department: 'Information Technology',
        graduationYear: 2026,
        currentCompany: 'Zoho Corporation',
        placementStatus: 'Placed (Member Technical Staff)',
        jobRole: 'MTS - Software Developer',
        experience: 'Fresher placed via on-campus drive (CTC: 8.5 LPA)',
        skills: ['Java', 'C++', 'DBMS', 'System Design', 'Algorithms'],
        companiesExperienced: ['Zoho', 'Kaar Tech', 'TCS Digital'],
        bio: 'Placed in Zoho as MTS. Passionate about helping juniors understand company hiring processes.',
        createdAt: '2026-07-15T10:00:00Z',
        badges: ['Active Mentor', 'Company Explorer Lead'],
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_senior_03',
        name: 'Karthik Raja S',
        email: 'karthik.interview@nec.edu.in',
        phone: '+91 96554 43210',
        role: 'senior',
        seniorId: 'SEN003',
        specialization: 'Interview Experience',
        secondarySpecializations: ['Round Resources', 'Resume Guidance'],
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2026,
        currentCompany: 'TCS (Tata Consultancy Services)',
        placementStatus: 'Placed (Digital Cadre)',
        jobRole: 'Systems Engineer - Digital',
        experience: 'Cleared TCS Digital OA and Advanced Technical Interviews (CTC: 7.2 LPA)',
        skills: ['Python', 'SQL', 'Machine Learning', 'Aptitude Mastery'],
        companiesExperienced: ['TCS Digital', 'Infosys SP', 'Cognizant GenC Elevate'],
        bio: 'Helping students crack technical interview rounds and master tricky HR questions.',
        createdAt: '2026-07-15T10:00:00Z',
        badges: ['Interview Mentor', 'Experience Archivist'],
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_senior_04',
        name: 'Deepa Rajan',
        email: 'deepa.qb@nec.edu.in',
        phone: '+91 99441 87654',
        role: 'senior',
        seniorId: 'SEN004',
        specialization: 'Question Bank',
        secondarySpecializations: ['Coding Arena', 'Aptitude Practice'],
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.E.',
        department: 'Computer Science & Engineering',
        graduationYear: 2026,
        currentCompany: 'Infosys',
        placementStatus: 'Placed (Specialist Programmer)',
        jobRole: 'Specialist Programmer (L1)',
        experience: 'Cleared HackWithInfy & Specialist Programmer round (CTC: 9.5 LPA)',
        skills: ['Dynamic Programming', 'Graph Theory', 'Java', 'Data Structures'],
        companiesExperienced: ['Infosys', 'Accenture', 'Virtusa'],
        bio: 'Curating the most frequently asked coding & aptitude questions for college drives.',
        createdAt: '2026-07-15T10:00:00Z',
        badges: ['Question Master', 'Coding Mentor'],
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_senior_07',
        name: 'Sanjay Vignesh',
        email: 'sanjay.mock@nec.edu.in',
        phone: '+91 98840 55667',
        role: 'senior',
        seniorId: 'SEN007',
        specialization: 'Mock Interview',
        secondarySpecializations: ['Technical Interview', 'Mock GD'],
        college: 'National Engineering College, Kovilpatti',
        degree: 'B.Tech',
        department: 'Information Technology',
        graduationYear: 2026,
        currentCompany: 'Amazon',
        placementStatus: 'Placed (SDE Intern + FTE)',
        jobRole: 'Software Development Engineer',
        experience: 'Cleared Amazon 4-round technical & Leadership Principles interview (CTC: 28 LPA)',
        skills: ['Algorithms', 'System Design', 'Object Oriented Design', 'DSA', 'Java'],
        companiesExperienced: ['Amazon', 'Zoho', 'Cisco'],
        bio: 'Specialized in 1-on-1 technical mock interviews, code walkthroughs, and feedback.',
        createdAt: '2026-07-15T10:00:00Z',
        badges: ['Mock Interview Star', 'Amazonian Guide'],
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=256&q=80',
    },
    {
        id: 'usr_admin_01',
        name: 'Dr. K. Placement Officer',
        email: 'admin@nec.edu.in',
        phone: '+91 4632 222502',
        role: 'admin',
        adminId: 'ADM001',
        college: 'National Engineering College, Kovilpatti',
        degree: 'Ph.D.',
        department: 'Training and Placement Cell',
        bio: 'Placement Director & Career Guidance Cell Administrator, National Engineering College.',
        createdAt: '2026-01-01T00:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=256&q=80',
    },
];
// Initial pre-hashed passwords map (default for test accounts: Password@123)
const INITIAL_PASSWORDS = {
    'admin@nec.edu.in': '123',
    'admin': '123',
    'ADM001': '123',
    // Senior Mentors
    'SEN001': '123',
    'sen001@nec.edu.in': '123',
    'SEN002': '123',
    'sen002@nec.edu.in': '123',
    'SEN003': '123',
    'sen003@nec.edu.in': '123',
    'SEN004': '123',
    'sen004@nec.edu.in': '123',
    'SEN007': '123',
    // Pre-Final Year Students
    '24104009': '123',
    '24104009@nec.edu.in': '123',
    '24104001': '123',
    '24104001@nec.edu.in': '123',
    '24104002': '123',
    '24104002@nec.edu.in': '123',
    '24104003': '123',
    '24104003@nec.edu.in': '123',
    // Junior Students
    '25104001': '123',
    '25104001@nec.edu.in': '123',
    '25104002': '123',
    '25104002@nec.edu.in': '123',
    '25104003': '123',
    '25104003@nec.edu.in': '123',
    '25104004': '123',
    '25104004@nec.edu.in': '123',
    '25104009': '123',
    '25104009@nec.edu.in': '123',
    // Fallbacks
    'arun@nec.edu.in': '123',
    'neha@nec.edu.in': '123',
    'priya.explorer@nec.edu.in': '123',
    'karthik.interview@nec.edu.in': '123',
    'deepa.qb@nec.edu.in': '123',
    'sanjay.mock@nec.edu.in': '123',
};
// Initial Seed Companies
const INITIAL_COMPANIES = [
    {
        id: 'cmp_zoho',
        name: 'Zoho Corporation',
        industry: 'Product SaaS & Enterprise Software',
        tier: 'Tier 1 / Product',
        packageRange: '₹6.5 - ₹9.0 LPA',
        eligibilityCgpa: 6.5,
        branchesEligible: ['CSE', 'IT', 'ECE', 'EEE', 'Mech', 'Civil'],
        jobRoles: ['Member Technical Staff (MTS)', 'Quality Analyst', 'UI/UX Engineer'],
        selectionProcess: [
            'Round 1: Basic Aptitude & C Programming MCQs',
            'Round 2: Basic Programming (2-3 Problem Solving)',
            'Round 3: Advanced Programming (Data Structures & Complex Logic)',
            'Round 4: Technical 1-on-1 Interview',
            'Round 5: HR / Fitment Round',
        ],
        pastHiresCount: 42,
        overview: 'Zoho is a pioneer in Indian SaaS known for strict focus on problem-solving fundamentals, logic without external libraries, and high campus hiring at NEC.',
        website: 'https://www.zoho.com',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-10T10:00:00Z',
    },
    {
        id: 'cmp_tcs',
        name: 'Tata Consultancy Services (TCS)',
        industry: 'IT Services & Consulting',
        tier: 'Tier 2 / Tech',
        packageRange: '₹3.6 LPA (Ninja) | ₹7.2 LPA (Digital) | ₹9.0 LPA (Prime)',
        eligibilityCgpa: 6.0,
        branchesEligible: ['All Branches'],
        jobRoles: ['Systems Engineer', 'Digital Engineer', 'Prime Researcher'],
        selectionProcess: [
            'Round 1: National Qualifier Test (NQT) - Cognitive & Coding',
            'Round 2: Advanced Coding Assessment (for Digital/Prime)',
            'Round 3: Technical Interview',
            'Round 4: Managerial + HR Interview',
        ],
        pastHiresCount: 118,
        overview: 'Mass and high-end differential recruiter visiting NEC every season. Strong emphasis on speed math, logical ability, and clean coding.',
        website: 'https://www.tcs.com',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-11T10:00:00Z',
    },
    {
        id: 'cmp_kaar',
        name: 'Kaar Technologies',
        industry: 'Enterprise ERP & Digital Transformation',
        tier: 'Tier 2 / Tech',
        packageRange: '₹6.0 - ₹8.0 LPA',
        eligibilityCgpa: 7.0,
        branchesEligible: ['CSE', 'IT', 'ECE', 'EEE'],
        jobRoles: ['Associate Consultant (SAP)', 'Software Engineer'],
        selectionProcess: [
            'Round 1: Online Aptitude & Technical MCQs',
            'Round 2: Coding Assessment',
            'Round 3: Group Discussion',
            'Round 4: Technical & Cultural Alignment Interview',
        ],
        pastHiresCount: 28,
        overview: 'Chennai-headquartered global SAP leader regularly recruiting top engineering talent from NEC with great training programs.',
        website: 'https://www.kaartech.com',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-12T10:00:00Z',
    },
    {
        id: 'cmp_bosch',
        name: 'Robert Bosch (BGSW)',
        industry: 'Automotive Embedded & Industrial Tech',
        tier: 'Core Engineering',
        packageRange: '₹5.5 - ₹7.5 LPA',
        eligibilityCgpa: 7.0,
        branchesEligible: ['ECE', 'EEE', 'CSE', 'Mech'],
        jobRoles: ['Embedded Software Engineer', 'System Test Engineer'],
        selectionProcess: [
            'Round 1: Core Technical & Aptitude Test',
            'Round 2: Coding in C / Embedded C',
            'Round 3: Technical Panel Interview',
            'Round 4: HR Discussion',
        ],
        pastHiresCount: 22,
        overview: 'Global leader in smart mobility and IoT. Excellent opportunity for ECE, EEE, and CSE students focused on hardware-software interfaces.',
        website: 'https://www.bosch.in',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-14T10:00:00Z',
    },
    {
        id: 'cmp_infosys',
        name: 'Infosys Limited',
        industry: 'Global Technology Services',
        tier: 'Tier 2 / Tech',
        packageRange: '₹3.6 LPA (SE) | ₹6.5 LPA (DSE) | ₹9.5 LPA (SP)',
        eligibilityCgpa: 6.5,
        branchesEligible: ['All Branches'],
        jobRoles: ['Systems Engineer', 'Differential SE', 'Specialist Programmer'],
        selectionProcess: [
            'Round 1: InfyTQ / Online Assessment',
            'Round 2: Advanced Coding Round (Dynamic Programming & Graphs)',
            'Round 3: Technical & Behavioral Interview',
        ],
        pastHiresCount: 65,
        overview: 'Offers Specialist Programmer (SP) roles with high compensation packages for strong competitive programmers at NEC.',
        website: 'https://www.infosys.com',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-15T10:00:00Z',
    },
    {
        id: 'cmp_amazon',
        name: 'Amazon Development Centre',
        industry: 'Cloud, E-Commerce & Big Tech',
        tier: 'Tier 1 / Product',
        packageRange: '₹22 - ₹32 LPA',
        eligibilityCgpa: 7.5,
        branchesEligible: ['CSE', 'IT', 'ECE'],
        jobRoles: ['Software Development Engineer (SDE 1)', 'Data Engineer'],
        selectionProcess: [
            'Round 1: Online Coding Assessment (2 LeetCode Medium/Hard + Work Style Simulation)',
            'Round 2: Technical Interview (DSA & Time Complexity)',
            'Round 3: Technical Interview (Problem Solving & System Design basics)',
            'Round 4: Bar Raiser (Amazon 16 Leadership Principles & Complex Case Study)',
        ],
        pastHiresCount: 6,
        overview: 'Dream tier recruiter. High bar on algorithmic problem solving, trees, graphs, dynamic programming, and behavioral alignment.',
        website: 'https://www.amazon.jobs',
        addedBySeniorId: 'SEN001',
        createdAt: '2026-08-16T10:00:00Z',
    },
];
// Initial Company Playbooks
const INITIAL_PLAYBOOKS = [
    {
        id: 'pb_zoho',
        companyId: 'cmp_zoho',
        companyName: 'Zoho Corporation',
        overview: 'Zoho recruitment is unique in Indian campus placements. They do NOT allow built-in standard library shortcuts (like `std::sort` or Java Collections in initial rounds). You must write logic from scratch using loops, arrays, and string manipulation.',
        preparationStrategy: 'Master matrix manipulations, 2D arrays, recursion, string matching algorithms without library functions, and pattern printing puzzles. Practice creating text-based games (Snake, Railway Reservation, Maze solver) for Round 3.',
        expectedSkills: [
            'C / C++ / Java Fundamentals',
            'Memory Management & Pointers',
            '2D Array Manipulation',
            'Object Oriented Design',
            'Time/Space Complexity optimization',
        ],
        importantTopics: [
            {
                round: 'Round 1: C MCQs & Aptitude',
                topics: ['Pointer arithmetic', 'Precedence of operators', 'Recursion tracing', 'Speed math percentage/ratios'],
            },
            {
                round: 'Round 2: Basic Programming',
                topics: ['String reversal without temp buffer', 'Pattern printing', 'Subarray with given sum', 'Roman to Integer'],
            },
            {
                round: 'Round 3: Advanced Programming',
                topics: ['Railway ticket reservation system', 'Call taxi booking app simulator', 'Snake ladder board game logic'],
            },
            {
                round: 'Round 4: Technical Interview',
                topics: ['Resume project deep dive', 'Live code refactoring', 'OOP concepts in real world', 'Database schema design'],
            },
        ],
        previousTips: [
            'Write clean variable names even during pen-paper rounds.',
            'Explain your thought process aloud to the Zoho panelist.',
            'Do not give up when a test case fails; show your debugging methodology.',
        ],
        seniorRecommendations: 'SEN001 Recommendation: Solve Zoho previous 5 years coding problems available in our Question Bank module before the drive day.',
        updatedBySenior: 'Priya M (SEN001)',
        updatedAt: '2026-08-20T10:00:00Z',
    },
    {
        id: 'pb_tcs',
        companyId: 'cmp_tcs',
        companyName: 'TCS (Tata Consultancy Services)',
        overview: 'TCS NQT is the primary gateway for Ninja (3.6LPA), Digital (7.2LPA), and Prime (9.0LPA) roles. The online test has negative marking in cognitive sections and sectional cutoffs.',
        preparationStrategy: 'Focus 50% on speed aptitude (Percentages, Work & Time, Permutations, Data Interpretation) and 50% on DSA problems for the coding section.',
        expectedSkills: ['Quantitative Aptitude', 'Reasoning Ability', 'Python/Java/C++', 'Basic SQL Queries'],
        importantTopics: [
            {
                round: 'Cognitive Section',
                topics: ['Numerical Ability', 'Verbal Reasoning', 'Inductive & Deductive Logic'],
            },
            {
                round: 'Coding Section',
                topics: ['Array transformations', 'Sliding Window', 'String parsing', 'Dynamic Programming for Digital'],
            },
            {
                round: 'Technical + MR Round',
                topics: ['Final year project explanation', 'DBMS joins and normalization', 'SDLC stages', 'Willingness to relocate'],
            },
        ],
        previousTips: [
            'Do not guess in cognitive section due to negative marking.',
            'Ensure your code passes both public and hidden test cases.',
        ],
        seniorRecommendations: 'SEN003 Recommendation: Spend at least 30 minutes daily on Aptitude Practice module to beat the sectional time limit.',
        updatedBySenior: 'Karthik Raja S (SEN003)',
        updatedAt: '2026-08-21T10:00:00Z',
    },
    {
        id: 'pb_kaar',
        companyId: 'cmp_kaar',
        companyName: 'Kaar Technologies',
        overview: 'Kaar Technologies is a premier global SAP digital transformation consulting company headquartered in Chennai. They hire Associate Software Engineers and SAP Trainees with high retention and fast career acceleration.',
        preparationStrategy: 'Practice Core Java (Collections, Exceptions, Multithreading), SQL Queries (Joins, Aggregations, Group By, Subqueries), and ERP concepts. Group Discussion and Communication clarity are heavily tested.',
        expectedSkills: ['Core Java / C++', 'Relational Databases & SQL', 'Logical Problem Solving', 'Strong Communication & Presentation'],
        importantTopics: [
            {
                round: 'Round 1: Online Aptitude & Technical MCQs',
                topics: ['Quantitative speed math', 'Logical deductions', 'Core Java syntax', 'SQL query output prediction'],
            },
            {
                round: 'Round 2: Group Discussion (GD)',
                topics: ['Digital Transformation in Business', 'AI vs Human Jobs', 'Work from Home vs Hybrid Culture'],
            },
            {
                round: 'Round 3: Technical Interview',
                topics: ['OOP 4 Pillars with real examples', 'Database Normalization', 'Java Collections Framework', 'Final year mini project'],
            },
            {
                round: 'Round 4: Management & HR Interview',
                topics: ['Company history & leadership', 'Relocation to Chennai/Middle East', 'Situational conflict scenarios'],
            },
        ],
        previousTips: [
            'Show genuine passion for Enterprise Software and SAP consulting.',
            'Speak clearly and facilitate others during the GD round without aggression.',
            'Be thorough with your resume projects and be prepared to write code on paper.',
        ],
        seniorRecommendations: 'SEN002 Recommendation: Practice explaining your Database schema and write complex SELECT statements with JOINs and GROUP BY.',
        updatedBySenior: 'Arun Kumar V (SEN002)',
        updatedAt: '2026-08-22T10:00:00Z',
    },
    {
        id: 'pb_cts',
        companyId: 'cmp_cts',
        companyName: 'Cognizant (CTS)',
        overview: 'Cognizant conducts recruitment for GenC (4.0 LPA), GenC Elevate (4.5 LPA), and GenC Next (6.75 LPA). Assessments are conducted on HackerEarth / Superset with rigorous automated proctoring.',
        preparationStrategy: 'Master data structures: Hash Maps, Linked Lists, Stacks, Queues, Binary Trees, and Greedy algorithms. Coding questions emphasize optimal time complexity.',
        expectedSkills: ['Data Structures & Algorithms', 'Python / Java', 'Cloud & Web Basics', 'Analytical Reasoning'],
        importantTopics: [
            {
                round: 'Communication Assessment',
                topics: ['Reading comprehension', 'Listening & sentence repetition', 'Extempore 1-minute speaking'],
            },
            {
                round: 'Technical Assessment (GenC Next)',
                topics: ['2 Medium DSA problems', 'SQL Subqueries', 'Web fundamentals (HTTP, JSON)'],
            },
            {
                round: 'Technical & HR Composite Round',
                topics: ['Data Structures complexity analysis', 'Object Oriented Programming', 'Cloud services familiarity', 'Role preference'],
            },
        ],
        previousTips: [
            'Take the English Communication round in a quiet room with quality headset.',
            'Focus on modular code with descriptive variable names.',
        ],
        seniorRecommendations: 'SEN005 Recommendation: Clear the GenC Elevate coding test by practicing sliding window and recursion problems in our Practice Studio.',
        updatedBySenior: 'Sowmya N (SEN005)',
        updatedAt: '2026-08-23T10:00:00Z',
    },
    {
        id: 'pb_accenture',
        companyId: 'cmp_accenture',
        companyName: 'Accenture',
        overview: 'Accenture recruits for Associate Software Engineer (4.5 LPA) and Advanced ASE (6.5 LPA). The Cognitive & Technical test is an elimination round, followed immediately by Coding and Communication assessment.',
        preparationStrategy: 'Practice Pseudocode interpretation (bitwise operations, nested loops), Common Application & MS Office MCQs, and solve 2 hands-on coding problems within 45 minutes.',
        expectedSkills: ['Pseudocode Tracing', 'Core CS Fundamentals', 'Critical Thinking', 'Hands-on Coding'],
        importantTopics: [
            {
                round: 'Cognitive & Technical Assessment',
                topics: ['Critical Thinking', 'Abstract Reasoning', 'Pseudocode Tracing', 'Networking & Cloud Security'],
            },
            {
                round: 'Coding Round (45 Mins)',
                topics: ['Array manipulation', 'String parsing & formatting', 'Math logic & number theory'],
            },
            {
                round: 'Learning Agility & Interview',
                topics: ['Continuous learning examples', 'Team leadership in college', 'Client handling situation judgment'],
            },
        ],
        previousTips: [
            'Pseudocode section requires high speed; practice tracing variable values in loops.',
            'Both coding questions should be fully passed for Advanced ASE consideration.',
        ],
        seniorRecommendations: 'SEN006 Recommendation: Review bitwise XOR/AND/OR logic thoroughly as Accenture pseudocode relies heavily on them.',
        updatedBySenior: 'Manikandan P (SEN006)',
        updatedAt: '2026-08-24T10:00:00Z',
    },
    {
        id: 'pb_amazon',
        companyId: 'cmp_amazon',
        companyName: 'Amazon',
        overview: 'Amazon campus hiring focuses on Software Development Engineer (SDE-1) and Cloud Support roles. The hiring bar evaluates DSA mastery and adherence to Amazon 16 Leadership Principles.',
        preparationStrategy: 'Solve LeetCode Medium/Hard problems on Dynamic Programming, Graphs, BFS/DFS, Heaps, and System Design basics. Frame all behavioral answers around Amazon Leadership Principles.',
        expectedSkills: ['Advanced DSA', 'System Architecture', 'Time Complexity O(log N) & O(N)', 'Leadership Principles (STAR method)'],
        importantTopics: [
            {
                round: 'Round 1: Online Assessment (OA)',
                topics: ['2 Algorithmic DSA problems', 'Work Style Assessment', 'Amazon Leadership Principles survey'],
            },
            {
                round: 'Round 2: Technical Interview 1',
                topics: ['Trees & Graphs traversal', 'Dynamic Programming', 'Complexity tradeoffs'],
            },
            {
                round: 'Round 3: Technical Interview 2 & Bar Raiser',
                topics: ['Object-Oriented Design (e.g. Parking Lot, Movie Ticket System)', 'Customer Obsession & Ownership stories'],
            },
        ],
        previousTips: [
            'Never jump straight into coding; clarify constraints, inputs, edge cases first.',
            'Have 2 detailed STAR stories ready for each Amazon Leadership Principle.',
        ],
        seniorRecommendations: 'SEN001 Recommendation: Take 1-on-1 Mock Interviews with senior mentors to practice live coding while communicating thought process.',
        updatedBySenior: 'Priya Muthuraman (SEN001)',
        updatedAt: '2026-08-25T10:00:00Z',
    },
];
// Initial Interview Experiences
const INITIAL_EXPERIENCES = [
    {
        id: 'exp_01',
        companyName: 'Zoho Corporation',
        studentName: 'Priya M (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'Member Technical Staff',
        packageOffered: '8.5 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        rounds: [
            {
                roundName: 'Round 1: Screening Test',
                type: 'Online Assessment',
                duration: '90 mins',
                questionsAsked: [
                    'Pointer increment in C: `int *p; *p++ vs (*p)++`',
                    'Output of recursive function with static variable',
                    'Aptitude: Train crossing platform problem and profit/loss calculation',
                ],
                experience: 'There were 15 C MCQs and 10 Aptitude questions. Thorough knowledge of pointers was essential.',
            },
            {
                roundName: 'Round 2: Basic Programming',
                type: 'Technical Round 1',
                duration: '120 mins',
                questionsAsked: [
                    'Given a string `a1b10`, output `abbbbbbbbbb`',
                    'Print matrix in spiral form without extra space',
                    'Find whether given array can be partitioned into two equal sum subsets',
                ],
                experience: 'The panelist watched my screen live. I was not allowed to use any header other than standard I/O.',
            },
            {
                roundName: 'Round 3: Advanced App Design',
                type: 'Technical Round 2',
                duration: '180 mins',
                questionsAsked: [
                    'Design a Railway Ticket Reservation system with Waiting List, RAC, and Confirmed berth allocations with cancellation logic.',
                ],
                experience: 'I spent 30 minutes on paper designing class relationships before writing code in Java. Clean modular functions impressed the mentor.',
            },
            {
                roundName: 'Round 4: Technical & HR Fitment',
                type: 'HR',
                duration: '45 mins',
                questionsAsked: [
                    'Why Zoho over consulting firms?',
                    'Explain your college mini project architecture in detail.',
                    'Are you ready to work in Chennai or Tenkasi campus?',
                ],
                experience: 'Friendly conversation. The interviewer verified my dedication and willingness to learn.',
            },
        ],
        generalTips: 'Never copy-paste code. Practice writing code without IDE autocomplete. Zoho values deep understanding over memorized algorithms.',
        date: '2026-07-28',
        verifiedByMentorId: 'SEN001',
    },
    {
        id: 'exp_02',
        companyName: 'Amazon',
        studentName: 'Sanjay Vignesh (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'Software Development Engineer 1',
        packageOffered: '28.0 LPA',
        verdict: 'Selected',
        difficulty: 'Hard',
        rounds: [
            {
                roundName: 'Round 1: Online Coding + Work Style',
                type: 'Online Assessment',
                duration: '105 mins',
                questionsAsked: [
                    'Reorder Data in Log Files (Custom sorting)',
                    'Critical Connections in a Network (Tarjan Bridge Finding Algorithm)',
                    'Amazon Leadership Principles behavioral survey',
                ],
                experience: 'Test was hosted on HackerRank. Both coding questions passed all edge cases.',
            },
            {
                roundName: 'Round 2: Technical Interview 1',
                type: 'Technical Round 1',
                duration: '60 mins',
                questionsAsked: [
                    'Lowest Common Ancestor in Binary Tree & Binary Search Tree',
                    'Design an In-Memory File System with directory navigation',
                ],
                experience: 'The interviewer tested time complexity and how I handled null pointers and cycle detection.',
            },
            {
                roundName: 'Round 3: Technical Interview 2',
                type: 'Technical Round 2',
                duration: '60 mins',
                questionsAsked: [
                    'LRU Cache implementation with O(1) get and put',
                    'Word Ladder shortest transformation sequence (BFS)',
                ],
                experience: 'Used a doubly linked list + hash map for LRU cache. Dry ran with custom test cases on Amazon Chime.',
            },
            {
                roundName: 'Round 4: Bar Raiser & Leadership Principles',
                type: 'Managerial',
                duration: '60 mins',
                questionsAsked: [
                    'Tell me about a time you took a calculated risk and failed.',
                    'How do you handle disagreement with your teammate on tech stack?',
                    'Design a high throughput notification service for Amazon Orders.',
                ],
                experience: 'Answered using STAR method (Situation, Task, Action, Result). Focused on Customer Obsession and Bias for Action.',
            },
        ],
        generalTips: 'Prepare 2 real stories for each of Amazon 16 Leadership Principles. Practice writing clean code on Google Docs without syntax highlighting.',
        date: '2026-08-05',
        verifiedByMentorId: 'SEN007',
    },
    {
        id: 'exp_03',
        companyName: 'TCS (Tata Consultancy Services)',
        studentName: 'Karthik Raja S (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'System Engineer - Digital Cadre',
        packageOffered: '7.5 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        rounds: [
            {
                roundName: 'Round 1: TCS NQT Cognitive + Advanced Coding',
                type: 'Online Assessment',
                duration: '180 mins',
                questionsAsked: [
                    'Numerical Ability: Time & Distance, Compound Interest, Mixtures',
                    'Reasoning: Statements and Assumptions, Data Sufficiency',
                    'Coding 1 (Easy): Count distinct elements in every window of size k',
                    'Coding 2 (Medium): Minimum jumps to reach end of array with O(N) Greedy strategy',
                ],
                experience: 'Sectional time limits were strict. Completing both coding problems guaranteed qualification for the Digital interview.',
            },
            {
                roundName: 'Round 2: Technical Interview',
                type: 'Technical Round 1',
                duration: '45 mins',
                questionsAsked: [
                    'Difference between SQL vs NoSQL with real use case',
                    'Explain multithreading in Java and lifecycle of thread',
                    'Write code to find loop in a singly linked list (Floyd Cycle Detection)',
                ],
                experience: 'The panelist asked detailed questions about my Final Year project deployment and AWS EC2 hosting.',
            },
            {
                roundName: 'Round 3: Managerial & HR Round',
                type: 'HR',
                duration: '30 mins',
                questionsAsked: [
                    'Are you comfortable working in night shifts / client time zones?',
                    'How do you stay updated with emerging tech stack?',
                    'Willingness to relocate to Pune, Bangalore, or Trivandrum.',
                ],
                experience: 'Positive, confident attitude and clear relocation agreement is essential.',
            },
        ],
        generalTips: 'Speed in quantitative aptitude is critical. For Digital upgrade, make sure your advanced coding logic has zero compilation errors.',
        date: '2026-08-10',
        verifiedByMentorId: 'SEN003',
    },
    {
        id: 'exp_04',
        companyName: 'Kaar Technologies',
        studentName: 'Arun Kumar V (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'Associate Software Engineer - SAP Trainee',
        packageOffered: '6.0 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        rounds: [
            {
                roundName: 'Round 1: Aptitude + Java MCQs',
                type: 'Online Assessment',
                duration: '60 mins',
                questionsAsked: [
                    'Speed math, logical seating arrangement, blood relations',
                    'Core Java: Output prediction for method overloading with null arguments',
                    'SQL: Find second highest salary using subquery and LIMIT offset',
                ],
                experience: 'Speed and accuracy mattered. Practicing with our Question Bank Aptitude module helped clear the cutoff.',
            },
            {
                roundName: 'Round 2: Group Discussion (GD)',
                type: 'GD',
                duration: '25 mins',
                questionsAsked: [
                    'Topic: "Impact of Artificial Intelligence on Enterprise Resource Planning (ERP)"',
                ],
                experience: 'I initiated the discussion with a clear definition, supported peer points politely, and summarized at the 20-minute mark.',
            },
            {
                roundName: 'Round 3: Technical Interview',
                type: 'Technical Round 1',
                duration: '50 mins',
                questionsAsked: [
                    '4 OOP pillars with code examples on paper',
                    'Database Normalization (1NF, 2NF, 3NF, BCNF) with a college library table example',
                    'String pool vs Heap memory in Java',
                ],
                experience: 'The interviewer appreciated that I drew ER diagrams before writing database queries.',
            },
            {
                roundName: 'Round 4: Management Interview',
                type: 'Managerial',
                duration: '35 mins',
                questionsAsked: [
                    'Why Kaar Technologies over mass IT companies?',
                    'What do you know about SAP S/4HANA digital transformation?',
                    'Willingness to travel for overseas client implementations.',
                ],
                experience: 'Researched Kaar recent client projects in Middle East beforehand which made a great impression.',
            },
        ],
        generalTips: 'Prepare Core Java and SQL rigorously. During GD, never shout or interrupt; focus on structured content and courteous facilitation.',
        date: '2026-08-14',
        verifiedByMentorId: 'SEN002',
    },
    {
        id: 'exp_05',
        companyName: 'Cognizant (CTS)',
        studentName: 'Sowmya N (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'GenC Next - Full Stack Specialist',
        packageOffered: '6.75 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        rounds: [
            {
                roundName: 'Round 1: Communication Assessment',
                type: 'Online Assessment',
                duration: '45 mins',
                questionsAsked: [
                    'Reading sentences aloud, listening to audio passages and answering MCQs',
                    'Spontaneous 1-minute speech on "Remote Learning vs Classroom Education"',
                ],
                experience: 'Automated AI scoring for pronunciation and fluency. Good microphone in quiet room is compulsory.',
            },
            {
                roundName: 'Round 2: GenC Next Advanced Coding',
                type: 'Online Assessment',
                duration: '90 mins',
                questionsAsked: [
                    'Find contiguous subarray with maximum product (Kadane variation with negative values)',
                    'Check if a directed graph contains a cycle using DFS coloring',
                ],
                experience: 'Both problems solved in Java with optimal O(N) and O(V+E) complexities.',
            },
            {
                roundName: 'Round 3: Technical & HR Composite',
                type: 'Technical Round 1',
                duration: '40 mins',
                questionsAsked: [
                    'Explain REST API status codes (200, 201, 400, 401, 404, 500)',
                    'Difference between process and thread in Operating Systems',
                    'What role would you like in Cognizant Digital Business?',
                ],
                experience: 'Smooth interview. Highlighted full-stack project experience and readiness to learn Cloud.',
            },
        ],
        generalTips: 'GenC Next requires strong algorithmic fundamentals. Practice Kadane, sliding window, and graph algorithms.',
        date: '2026-08-18',
        verifiedByMentorId: 'SEN005',
    },
    {
        id: 'exp_06',
        companyName: 'Accenture',
        studentName: 'Manikandan P (Senior Mentor)',
        batch: '2026 Passout',
        jobRole: 'Advanced Associate Software Engineer',
        packageOffered: '6.5 LPA',
        verdict: 'Selected',
        difficulty: 'Moderate',
        rounds: [
            {
                roundName: 'Round 1: Cognitive, Technical & Pseudocode',
                type: 'Online Assessment',
                duration: '90 mins',
                questionsAsked: [
                    'Pseudocode tracing involving bitwise XOR, AND, right-shift operations',
                    'Common applications: MS Word/Excel shortcut keys and cloud computing basics',
                    'Abstract reasoning and flowchart logic',
                ],
                experience: 'Elimination round. High accuracy in pseudocode is critical to unlock the coding round.',
            },
            {
                roundName: 'Round 2: Hands-On Coding',
                type: 'Online Assessment',
                duration: '45 mins',
                questionsAsked: [
                    'Question 1: Replace every element with least greater element on its right',
                    'Question 2: String encryption algorithm with character shifts',
                ],
                experience: 'Passed all public and hidden test cases in C++ within 30 minutes.',
            },
            {
                roundName: 'Round 3: Learning Agility & Interview',
                type: 'HR',
                duration: '30 mins',
                questionsAsked: [
                    'Tell me about an instance when you had to learn a completely new technology in a short timeframe.',
                    'Describe a situation where you resolved a team conflict during your project.',
                    'Are you comfortable with cross-domain training (e.g. Salesforce / Cloud / Data)?',
                ],
                experience: 'Interviewer focused on communication, adaptability, and college leadership activities.',
            },
        ],
        generalTips: 'Practice pseudocode tracing fast. For Advanced ASE role, solving both coding questions cleanly is required.',
        date: '2026-08-22',
        verifiedByMentorId: 'SEN006',
    },
];
// Initial Round Resources
const INITIAL_RESOURCES = [
    {
        id: 'res_01',
        roundType: 'Aptitude',
        title: 'NEC Placement Aptitude Master Formula Cheatsheet',
        description: 'Comprehensive 1-page formula sheet covering Time & Work, Speed Distance, Permutation, and Probability.',
        resourceType: 'Cheatsheet',
        link: '#formula-sheet',
        uploadedBySeniorId: 'SEN003',
        uploadedBySeniorName: 'Karthik Raja S',
        downloadCount: 342,
        createdAt: '2026-08-15T10:00:00Z',
    },
    {
        id: 'res_02',
        roundType: 'Coding',
        title: 'Top 75 DSA Patterns for Campus Placements',
        description: 'Curated list of Two Pointers, Sliding Window, Fast-Slow Pointers, and Tree BFS patterns frequently asked in Tamil Nadu college drives.',
        resourceType: 'PDF Guide',
        link: '#dsa-patterns',
        uploadedBySeniorId: 'SEN004',
        uploadedBySeniorName: 'Deepa Rajan',
        downloadCount: 512,
        createdAt: '2026-08-16T10:00:00Z',
    },
    {
        id: 'res_03',
        roundType: 'Technical',
        title: 'Core Subjects Quick Revision Handbook (OS, DBMS, CN)',
        description: 'Concise summary of ACID properties, Normalization, Paging, Deadlocks, TCP vs UDP for technical interview rounds.',
        resourceType: 'Notes',
        link: '#core-handbook',
        uploadedBySeniorId: 'SEN001',
        uploadedBySeniorName: 'Priya Muthuraman',
        downloadCount: 420,
        createdAt: '2026-08-17T10:00:00Z',
    },
    {
        id: 'res_04',
        roundType: 'HR',
        title: 'STAR Method HR Answer Templates & Interview Etiquette',
        description: 'Structured templates for answering "Tell me about yourself", "Greatest weakness", and situational conflict questions.',
        resourceType: 'PDF Guide',
        link: '#hr-guide',
        uploadedBySeniorId: 'SEN007',
        uploadedBySeniorName: 'Sanjay Vignesh',
        downloadCount: 290,
        createdAt: '2026-08-18T10:00:00Z',
    },
    {
        id: 'res_05',
        roundType: 'GD',
        title: 'Group Discussion Master Kit: 50 Trending Topics & Speaking Phrases',
        description: 'Frameworks to open, summarize, and navigate heated GD arguments constructively during company elimination rounds.',
        resourceType: 'Cheatsheet',
        link: '#gd-kit',
        uploadedBySeniorId: 'SEN003',
        uploadedBySeniorName: 'Karthik Raja S',
        downloadCount: 215,
        createdAt: '2026-08-19T10:00:00Z',
    },
];
// Initial Question Bank
const INITIAL_QUESTIONS = [
    {
        id: 'q_01',
        category: 'Aptitude',
        subCategory: 'Quantitative - Time and Work',
        companyTag: 'TCS / Cognizant',
        title: 'A can do a work in 12 days and B can do it in 18 days. If they work together for 4 days, how much fraction of work is left?',
        difficulty: 'Easy',
        options: ['5/9', '4/9', '1/3', '2/9'],
        correctOptionIndex: 1,
        solutionExplanation: "A's 1-day work = 1/12, B's 1-day work = 1/18. Together in 1 day = (1/12 + 1/18) = 5/36. In 4 days = 4 * (5/36) = 20/36 = 5/9 work is completed. Remaining work = 1 - 5/9 = 4/9.",
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_02',
        category: 'Aptitude',
        subCategory: 'Logical Reasoning - Blood Relations',
        companyTag: 'Zoho / Infosys',
        title: 'Pointing to a photograph, a woman says: "He is the only son of the wife of my husband." How is the boy related to the woman?',
        difficulty: 'Easy',
        options: ['Brother', 'Son', 'Nephew', 'Husband'],
        correctOptionIndex: 1,
        solutionExplanation: '"The wife of my husband" is the woman herself. Therefore, the boy is her only son.',
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_03',
        category: 'Technical',
        subCategory: 'DBMS & SQL',
        companyTag: 'Zoho / Kaar Tech',
        title: 'What is the main difference between DELETE and TRUNCATE commands in SQL?',
        difficulty: 'Medium',
        options: [
            'DELETE is DDL while TRUNCATE is DML',
            'TRUNCATE removes all rows without logging individual row deletions and cannot be rolled back in standard transactions, whereas DELETE is a DML statement and can be filtered with WHERE',
            'TRUNCATE drops the table schema entirely',
            'There is no functional difference',
        ],
        correctOptionIndex: 1,
        solutionExplanation: 'TRUNCATE is a DDL command that deallocates data pages and resets identity columns. It is faster than DELETE which deletes row by row maintaining transaction logs.',
        addedBySeniorId: 'SEN001',
    },
    {
        id: 'q_04',
        category: 'Technical',
        subCategory: 'Operating Systems',
        companyTag: 'Bosch / Amazon',
        title: 'Which of the following conditions is NOT one of Coffman four necessary conditions for deadlock?',
        difficulty: 'Medium',
        options: ['Mutual Exclusion', 'Hold and Wait', 'Preemption Allowed', 'Circular Wait'],
        correctOptionIndex: 2,
        solutionExplanation: 'The four Coffman conditions are: 1. Mutual Exclusion, 2. Hold and Wait, 3. No Preemption (resources cannot be forcibly taken away), 4. Circular Wait. Allowing preemption prevents deadlocks.',
        addedBySeniorId: 'SEN007',
    },
    {
        id: 'q_05',
        category: 'Coding',
        subCategory: 'Arrays & Two Pointers',
        companyTag: 'Zoho / Amazon',
        title: 'Two Sum Problem - Find indices of two numbers that add up to target',
        difficulty: 'Easy',
        solutionExplanation: 'Use a Hash Map to store elements and their indices in O(N) time and O(N) space, checking if `target - current` exists.',
        codingProblemDetails: {
            description: 'Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`. You may assume each input has exactly one solution.',
            sampleInput: 'nums = [2,7,11,15], target = 9',
            sampleOutput: '[0,1]',
            starterCode: {
                javascript: `function twoSum(nums, target) {\n  const map = new Map();\n  for (let i = 0; i < nums.length; i++) {\n    const complement = target - nums[i];\n    if (map.has(complement)) {\n      return [map.get(complement), i];\n    }\n    map.set(nums[i], i);\n  }\n  return [];\n}`,
                python: `def twoSum(nums, target):\n    seen = {}\n    for i, num in enumerate(nums):\n        comp = target - num\n        if comp in seen:\n            return [seen[comp], i]\n        seen[num] = i\n    return []`,
                java: `class Solution {\n    public int[] twoSum(int[] nums, int target) {\n        Map<Integer, Integer> map = new HashMap<>();\n        for (int i = 0; i < nums.length; i++) {\n            int comp = target - nums[i];\n            if (map.containsKey(comp)) return new int[]{map.get(comp), i};\n            map.put(nums[i], i);\n        }\n        return new int[]{};\n    }\n}`,
            },
            testCases: [
                { input: '[2,7,11,15], 9', output: '[0,1]' },
                { input: '[3,2,4], 6', output: '[1,2]' },
            ],
        },
        addedBySeniorId: 'SEN004',
    },
    {
        id: 'q_06',
        category: 'HR',
        subCategory: 'Behavioral',
        companyTag: 'All Companies',
        title: 'Why should we hire you over other qualified candidates from National Engineering College?',
        difficulty: 'Easy',
        options: [
            'Because I have the highest CGPA in my department.',
            'Because I need a job desperately before graduation.',
            'By aligning my technical foundations, practical project implementations, continuous problem-solving practice, and cultural adaptability to company values.',
            'I do not know about other candidates so I cannot answer.',
        ],
        correctOptionIndex: 2,
        solutionExplanation: 'The ideal answer focuses on your unique combination of skills, quick learning adaptability, specific alignment with the team role, and demonstrated problem-solving initiatives.',
        addedBySeniorId: 'SEN007',
    },
    {
        id: 'q_07',
        category: 'Coding',
        subCategory: 'Stacks & Strings',
        companyTag: 'Zoho / TCS / Amazon',
        title: 'Valid Parentheses: Determine if the input brackets string has valid closure',
        difficulty: 'Easy',
        solutionExplanation: 'Use a Stack. Push opening brackets `(`, `{`, `[`. When a closing bracket is found, check if the stack top matches. Return true if stack is empty at the end.',
        codingProblemDetails: {
            description: 'Given a string `s` containing just the characters `(`, `)`, `{`, `}`, `[` and `]`, determine if the input string is valid.',
            sampleInput: 's = "()[]{}"',
            sampleOutput: 'true',
            starterCode: {
                javascript: `function isValid(s) {\n  const stack = [];\n  const map = { ')': '(', '}': '{', ']': '[' };\n  for (let c of s) {\n    if (map[c]) {\n      if (stack.pop() !== map[c]) return false;\n    } else {\n      stack.push(c);\n    }\n  }\n  return stack.length === 0;\n}`,
                python: `def isValid(s):\n    stack = []\n    mapping = {")": "(", "}": "{", "]": "["}\n    for char in s:\n        if char in mapping:\n            top = stack.pop() if stack else '#'\n            if mapping[char] != top: return False\n        else:\n            stack.append(char)\n    return not stack`,
                java: `class Solution {\n    public boolean isValid(String s) {\n        Stack<Character> stack = new Stack<>();\n        for (char c : s.toCharArray()) {\n            if (c == '(') stack.push(')');\n            else if (c == '{') stack.push('}');\n            else if (c == '[') stack.push(']');\n            else if (stack.isEmpty() || stack.pop() != c) return false;\n        }\n        return stack.isEmpty();\n    }\n}`,
            },
            testCases: [
                { input: '"()[]{}"', output: 'true' },
                { input: '"(]"', output: 'false' },
            ],
        },
        addedBySeniorId: 'SEN001',
    },
    {
        id: 'q_08',
        category: 'Coding',
        subCategory: 'Linked Lists',
        companyTag: 'Kaar Tech / Cognizant',
        title: 'Reverse a Singly Linked List in O(N) time and O(1) space',
        difficulty: 'Easy',
        solutionExplanation: 'Maintain three pointers: prev, current, next. In a loop, store `next = curr.next`, set `curr.next = prev`, advance `prev = curr` and `curr = next`.',
        codingProblemDetails: {
            description: 'Given the head of a singly linked list, reverse the list, and return the reversed list.',
            sampleInput: 'head = [1,2,3,4,5]',
            sampleOutput: '[5,4,3,2,1]',
            starterCode: {
                javascript: `function reverseList(head) {\n  let prev = null, curr = head;\n  while (curr) {\n    let next = curr.next;\n    curr.next = prev;\n    prev = curr;\n    curr = next;\n  }\n  return prev;\n}`,
                python: `def reverseList(head):\n    prev = None\n    curr = head\n    while curr:\n        nxt = curr.next\n        curr.next = prev\n        prev = curr\n        curr = nxt\n    return prev`,
                java: `class Solution {\n    public ListNode reverseList(ListNode head) {\n        ListNode prev = null, curr = head;\n        while (curr != null) {\n            ListNode next = curr.next;\n            curr.next = prev;\n            prev = curr;\n            curr = next;\n        }\n        return prev;\n    }\n}`,
            },
            testCases: [
                { input: '[1,2,3,4,5]', output: '[5,4,3,2,1]' },
            ],
        },
        addedBySeniorId: 'SEN004',
    },
    {
        id: 'q_09',
        category: 'Technical',
        subCategory: 'DBMS & SQL',
        companyTag: 'Zoho / TCS / Kaar Tech',
        title: 'How do you find the Nth highest salary of an employee in SQL?',
        difficulty: 'Medium',
        options: [
            'SELECT salary FROM Employee ORDER BY salary DESC LIMIT 1 OFFSET N;',
            'SELECT DISTINCT salary FROM Employee ORDER BY salary DESC LIMIT 1 OFFSET N-1;',
            'SELECT MAX(salary) FROM Employee WHERE salary < N;',
            'SELECT TOP N salary FROM Employee GROUP BY salary;',
        ],
        correctOptionIndex: 1,
        solutionExplanation: 'To find Nth highest, use `SELECT DISTINCT salary FROM Employee ORDER BY salary DESC LIMIT 1 OFFSET N-1;` or dense_rank() OVER (ORDER BY salary DESC).',
        addedBySeniorId: 'SEN002',
    },
    {
        id: 'q_10',
        category: 'Technical',
        subCategory: 'DBMS & SQL',
        companyTag: 'Cognizant / Accenture',
        title: 'What is the fundamental difference between INNER JOIN and LEFT OUTER JOIN?',
        difficulty: 'Easy',
        options: [
            'INNER JOIN returns matching rows from both tables; LEFT JOIN returns all rows from left table plus matching rows from right (with NULL for non-matches).',
            'LEFT JOIN is faster because it does not check table constraints.',
            'INNER JOIN deletes unmatched records from disk.',
            'There is no difference in modern database engines.',
        ],
        correctOptionIndex: 0,
        solutionExplanation: 'INNER JOIN returns only records that have matching keys in both tables. LEFT OUTER JOIN retains all records from the left table regardless of whether there is a match in the right table.',
        addedBySeniorId: 'SEN002',
    },
    {
        id: 'q_11',
        category: 'Technical',
        subCategory: 'Operating Systems',
        companyTag: 'Bosch / Zoho / Amazon',
        title: 'What is the primary difference between a Process and a Thread?',
        difficulty: 'Medium',
        options: [
            'A process has its own independent address space & resources; threads of a process share the same memory space, code, and file descriptors.',
            'Processes run on hardware while threads run inside the browser only.',
            'A thread cannot be paused or resumed by the OS scheduler.',
            'Processes have no stack while threads have multiple stacks.',
        ],
        correctOptionIndex: 0,
        solutionExplanation: 'A process is an executing instance of a program with isolated memory. A thread is the smallest unit of execution within a process, sharing memory space with sibling threads for low-overhead context switching.',
        addedBySeniorId: 'SEN007',
    },
    {
        id: 'q_12',
        category: 'Technical',
        subCategory: 'Computer Networks',
        companyTag: 'TCS / Accenture / Zoho',
        title: 'Why is TCP considered a connection-oriented protocol while UDP is connectionless?',
        difficulty: 'Easy',
        options: [
            'TCP establishes a 3-way handshake (SYN, SYN-ACK, ACK) ensuring reliable ordered packet delivery with retransmissions; UDP sends datagrams without handshake or guarantee.',
            'TCP can only be used on fiber-optic cables.',
            'UDP encrypts all traffic by default while TCP does not.',
            'TCP does not support IP addresses.',
        ],
        correctOptionIndex: 0,
        solutionExplanation: 'TCP guarantees packet ordering, flow control, and error correction via sequence numbers and 3-way handshake. UDP trades reliability for low latency, used in video streaming and DNS.',
        addedBySeniorId: 'SEN006',
    },
    {
        id: 'q_13',
        category: 'Technical',
        subCategory: 'Object Oriented Programming',
        companyTag: 'Kaar Tech / Zoho',
        title: 'What is the Diamond Problem in Object-Oriented Programming and how does Java address it?',
        difficulty: 'Medium',
        options: [
            'It arises when a class inherits from two classes that both inherit from a common base class; Java prevents multiple inheritance of classes and uses Interfaces with explicit default methods.',
            'It occurs when too many objects are allocated in heap memory.',
            'It happens when recursion has no base condition.',
            'It is an encryption algorithm flaw.',
        ],
        correctOptionIndex: 0,
        solutionExplanation: 'The diamond problem creates ambiguity when two parent classes provide implementations of the same superclass method. Java disallows multiple class inheritance, allowing only interfaces.',
        addedBySeniorId: 'SEN001',
    },
    {
        id: 'q_14',
        category: 'Coding',
        subCategory: 'Arrays & Dynamic Programming',
        companyTag: 'Amazon / Zoho / Cognizant',
        title: "Maximum Subarray Sum: Find contiguous subarray with the largest sum (Kadane's Algorithm)",
        difficulty: 'Medium',
        solutionExplanation: "Kadane's Algorithm maintains `maxSoFar` and `currentMax`. For each number, `currentMax = max(num, currentMax + num)` and `maxSoFar = max(maxSoFar, currentMax)`. Runs in O(N) time and O(1) space.",
        codingProblemDetails: {
            description: 'Given an integer array `nums`, find the subarray with the largest sum, and return its sum.',
            sampleInput: 'nums = [-2,1,-3,4,-1,2,1,-5,4]',
            sampleOutput: '6 (subarray [4,-1,2,1])',
            starterCode: {
                javascript: `function maxSubArray(nums) {\n  let currentMax = nums[0];\n  let maxSoFar = nums[0];\n  for (let i = 1; i < nums.length; i++) {\n    currentMax = Math.max(nums[i], currentMax + nums[i]);\n    maxSoFar = Math.max(maxSoFar, currentMax);\n  }\n  return maxSoFar;\n}`,
                python: `def maxSubArray(nums):\n    cur_max = max_so_far = nums[0]\n    for x in nums[1:]:\n        cur_max = max(x, cur_max + x)\n        max_so_far = max(max_so_far, cur_max)\n    return max_so_far`,
                java: `class Solution {\n    public int maxSubArray(int[] nums) {\n        int curMax = nums[0], maxSoFar = nums[0];\n        for (int i = 1; i < nums.length; i++) {\n            curMax = Math.max(nums[i], curMax + nums[i]);\n            maxSoFar = Math.max(maxSoFar, curMax);\n        }\n        return maxSoFar;\n    }\n}`,
            },
            testCases: [
                { input: '[-2,1,-3,4,-1,2,1,-5,4]', output: '6' },
                { input: '[1]', output: '1' },
            ],
        },
        addedBySeniorId: 'SEN005',
    },
    {
        id: 'q_15',
        category: 'Aptitude',
        subCategory: 'Quantitative - Speed, Distance & Time',
        companyTag: 'TCS / Accenture',
        title: 'A train 150 meters long crosses a telegraph post in 9 seconds. What is the speed of the train in km/hr?',
        difficulty: 'Easy',
        options: ['50 km/hr', '60 km/hr', '72 km/hr', '54 km/hr'],
        correctOptionIndex: 1,
        solutionExplanation: 'Speed in m/s = Distance / Time = 150 / 9 = 50/3 m/s. To convert to km/hr, multiply by 18/5: (50/3) * (18/5) = 10 * 6 = 60 km/hr.',
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_16',
        category: 'Aptitude',
        subCategory: 'Quantitative - Permutations & Combinations',
        companyTag: 'Zoho / CTS',
        title: 'In how many different ways can the letters of the word "CAMPUS" be arranged such that vowels always stay together?',
        difficulty: 'Medium',
        options: ['120', '240', '720', '480'],
        correctOptionIndex: 1,
        solutionExplanation: 'Word CAMPUS has 6 letters: Vowels are A, U (2 vowels). Consonants are C, M, P, S (4 consonants). Treat {A, U} as 1 unit. Total units = 4 + 1 = 5 units. Arrangements of 5 units = 5! = 120. Vowels {A, U} can be arranged in 2! = 2 ways. Total = 120 * 2 = 240.',
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_17',
        category: 'Aptitude',
        subCategory: 'Quantitative - Profit and Loss',
        companyTag: 'TCS / Kaar Tech',
        title: 'If the cost price of an item is 95% of its selling price, what is the profit percentage?',
        difficulty: 'Easy',
        options: ['5.26%', '5.00%', '4.75%', '6.12%'],
        correctOptionIndex: 0,
        solutionExplanation: 'Let Selling Price (SP) = 100. Cost Price (CP) = 95. Profit = SP - CP = 100 - 95 = 5. Profit % = (Profit / CP) * 100 = (5 / 95) * 100 = 100 / 19 ≈ 5.26%.',
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_18',
        category: 'Aptitude',
        subCategory: 'Logical Reasoning - Syllogisms',
        companyTag: 'Cognizant / Infosys',
        title: 'Statements: 1. All engineers are innovators. 2. Some innovators are leaders. Which conclusion logically follows?',
        difficulty: 'Easy',
        options: [
            'Some leaders are innovators.',
            'All leaders are engineers.',
            'No engineer is a leader.',
            'All innovators are engineers.',
        ],
        correctOptionIndex: 0,
        solutionExplanation: 'From statement 2 "Some innovators are leaders", the converse "Some leaders are innovators" is an immediate valid deduction.',
        addedBySeniorId: 'SEN003',
    },
    {
        id: 'q_19',
        category: 'HR',
        subCategory: 'Behavioral & Leadership',
        companyTag: 'Amazon / Zoho / Kaar Tech',
        title: 'Tell me about a time you faced a difficult technical bug under a tight project deadline.',
        difficulty: 'Medium',
        options: [
            'I blamed the backend teammate for not providing proper documentation.',
            'Using the STAR method: Described the critical race condition bug, isolated it with logging, coordinated a patch before midnight, and added automated unit tests.',
            'I asked my professor to extend the deadline by two weeks.',
            'I skipped that module and submitted an incomplete project.',
        ],
        correctOptionIndex: 1,
        solutionExplanation: 'Top placement recruiters look for accountability, systematic debugging methodology, team collaboration under pressure, and preventive measures like automated testing.',
        addedBySeniorId: 'SEN007',
    },
];
// Initial Daily Challenges
const INITIAL_CHALLENGES = [
    {
        id: 'ch_today',
        date: new Date().toISOString().split('T')[0],
        title: 'Daily Challenge: Palindrome Permutation Checker',
        type: 'Coding',
        description: 'Given a string `s`, determine if a permutation of the string could form a palindrome. E.g. "carerac" -> true because "racecar" is a valid palindrome.',
        options: [
            'Check if length of string is even only',
            'Count character frequencies: At most one character can have an odd count',
            'Reverse the string and check if it equals original',
            'Sort the string and compare adjacent elements',
        ],
        correctAnswer: 1,
        explanation: 'For a string to form a palindrome by permuting letters, at most ONE character can appear an odd number of times (which would sit in the center if length is odd). All other characters must have even frequencies.',
        xpReward: 50,
    },
    {
        id: 'ch_prev',
        date: '2026-09-27',
        title: 'Speed Aptitude: Ratio and Mixtures',
        type: 'Aptitude',
        description: 'In a mixture of 60 liters, the ratio of milk and water is 2:1. How much water must be added to make the ratio 1:2?',
        options: ['40 liters', '60 liters', '50 liters', '30 liters'],
        correctAnswer: 1,
        explanation: 'Initial milk = (2/3)*60 = 40L, water = 20L. In the new mixture, milk:water = 1:2. Since milk remains 40L, water must be 40 * 2 = 80L. Therefore, water to be added = 80 - 20 = 60 liters.',
        xpReward: 40,
    },
];
// Initial Mock Interview Sessions
const INITIAL_MOCK_INTERVIEWS = [
    {
        id: 'mock_01',
        studentId: 'usr_prefinal_01',
        studentName: 'Arun Kumar M',
        mentorId: 'usr_senior_07',
        mentorName: 'Sanjay Vignesh (Amazon SDE)',
        roleOrCompany: 'Amazon / Product Companies Mock',
        scheduledDate: '2026-10-02',
        scheduledTime: '06:00 PM IST',
        type: 'Technical (DSA & Core)',
        status: 'Scheduled',
        meetingLink: 'https://meet.google.com/nec-mock-sde1',
    },
    {
        id: 'mock_02',
        studentId: 'usr_junior_01',
        studentName: 'Neha S',
        mentorId: 'usr_senior_01',
        mentorName: 'Priya Muthuraman (Zoho MTS)',
        roleOrCompany: 'Zoho Corporation Mock Round 2',
        scheduledDate: '2026-10-04',
        scheduledTime: '07:30 PM IST',
        type: 'Company-Specific Mock',
        status: 'Scheduled',
        meetingLink: 'https://meet.google.com/nec-zoho-prep',
    },
];
// Initial Mock GD Sessions
const INITIAL_MOCK_GDS = [
    {
        id: 'gd_01',
        topic: 'Will Generative AI Eliminate Entry-Level Software Engineering Jobs in India?',
        category: 'Tech & AI Trends',
        scheduledDate: '2026-10-03',
        scheduledTime: '05:00 PM IST',
        mentorId: 'usr_senior_03',
        mentorName: 'Karthik Raja S (TCS Digital)',
        maxParticipants: 8,
        participants: [
            {
                studentId: 'usr_prefinal_01',
                studentName: 'Arun Kumar M',
            },
        ],
        status: 'Upcoming',
        meetingLink: 'https://meet.google.com/nec-gd-round1',
    },
    {
        id: 'gd_02',
        topic: 'Work From Office vs Hybrid Work Model for Fresh Campus Recruits',
        category: 'Current Affairs',
        scheduledDate: '2026-10-05',
        scheduledTime: '04:30 PM IST',
        mentorId: 'usr_senior_07',
        mentorName: 'Sanjay Vignesh',
        maxParticipants: 8,
        participants: [],
        status: 'Upcoming',
        meetingLink: 'https://meet.google.com/nec-gd-hybrid',
    },
];
// Initial Peer Posts
const INITIAL_PEER_POSTS = [
    {
        id: 'post_01',
        authorId: 'usr_prefinal_01',
        authorName: 'Arun Kumar M',
        authorRole: 'pre_final',
        title: 'What are the top 5 questions frequently asked in Kaar Technologies GD round?',
        content: 'Hey folks! Our department has Kaar Tech campus drive scheduled next month. Can seniors who cleared Kaar tell us what criteria their evaluators look for in the GD round?',
        tags: ['Kaar Technologies', 'Mock GD', 'Campus Drive'],
        upvotes: 8,
        replies: [
            {
                id: 'rep_01',
                authorName: 'Priya Muthuraman (Senior Mentor)',
                authorRole: 'senior',
                text: 'Kaar Technologies focuses heavily on balanced participation. Do not cut in aggressively; instead, summarize points and invite silent participants to speak. That scores high marks!',
                createdAt: '2026-08-25T11:00:00Z',
            },
        ],
        createdAt: '2026-08-25T10:00:00Z',
    },
    {
        id: 'post_02',
        authorId: 'usr_junior_01',
        authorName: 'Neha S',
        authorRole: 'junior',
        title: 'How should a 2nd year student start practicing Data Structures for Zoho?',
        content: 'Currently in 3rd semester CSE. I want to build a solid foundation before 3rd year. Which programming language is best for Zoho rounds?',
        tags: ['Zoho', '2nd Year Guidance', 'C Programming'],
        upvotes: 12,
        replies: [
            {
                id: 'rep_02',
                authorName: 'Deepa Rajan (Question Bank Lead)',
                authorRole: 'senior',
                text: 'Start with pure C or Java without using Collections. Practice 2D arrays, recursion, and pattern questions in our Practice Studio module!',
                createdAt: '2026-08-26T14:30:00Z',
            },
        ],
        createdAt: '2026-08-26T12:00:00Z',
    },
];
// Default User Settings
export const DEFAULT_USER_SETTINGS = {
    mode: 'light',
    theme: 'blue',
    themeColor: '#1e40af',
    fontSize: 'medium',
    background: 'college',
    language: 'en',
    notifications: {
        email: true,
        mockInterviews: true,
        mockGD: true,
        mentorship: true,
        practice: true,
        upcomingSessions: true,
    },
    accessibility: {
        highContrast: false,
        reducedAnimations: false,
        comfortableReading: false,
    },
    privacy: {
        profileVisibility: 'college_only',
        activityVisibility: true,
        mentorshipVisibility: true,
    },
};
// STORAGE CLASS
class StorageService {
    isClient = typeof window !== 'undefined';
    constructor() {
        this.initializeData();
    }
    initializeData() {
        if (!this.isClient)
            return;
        if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
            localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.USER_PASSWORDS)) {
            localStorage.setItem(STORAGE_KEYS.USER_PASSWORDS, JSON.stringify(INITIAL_PASSWORDS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.COMPANIES)) {
            localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify(INITIAL_COMPANIES));
        }
        if (!localStorage.getItem(STORAGE_KEYS.PLAYBOOKS)) {
            localStorage.setItem(STORAGE_KEYS.PLAYBOOKS, JSON.stringify(INITIAL_PLAYBOOKS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.EXPERIENCES)) {
            localStorage.setItem(STORAGE_KEYS.EXPERIENCES, JSON.stringify(INITIAL_EXPERIENCES));
        }
        if (!localStorage.getItem(STORAGE_KEYS.RESOURCES)) {
            localStorage.setItem(STORAGE_KEYS.RESOURCES, JSON.stringify(INITIAL_RESOURCES));
        }
        if (!localStorage.getItem(STORAGE_KEYS.QUESTIONS)) {
            localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(INITIAL_QUESTIONS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.CHALLENGES)) {
            localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(INITIAL_CHALLENGES));
        }
        if (!localStorage.getItem(STORAGE_KEYS.MOCK_INTERVIEWS)) {
            localStorage.setItem(STORAGE_KEYS.MOCK_INTERVIEWS, JSON.stringify(INITIAL_MOCK_INTERVIEWS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.MOCK_GDS)) {
            localStorage.setItem(STORAGE_KEYS.MOCK_GDS, JSON.stringify(INITIAL_MOCK_GDS));
        }
        if (!localStorage.getItem(STORAGE_KEYS.PEER_POSTS)) {
            localStorage.setItem(STORAGE_KEYS.PEER_POSTS, JSON.stringify(INITIAL_PEER_POSTS));
        }
    }
    // USERS & AUTH
    getUsers() {
        if (!this.isClient)
            return INITIAL_USERS;
        const raw = localStorage.getItem(STORAGE_KEYS.USERS);
        return raw ? JSON.parse(raw) : INITIAL_USERS;
    }
    saveUsers(users) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }
    getUserById(id) {
        return this.getUsers().find((u) => u.id === id);
    }
    getUserByEmail(email) {
        const cleaned = email.trim().toLowerCase();
        return this.getUsers().find((u) => u.email.toLowerCase() === cleaned ||
            u.email.toLowerCase() === `${cleaned}@nec.edu.in` ||
            u.email.split('@')[0].toLowerCase() === cleaned ||
            (u.seniorId && u.seniorId.toLowerCase() === cleaned) ||
            (u.adminId && u.adminId.toLowerCase() === cleaned));
    }
    registerUser(userData, passwordPlain) {
        const users = this.getUsers();
        const existing = users.find((u) => u.email.toLowerCase() === userData.email.toLowerCase());
        if (existing) {
            throw new Error('An account with this email address already exists.');
        }
        const newUser = {
            ...userData,
            id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            createdAt: new Date().toISOString(),
        };
        users.push(newUser);
        this.saveUsers(users);
        // Save password
        if (this.isClient) {
            const passwords = JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_PASSWORDS) || '{}');
            passwords[newUser.email.toLowerCase()] = passwordPlain;
            if (newUser.seniorId)
                passwords[newUser.seniorId.toLowerCase()] = passwordPlain;
            if (newUser.adminId)
                passwords[newUser.adminId.toLowerCase()] = passwordPlain;
            if (newUser.alumniId)
                passwords[newUser.alumniId.toLowerCase()] = passwordPlain;
            if (newUser.visitorId)
                passwords[newUser.visitorId.toLowerCase()] = passwordPlain;
            if (newUser.placementOfficerId)
                passwords[newUser.placementOfficerId.toLowerCase()] = passwordPlain;
            localStorage.setItem(STORAGE_KEYS.USER_PASSWORDS, JSON.stringify(passwords));
        }
        // Initialize clean 0 progress for new user
        this.initializeZeroProgress(newUser.id);
        return newUser;
    }
    verifyCredentials(identifier, passwordPlain, roleHint) {
        const trimmedId = (identifier || '').trim();
        const emailLower = trimmedId.toLowerCase();
        const localPart = emailLower.includes('@') ? emailLower.split('@')[0] : emailLower;
        // Automatic role detection based on NEC roll number / email patterns:
        // Junior (25 batch): 25104009, 25104001-25104005, etc.
        // Pre-Final (24 batch): 24105001, 24104009, 24105002-24105005, etc.
        // Senior (22 batch): 22104001, 22104002-22104005, SEN...
        // Admin: admin@nec.edu.in, admin, ADM...
        let inferredRole = roleHint || 'pre_final';
        if (localPart.startsWith('25')) {
            inferredRole = 'junior';
        }
        else if (localPart.startsWith('24')) {
            inferredRole = 'pre_final';
        }
        else if (localPart.startsWith('22') || localPart.startsWith('23') || localPart.startsWith('sen')) {
            inferredRole = 'senior';
        }
        else if (localPart.includes('admin') || localPart.startsWith('adm')) {
            inferredRole = 'admin';
        }
        let user = this.getUserByEmail(trimmedId);
        // If user does not exist yet, auto-create and accept at first attempt!
        if (!user) {
            const displayName = localPart.includes('.')
                ? localPart.split('.').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ')
                : localPart.match(/^\d+$/)
                    ? `Student (${localPart})`
                    : localPart.charAt(0).toUpperCase() + localPart.slice(1);
            const gradYear = inferredRole === 'junior'
                ? 2028
                : inferredRole === 'pre_final'
                    ? 2027
                    : inferredRole === 'senior'
                        ? 2026
                        : undefined;
            const userPayload = {
                name: inferredRole === 'admin' ? 'Placement Admin' : displayName,
                email: trimmedId.includes('@') ? trimmedId : `${trimmedId}@nec.edu.in`,
                role: inferredRole,
                college: 'National Engineering College, Kovilpatti',
                department: inferredRole === 'admin' ? 'Training and Placement Cell' : 'Computer Science & Engineering',
                graduationYear: gradYear,
                degree: 'B.E.',
                skills: ['Problem Solving', 'Data Structures', 'Communication', 'Industry Practices'],
            };
            if (inferredRole === 'senior') {
                userPayload.seniorId = localPart.toUpperCase().startsWith('SEN') ? localPart.toUpperCase() : `SEN-${localPart}`;
                userPayload.specialization = 'Interview Experience';
            }
            else if (inferredRole === 'admin') {
                userPayload.adminId = 'ADM001';
            }
            user = this.registerUser(userPayload, passwordPlain || '123');
        }
        else {
            // Auto-save / update password in storage for subsequent logins
            if (this.isClient && passwordPlain) {
                const passwords = JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_PASSWORDS) || '{}');
                passwords[user.email.toLowerCase()] = passwordPlain;
                if (user.seniorId)
                    passwords[user.seniorId.toLowerCase()] = passwordPlain;
                if (user.adminId)
                    passwords[user.adminId.toLowerCase()] = passwordPlain;
                localStorage.setItem(STORAGE_KEYS.USER_PASSWORDS, JSON.stringify(passwords));
            }
        }
        return user;
    }
    savePassword(emailOrId, passwordPlain) {
        if (!this.isClient || !emailOrId || !passwordPlain)
            return;
        try {
            const passwords = JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_PASSWORDS) || '{}');
            passwords[emailOrId.trim().toLowerCase()] = passwordPlain;
            localStorage.setItem(STORAGE_KEYS.USER_PASSWORDS, JSON.stringify(passwords));
        }
        catch (e) {
            // ignore storage error
        }
    }
    getCurrentUser() {
        if (!this.isClient)
            return null;
        const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
        return raw ? JSON.parse(raw) : null;
    }
    setCurrentUser(user, remember = false) {
        if (!this.isClient)
            return;
        if (user) {
            localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
            const simulatedJwt = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${btoa(JSON.stringify({ id: user.id, role: user.role, email: user.email }))}.necsignature`;
            localStorage.setItem(STORAGE_KEYS.TOKEN, simulatedJwt);
            if (remember) {
                localStorage.setItem('necpp_remember_me', 'true');
            }
        }
        else {
            localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
            localStorage.removeItem(STORAGE_KEYS.TOKEN);
        }
    }
    updateUserProfile(userId, updates) {
        const users = this.getUsers();
        const idx = users.findIndex((u) => u.id === userId);
        if (idx === -1)
            throw new Error('User not found');
        users[idx] = { ...users[idx], ...updates };
        this.saveUsers(users);
        const currentUser = this.getCurrentUser();
        if (currentUser && currentUser.id === userId) {
            this.setCurrentUser(users[idx], true);
        }
        return users[idx];
    }
    // DYNAMIC USER PROGRESS
    // Starts strictly at 0 for every user, no fake data!
    initializeZeroProgress(userId) {
        const zeroProgress = {
            userId,
            questionsAttempted: 0,
            questionsCorrect: 0,
            codingProblemsSolved: 0,
            aptitudeSolved: 0,
            dailyChallengesCompleted: 0,
            studyStreakDays: 0,
            lastActiveDate: new Date().toISOString().split('T')[0],
            mockInterviewsAttended: 0,
            mockGDsAttended: 0,
            mentorshipSessionsAttended: 0,
            studyGoalsCompleted: 0,
            totalStudyGoals: 0,
            readinessScore: 0,
        };
        if (this.isClient) {
            localStorage.setItem(`${STORAGE_KEYS.PROGRESS}${userId}`, JSON.stringify(zeroProgress));
        }
        return zeroProgress;
    }
    getUserProgress(userId) {
        if (!this.isClient) {
            return {
                userId,
                questionsAttempted: 0,
                questionsCorrect: 0,
                codingProblemsSolved: 0,
                aptitudeSolved: 0,
                dailyChallengesCompleted: 0,
                studyStreakDays: 0,
                lastActiveDate: new Date().toISOString().split('T')[0],
                mockInterviewsAttended: 0,
                mockGDsAttended: 0,
                mentorshipSessionsAttended: 0,
                studyGoalsCompleted: 0,
                totalStudyGoals: 0,
                readinessScore: 0,
            };
        }
        const raw = localStorage.getItem(`${STORAGE_KEYS.PROGRESS}${userId}`);
        if (!raw) {
            return this.initializeZeroProgress(userId);
        }
        return JSON.parse(raw);
    }
    saveUserProgress(progress) {
        if (!this.isClient)
            return;
        // Recalculate transparent readiness score
        progress.readinessScore = this.calculateReadinessScore(progress);
        localStorage.setItem(`${STORAGE_KEYS.PROGRESS}${progress.userId}`, JSON.stringify(progress));
    }
    // Centralized Dynamic Readiness Score Calculation (0 to 100)
    calculateReadinessScore(p) {
        // Component 1: Practice Volume & Accuracy (Max 30 pts)
        const accuracy = p.questionsAttempted > 0 ? p.questionsCorrect / p.questionsAttempted : 0;
        const practiceScore = Math.min(20, p.questionsAttempted * 2) + accuracy * 10;
        // Component 2: Coding & Aptitude Balance (Max 25 pts)
        const codingScore = Math.min(15, p.codingProblemsSolved * 5);
        const aptitudeScore = Math.min(10, p.aptitudeSolved * 2);
        // Component 3: Daily Challenge & Streak Consistency (Max 15 pts)
        const streakScore = Math.min(10, p.studyStreakDays * 2) + Math.min(5, p.dailyChallengesCompleted * 1);
        // Component 4: Mock Interview & GD Participation (Max 20 pts)
        const interviewScore = Math.min(12, p.mockInterviewsAttended * 6);
        const gdScore = Math.min(8, p.mockGDsAttended * 4);
        // Component 5: Mentorship & Goal Completion (Max 10 pts)
        const mentorshipScore = Math.min(5, p.mentorshipSessionsAttended * 2.5);
        const goalRatio = p.totalStudyGoals > 0 ? (p.studyGoalsCompleted / p.totalStudyGoals) * 5 : 0;
        const total = practiceScore + codingScore + aptitudeScore + streakScore + interviewScore + gdScore + mentorshipScore + goalRatio;
        return Math.min(100, Math.round(total));
    }
    recordQuestionAttempt(userId, isCorrect, category) {
        const progress = this.getUserProgress(userId);
        progress.questionsAttempted += 1;
        if (isCorrect)
            progress.questionsCorrect += 1;
        if (category.toLowerCase().includes('coding')) {
            progress.codingProblemsSolved += 1;
        }
        else if (category.toLowerCase().includes('aptitude')) {
            progress.aptitudeSolved += 1;
        }
        // Check streak
        const today = new Date().toISOString().split('T')[0];
        if (progress.lastActiveDate !== today) {
            progress.studyStreakDays += 1;
            progress.lastActiveDate = today;
        }
        this.saveUserProgress(progress);
        this.addNotification({
            userId,
            title: 'Practice Progress Updated',
            message: `You completed a ${category} question. Total practiced: ${progress.questionsAttempted}.`,
            type: 'challenge',
            isRead: false,
        });
    }
    recordChallengeCompleted(userId, xpEarned) {
        const progress = this.getUserProgress(userId);
        progress.dailyChallengesCompleted += 1;
        progress.studyStreakDays = Math.max(1, progress.studyStreakDays + 1);
        progress.lastActiveDate = new Date().toISOString().split('T')[0];
        this.saveUserProgress(progress);
        this.addNotification({
            userId,
            title: 'Daily Challenge Completed! 🎯',
            message: `Great job! You earned ${xpEarned} XP and maintained your streak.`,
            type: 'challenge',
            isRead: false,
        });
    }
    recordMockInterviewCompleted(userId) {
        const progress = this.getUserProgress(userId);
        progress.mockInterviewsAttended += 1;
        this.saveUserProgress(progress);
    }
    recordMockGDCompleted(userId) {
        const progress = this.getUserProgress(userId);
        progress.mockGDsAttended += 1;
        this.saveUserProgress(progress);
    }
    recordMentorshipSession(userId) {
        const progress = this.getUserProgress(userId);
        progress.mentorshipSessionsAttended += 1;
        this.saveUserProgress(progress);
    }
    // SENIOR CONTRIBUTIONS & ANALYTICS
    getSeniorContributions(seniorId) {
        const defaultVal = {
            seniorId,
            resourcesContributed: 4,
            questionsAdded: 12,
            interviewExperiencesAdded: 3,
            studentsGuided: 18,
            sessionsCompleted: 9,
            mockInterviewsConducted: 6,
            gdsConducted: 4,
            feedbackSubmitted: 10,
            doubtsResolved: 15,
        };
        if (!this.isClient)
            return defaultVal;
        const raw = localStorage.getItem(`${STORAGE_KEYS.SENIOR_CONTRIBUTIONS}_${seniorId}`);
        return raw ? JSON.parse(raw) : defaultVal;
    }
    updateSeniorContribution(seniorId, updates) {
        if (!this.isClient)
            return;
        const current = this.getSeniorContributions(seniorId);
        const updated = { ...current, ...updates };
        localStorage.setItem(`${STORAGE_KEYS.SENIOR_CONTRIBUTIONS}_${seniorId}`, JSON.stringify(updated));
    }
    // COMPANIES
    getCompanies() {
        if (!this.isClient)
            return INITIAL_COMPANIES;
        const raw = localStorage.getItem(STORAGE_KEYS.COMPANIES);
        return raw ? JSON.parse(raw) : INITIAL_COMPANIES;
    }
    addCompany(company) {
        const companies = this.getCompanies();
        const newCompany = {
            ...company,
            id: `cmp_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        companies.unshift(newCompany);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify(companies));
        return newCompany;
    }
    // PLAYBOOKS
    getPlaybooks() {
        if (!this.isClient)
            return INITIAL_PLAYBOOKS;
        const raw = localStorage.getItem(STORAGE_KEYS.PLAYBOOKS);
        return raw ? JSON.parse(raw) : INITIAL_PLAYBOOKS;
    }
    savePlaybook(playbook) {
        const playbooks = this.getPlaybooks();
        const existingIdx = playbooks.findIndex((p) => p.companyId === playbook.companyId);
        const updated = {
            ...playbook,
            id: existingIdx !== -1 ? playbooks[existingIdx].id : `pb_${Date.now()}`,
            updatedAt: new Date().toISOString(),
        };
        if (existingIdx !== -1) {
            playbooks[existingIdx] = updated;
        }
        else {
            playbooks.unshift(updated);
        }
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.PLAYBOOKS, JSON.stringify(playbooks));
        return updated;
    }
    // INTERVIEW EXPERIENCES
    getInterviewExperiences() {
        if (!this.isClient)
            return INITIAL_EXPERIENCES;
        const raw = localStorage.getItem(STORAGE_KEYS.EXPERIENCES);
        return raw ? JSON.parse(raw) : INITIAL_EXPERIENCES;
    }
    addInterviewExperience(exp) {
        const experiences = this.getInterviewExperiences();
        const newExp = {
            ...exp,
            id: `exp_${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
        };
        experiences.unshift(newExp);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.EXPERIENCES, JSON.stringify(experiences));
        return newExp;
    }
    // ROUND RESOURCES
    getResources() {
        if (!this.isClient)
            return INITIAL_RESOURCES;
        const raw = localStorage.getItem(STORAGE_KEYS.RESOURCES);
        return raw ? JSON.parse(raw) : INITIAL_RESOURCES;
    }
    addResource(res) {
        const resources = this.getResources();
        const newRes = {
            ...res,
            id: `res_${Date.now()}`,
            downloadCount: 0,
            createdAt: new Date().toISOString(),
        };
        resources.unshift(newRes);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.RESOURCES, JSON.stringify(resources));
        return newRes;
    }
    // QUESTION BANK
    getQuestions() {
        if (!this.isClient)
            return INITIAL_QUESTIONS;
        const raw = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
        return raw ? JSON.parse(raw) : INITIAL_QUESTIONS;
    }
    addQuestion(q) {
        const questions = this.getQuestions();
        const newQ = {
            ...q,
            id: `q_${Date.now()}`,
        };
        questions.unshift(newQ);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
        return newQ;
    }
    // DAILY CHALLENGES
    getChallenges() {
        if (!this.isClient)
            return INITIAL_CHALLENGES;
        const raw = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
        return raw ? JSON.parse(raw) : INITIAL_CHALLENGES;
    }
    // MOCK INTERVIEWS
    getMockInterviews() {
        if (!this.isClient)
            return INITIAL_MOCK_INTERVIEWS;
        const raw = localStorage.getItem(STORAGE_KEYS.MOCK_INTERVIEWS);
        return raw ? JSON.parse(raw) : INITIAL_MOCK_INTERVIEWS;
    }
    bookMockInterview(session) {
        const mocks = this.getMockInterviews();
        const newSession = {
            ...session,
            id: `mock_${Date.now()}`,
            status: 'Scheduled',
            meetingLink: `https://meet.google.com/nec-${Math.random().toString(36).substring(2, 8)}`,
        };
        mocks.unshift(newSession);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.MOCK_INTERVIEWS, JSON.stringify(mocks));
        // Notify mentor
        this.addNotification({
            userId: session.mentorId,
            title: 'New Mock Interview Request',
            message: `${session.studentName} scheduled a ${session.type} on ${session.scheduledDate} at ${session.scheduledTime}.`,
            type: 'mock',
            isRead: false,
        });
        return newSession;
    }
    updateMockInterview(id, updates) {
        const mocks = this.getMockInterviews();
        const idx = mocks.findIndex((m) => m.id === id);
        if (idx !== -1) {
            mocks[idx] = { ...mocks[idx], ...updates };
            if (this.isClient)
                localStorage.setItem(STORAGE_KEYS.MOCK_INTERVIEWS, JSON.stringify(mocks));
        }
    }
    // MOCK GD
    getMockGDs() {
        if (!this.isClient)
            return INITIAL_MOCK_GDS;
        const raw = localStorage.getItem(STORAGE_KEYS.MOCK_GDS);
        return raw ? JSON.parse(raw) : INITIAL_MOCK_GDS;
    }
    joinMockGD(gdId, studentId, studentName) {
        const gds = this.getMockGDs();
        const gd = gds.find((g) => g.id === gdId);
        if (!gd)
            return false;
        if (gd.participants.some((p) => p.studentId === studentId))
            return true;
        if (gd.participants.length >= gd.maxParticipants)
            return false;
        gd.participants.push({ studentId, studentName });
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.MOCK_GDS, JSON.stringify(gds));
        return true;
    }
    addMockGD(gd) {
        const gds = this.getMockGDs();
        const newGD = {
            ...gd,
            id: `gd_${Date.now()}`,
            status: 'Upcoming',
            participants: [],
            meetingLink: `https://meet.google.com/nec-gd-${Math.random().toString(36).substring(2, 7)}`,
        };
        gds.unshift(newGD);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.MOCK_GDS, JSON.stringify(gds));
        return newGD;
    }
    // MENTORSHIP REQUESTS
    getMentorshipRequests() {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.MENTORSHIP_REQUESTS);
        return raw ? JSON.parse(raw) : [];
    }
    createMentorshipRequest(req) {
        const requests = this.getMentorshipRequests();
        const newReq = {
            ...req,
            id: `mreq_${Date.now()}`,
            status: 'Pending',
            createdAt: new Date().toISOString(),
        };
        requests.unshift(newReq);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.MENTORSHIP_REQUESTS, JSON.stringify(requests));
        this.addNotification({
            userId: req.mentorId,
            title: 'New Mentorship Request',
            message: `${req.studentName} requested 1-on-1 guidance on ${req.topic} (${req.targetCompany}).`,
            type: 'mentorship',
            isRead: false,
        });
        return newReq;
    }
    updateMentorshipStatus(reqId, status, notes) {
        const requests = this.getMentorshipRequests();
        const item = requests.find((r) => r.id === reqId);
        if (item) {
            item.status = status;
            if (notes)
                item.notes = notes;
            if (this.isClient)
                localStorage.setItem(STORAGE_KEYS.MENTORSHIP_REQUESTS, JSON.stringify(requests));
            this.addNotification({
                userId: item.studentId,
                title: `Mentorship Request ${status}`,
                message: `${item.mentorName} has ${status.toLowerCase()} your session request for ${item.topic}.`,
                type: 'mentorship',
                isRead: false,
            });
        }
    }
    // DOUBTS / QUESTIONS
    getDoubts() {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.DOUBTS);
        return raw ? JSON.parse(raw) : [];
    }
    askDoubt(doubt) {
        const doubts = this.getDoubts();
        const newDoubt = {
            ...doubt,
            id: `dbt_${Date.now()}`,
            status: 'Open',
            createdAt: new Date().toISOString(),
        };
        doubts.unshift(newDoubt);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.DOUBTS, JSON.stringify(doubts));
        this.addNotification({
            userId: doubt.mentorId,
            title: 'New Student Question 💬',
            message: `${doubt.studentName} asked: "${doubt.subject}"`,
            type: 'doubt',
            isRead: false,
        });
        return newDoubt;
    }
    replyDoubt(doubtId, replyText) {
        const doubts = this.getDoubts();
        const doubt = doubts.find((d) => d.id === doubtId);
        if (doubt) {
            doubt.reply = replyText;
            doubt.repliedAt = new Date().toISOString();
            doubt.status = 'Resolved';
            if (this.isClient)
                localStorage.setItem(STORAGE_KEYS.DOUBTS, JSON.stringify(doubts));
            this.addNotification({
                userId: doubt.studentId,
                title: 'Mentor Answered Your Question! 🎉',
                message: `${doubt.mentorName} replied to: "${doubt.subject}"`,
                type: 'doubt',
                isRead: false,
            });
        }
    }
    // PEER CIRCLE
    getPeerPosts() {
        if (!this.isClient)
            return INITIAL_PEER_POSTS;
        const raw = localStorage.getItem(STORAGE_KEYS.PEER_POSTS);
        return raw ? JSON.parse(raw) : INITIAL_PEER_POSTS;
    }
    createPeerPost(post) {
        const posts = this.getPeerPosts();
        const newPost = {
            ...post,
            id: `post_${Date.now()}`,
            upvotes: 0,
            replies: [],
            createdAt: new Date().toISOString(),
        };
        posts.unshift(newPost);
        if (this.isClient)
            localStorage.setItem(STORAGE_KEYS.PEER_POSTS, JSON.stringify(posts));
        return newPost;
    }
    replyPeerPost(postId, reply) {
        const posts = this.getPeerPosts();
        const post = posts.find((p) => p.id === postId);
        if (post) {
            post.replies.push({
                id: `rep_${Date.now()}`,
                ...reply,
                createdAt: new Date().toISOString(),
            });
            if (this.isClient)
                localStorage.setItem(STORAGE_KEYS.PEER_POSTS, JSON.stringify(posts));
        }
    }
    upvotePeerPost(postId) {
        const posts = this.getPeerPosts();
        const post = posts.find((p) => p.id === postId);
        if (post) {
            post.upvotes += 1;
            if (this.isClient)
                localStorage.setItem(STORAGE_KEYS.PEER_POSTS, JSON.stringify(posts));
        }
    }
    // STUDY GOALS
    getStudyGoals(userId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(`${STORAGE_KEYS.STUDY_GOALS}_${userId}`);
        return raw ? JSON.parse(raw) : [];
    }
    addStudyGoal(userId, goal) {
        const goals = this.getStudyGoals(userId);
        const newGoal = {
            ...goal,
            userId,
            id: `goal_${Date.now()}`,
            isCompleted: false,
            createdAt: new Date().toISOString(),
        };
        goals.push(newGoal);
        if (this.isClient) {
            localStorage.setItem(`${STORAGE_KEYS.STUDY_GOALS}_${userId}`, JSON.stringify(goals));
        }
        const progress = this.getUserProgress(userId);
        progress.totalStudyGoals = goals.length;
        this.saveUserProgress(progress);
        return newGoal;
    }
    toggleStudyGoal(userId, goalId) {
        const goals = this.getStudyGoals(userId);
        const goal = goals.find((g) => g.id === goalId);
        if (goal) {
            goal.isCompleted = !goal.isCompleted;
            if (this.isClient) {
                localStorage.setItem(`${STORAGE_KEYS.STUDY_GOALS}_${userId}`, JSON.stringify(goals));
            }
            const progress = this.getUserProgress(userId);
            progress.totalStudyGoals = goals.length;
            progress.studyGoalsCompleted = goals.filter((g) => g.isCompleted).length;
            this.saveUserProgress(progress);
            return goal.isCompleted;
        }
        return false;
    }
    // NOTIFICATIONS
    getNotifications(userId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(`${STORAGE_KEYS.NOTIFICATIONS}_${userId}`);
        return raw ? JSON.parse(raw) : [];
    }
    addNotification(item) {
        if (!this.isClient)
            return;
        const list = this.getNotifications(item.userId);
        const newItem = {
            ...item,
            id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newItem);
        localStorage.setItem(`${STORAGE_KEYS.NOTIFICATIONS}_${item.userId}`, JSON.stringify(list.slice(0, 30)));
    }
    markNotificationAsRead(userId, notifId) {
        if (!this.isClient)
            return;
        const list = this.getNotifications(userId);
        const target = list.find((n) => n.id === notifId);
        if (target) {
            target.isRead = true;
            localStorage.setItem(`${STORAGE_KEYS.NOTIFICATIONS}_${userId}`, JSON.stringify(list));
        }
    }
    markAllNotificationsAsRead(userId) {
        if (!this.isClient)
            return;
        const list = this.getNotifications(userId);
        list.forEach((n) => (n.isRead = true));
        localStorage.setItem(`${STORAGE_KEYS.NOTIFICATIONS}_${userId}`, JSON.stringify(list));
    }
    // FEEDBACK JOURNAL & REWINDERS
    getFeedbackEntries(userId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(`${STORAGE_KEYS.FEEDBACK}_${userId}`);
        return raw ? JSON.parse(raw) : [];
    }
    addFeedbackEntry(entry) {
        const list = this.getFeedbackEntries(entry.userId);
        const newEntry = {
            ...entry,
            id: `fb_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newEntry);
        if (this.isClient)
            localStorage.setItem(`${STORAGE_KEYS.FEEDBACK}_${entry.userId}`, JSON.stringify(list));
        return newEntry;
    }
    // RECENTLY ACCESSED
    getRecentlyAccessed(userId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(`${STORAGE_KEYS.RECENTLY_ACCESSED}_${userId}`);
        return raw ? JSON.parse(raw) : [];
    }
    recordRecentlyAccessed(userId, item) {
        if (!this.isClient)
            return;
        const list = this.getRecentlyAccessed(userId);
        const filtered = list.filter((i) => !(i.title === item.title && i.type === item.type));
        const newItem = {
            ...item,
            id: `rec_${Date.now()}`,
            userId,
            accessedAt: new Date().toISOString(),
        };
        filtered.unshift(newItem);
        localStorage.setItem(`${STORAGE_KEYS.RECENTLY_ACCESSED}_${userId}`, JSON.stringify(filtered.slice(0, 10)));
    }
    // ================= ORGANIZATIONS (PLACEMENT CELL & VISITOR) =================
    getOrganizations() {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.ORGANIZATIONS);
        if (!raw) {
            const initial = [
                {
                    id: 'org_zoho',
                    name: 'Zoho Corporation',
                    industry: 'Software & Cloud SaaS',
                    website: 'https://www.zoho.com',
                    description: 'Global SaaS enterprise creating workplace productivity, CRM, and cloud engineering solutions.',
                    location: 'Chennai & Tenkasi, Tamil Nadu',
                    contactPerson: 'Venkatesh Raman',
                    contactEmail: 'campus@zohocorp.com',
                    contactPhone: '+91 44 6744 7070',
                    jobRoles: ['Member Technical Staff (MTS)', 'Quality Analyst', 'Product Designer'],
                    status: 'Active',
                    totalDrivesConducted: 8,
                    createdAt: '2026-01-10T10:00:00Z',
                },
                {
                    id: 'org_tcs',
                    name: 'Tata Consultancy Services',
                    industry: 'IT Services & Consulting',
                    website: 'https://www.tcs.com',
                    description: 'Global IT powerhouse offering Prime, Digital, and Ninja technical profiles.',
                    location: 'Pan India',
                    contactPerson: 'Campus Talent Acquisition',
                    contactEmail: 'campus.recruitment@tcs.com',
                    contactPhone: '+91 22 6778 9999',
                    jobRoles: ['Systems Engineer (Digital)', 'Software Engineer (Prime)', 'Assistant System Engineer'],
                    status: 'Active',
                    totalDrivesConducted: 12,
                    createdAt: '2026-01-12T10:00:00Z',
                },
                {
                    id: 'org_cognizant',
                    name: 'Cognizant Technology Solutions',
                    industry: 'Information Technology',
                    website: 'https://www.cognizant.com',
                    description: 'Fortune 500 company hiring for GenC, GenC Next, and GenC Pro profiles.',
                    location: 'Coimbatore & Chennai',
                    contactPerson: 'Lead University Relations',
                    contactEmail: 'genc.campus@cognizant.com',
                    contactPhone: '+91 44 4209 6000',
                    jobRoles: ['GenC Next Developer', 'GenC Pro Full Stack', 'Programmer Analyst'],
                    status: 'Active',
                    totalDrivesConducted: 10,
                    createdAt: '2026-01-15T10:00:00Z',
                },
            ];
            localStorage.setItem(STORAGE_KEYS.ORGANIZATIONS, JSON.stringify(initial));
            return initial;
        }
        return JSON.parse(raw);
    }
    saveOrganizations(orgs) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.ORGANIZATIONS, JSON.stringify(orgs));
    }
    addOrganization(org) {
        const orgs = this.getOrganizations();
        const newOrg = {
            ...org,
            id: `org_${Date.now()}`,
            totalDrivesConducted: 0,
            createdAt: new Date().toISOString(),
        };
        orgs.unshift(newOrg);
        this.saveOrganizations(orgs);
        return newOrg;
    }
    updateOrganization(id, updates) {
        const orgs = this.getOrganizations();
        const index = orgs.findIndex((o) => o.id === id);
        if (index !== -1) {
            orgs[index] = { ...orgs[index], ...updates };
            this.saveOrganizations(orgs);
            return orgs[index];
        }
        return undefined;
    }
    // ================= PLACEMENT DRIVES =================
    getPlacementDrives() {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.PLACEMENT_DRIVES);
        if (!raw) {
            const initial = [
                {
                    id: 'drv_zoho_2026',
                    organizationId: 'org_zoho',
                    organizationName: 'Zoho Corporation',
                    jobRole: 'Member Technical Staff (MTS)',
                    salaryPackage: '8.5 - 12.0 LPA',
                    driveDate: '2026-10-15',
                    applicationDeadline: '2026-10-10',
                    location: 'NEC Main Auditorium & Computer Lab 3',
                    vacancies: 25,
                    minCgpa: 7.5,
                    maxBacklogs: 0,
                    eligibleBranches: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication Engineering'],
                    eligibleGraduationYear: 2027,
                    status: 'OPEN',
                    recruitmentRounds: ['Basic Problem Solving (C/Java)', 'Advanced Programming', 'Technical Interview 1', 'HR Round'],
                    registeredStudentIds: ['usr_prefinal_01'],
                    selectedStudentIds: [],
                    createdAt: '2026-08-01T10:00:00Z',
                },
                {
                    id: 'drv_tcs_digital_2026',
                    organizationId: 'org_tcs',
                    organizationName: 'Tata Consultancy Services',
                    jobRole: 'Systems Engineer - Digital',
                    salaryPackage: '7.2 - 9.0 LPA',
                    driveDate: '2026-10-25',
                    applicationDeadline: '2026-10-18',
                    location: 'Online Proctored & Virtual Interview',
                    vacancies: 40,
                    minCgpa: 7.0,
                    maxBacklogs: 1,
                    eligibleBranches: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication Engineering', 'Electrical & Electronics Engineering'],
                    eligibleGraduationYear: 2027,
                    status: 'UPCOMING',
                    recruitmentRounds: ['TCS NQT Assessment', 'Technical Evaluation', 'HR Interview'],
                    registeredStudentIds: [],
                    selectedStudentIds: [],
                    createdAt: '2026-08-05T10:00:00Z',
                },
            ];
            localStorage.setItem(STORAGE_KEYS.PLACEMENT_DRIVES, JSON.stringify(initial));
            return initial;
        }
        return JSON.parse(raw);
    }
    savePlacementDrives(drives) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.PLACEMENT_DRIVES, JSON.stringify(drives));
    }
    createPlacementDrive(drive) {
        const drives = this.getPlacementDrives();
        const newDrive = {
            ...drive,
            id: `drv_${Date.now()}`,
            registeredStudentIds: [],
            selectedStudentIds: [],
            createdAt: new Date().toISOString(),
        };
        drives.unshift(newDrive);
        this.savePlacementDrives(drives);
        return newDrive;
    }
    updatePlacementDrive(id, updates) {
        const drives = this.getPlacementDrives();
        const idx = drives.findIndex((d) => d.id === id);
        if (idx !== -1) {
            drives[idx] = { ...drives[idx], ...updates };
            this.savePlacementDrives(drives);
            return drives[idx];
        }
        return undefined;
    }
    // ================= STUDENT ELIGIBILITY & PARTICIPATION =================
    checkStudentEligibility(student, drive) {
        if (student.role !== 'junior' && student.role !== 'pre_final' && student.role !== 'senior') {
            return { eligible: false, reason: 'Eligible for student roles only' };
        }
        if (drive.eligibleGraduationYear && student.graduationYear && student.graduationYear !== drive.eligibleGraduationYear) {
            return { eligible: false, reason: `Target batch is ${drive.eligibleGraduationYear} (Student batch: ${student.graduationYear})` };
        }
        if (drive.eligibleBranches && drive.eligibleBranches.length > 0 && student.department) {
            const match = drive.eligibleBranches.some((b) => b.toLowerCase().includes(student.department.toLowerCase()) || student.department.toLowerCase().includes(b.toLowerCase()));
            if (!match) {
                return { eligible: false, reason: `Branch ${student.department} is not listed in eligible branches` };
            }
        }
        const studentCgpa = student.cgpa || 8.0;
        if (drive.minCgpa && studentCgpa < drive.minCgpa) {
            return { eligible: false, reason: `CGPA ${studentCgpa} is below requirement (${drive.minCgpa})` };
        }
        const backlogs = student.backlogs || 0;
        if (backlogs > drive.maxBacklogs) {
            return { eligible: false, reason: `Backlog count (${backlogs}) exceeds allowed (${drive.maxBacklogs})` };
        }
        return { eligible: true };
    }
    getDriveParticipations(driveId, studentId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.DRIVE_PARTICIPATION);
        let list = raw ? JSON.parse(raw) : [];
        if (driveId)
            list = list.filter((p) => p.driveId === driveId);
        if (studentId)
            list = list.filter((p) => p.studentId === studentId);
        return list;
    }
    registerStudentForDrive(driveId, student) {
        if (!this.isClient)
            return { success: false, error: 'Server rendering' };
        const drives = this.getPlacementDrives();
        const drive = drives.find((d) => d.id === driveId);
        if (!drive)
            return { success: false, error: 'Placement drive not found' };
        const eligibility = this.checkStudentEligibility(student, drive);
        if (!eligibility.eligible) {
            return { success: false, error: eligibility.reason || 'You do not meet the drive eligibility criteria.' };
        }
        const participations = JSON.parse(localStorage.getItem(STORAGE_KEYS.DRIVE_PARTICIPATION) || '[]');
        const existing = participations.find((p) => p.driveId === driveId && p.studentId === student.id);
        if (existing) {
            return { success: true };
        }
        const newParticipation = {
            id: `part_${Date.now()}`,
            driveId,
            driveTitle: `${drive.organizationName} - ${drive.jobRole}`,
            organizationName: drive.organizationName,
            studentId: student.id,
            studentName: student.name,
            studentEmail: student.email,
            branch: student.department || 'Computer Science & Engineering',
            graduationYear: student.graduationYear || 2027,
            cgpa: student.cgpa || 8.5,
            status: 'APPLIED',
            currentRound: drive.recruitmentRounds[0] || 'Application Submitted',
            appliedAt: new Date().toISOString(),
        };
        participations.unshift(newParticipation);
        localStorage.setItem(STORAGE_KEYS.DRIVE_PARTICIPATION, JSON.stringify(participations));
        if (!drive.registeredStudentIds.includes(student.id)) {
            drive.registeredStudentIds.push(student.id);
            this.updatePlacementDrive(driveId, { registeredStudentIds: drive.registeredStudentIds });
        }
        this.addNotification({
            userId: student.id,
            title: 'Drive Registration Confirmed',
            message: `You have successfully applied for ${drive.organizationName} (${drive.jobRole}). Drive date: ${drive.driveDate}.`,
            type: 'system',
            isRead: false,
        });
        return { success: true };
    }
    updateParticipationStatus(participationId, status, currentRound) {
        if (!this.isClient)
            return;
        const participations = JSON.parse(localStorage.getItem(STORAGE_KEYS.DRIVE_PARTICIPATION) || '[]');
        const idx = participations.findIndex((p) => p.id === participationId);
        if (idx !== -1) {
            participations[idx].status = status;
            if (currentRound)
                participations[idx].currentRound = currentRound;
            localStorage.setItem(STORAGE_KEYS.DRIVE_PARTICIPATION, JSON.stringify(participations));
        }
    }
    // ================= PLACEMENT RESULTS =================
    getPlacementResults(studentId, driveId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.PLACEMENT_RESULTS);
        let list = raw ? JSON.parse(raw) : [];
        if (studentId)
            list = list.filter((r) => r.studentId === studentId);
        if (driveId)
            list = list.filter((r) => r.driveId === driveId);
        return list;
    }
    savePlacementResults(results) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.PLACEMENT_RESULTS, JSON.stringify(results));
    }
    createPlacementResult(result) {
        const list = this.getPlacementResults();
        const newResult = {
            ...result,
            id: `res_${Date.now()}`,
            updatedAt: new Date().toISOString(),
        };
        list.unshift(newResult);
        this.savePlacementResults(list);
        if (result.selectionStatus === 'SELECTED') {
            this.addNotification({
                userId: result.studentId,
                title: '🎉 Placement Selection Conferred!',
                message: `Congratulations! You have been selected for ${result.jobRole} at ${result.organizationName} with package ${result.packageOffered}.`,
                type: 'system',
                isRead: false,
            });
        }
        return newResult;
    }
    // ================= ALUMNI SESSIONS & LIVE INTERFACE =================
    getAlumniSessions() {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.ALUMNI_SESSIONS);
        if (!raw) {
            const initial = [
                {
                    id: 'ses_alu_01',
                    alumniId: 'usr_alumni_01',
                    alumniName: 'Anand Sundaresan',
                    alumniCompany: 'Microsoft',
                    alumniDesignation: 'Senior Software Engineer',
                    title: 'Cracking Cloud Infrastructure & System Design Rounds',
                    description: 'A comprehensive interactive breakdown of real system design questions, scalable backend architecture, and coding patterns required for Tier-1 product companies.',
                    type: 'Technical Session',
                    scheduledDate: '2026-10-08',
                    scheduledTime: '18:30 IST',
                    status: 'UPCOMING',
                    meetingLink: 'https://meet.google.com/nec-alumni-cloud',
                    participants: [
                        { studentId: 'usr_prefinal_01', studentName: 'Arun Kumar M', studentEmail: 'arun@nec.edu.in' },
                        { studentId: 'usr_junior_01', studentName: 'Neha S', studentEmail: 'neha@nec.edu.in' },
                    ],
                    chatMessages: [
                        { id: 'c1', senderId: 'usr_alumni_01', senderName: 'Anand Sundaresan', message: 'Welcome students! Drop your system design questions in the Q&A tab.', timestamp: '18:30' },
                    ],
                    questions: [
                        { id: 'q1', studentId: 'usr_prefinal_01', studentName: 'Arun Kumar', question: 'How important is low-level design vs high-level architecture for freshers?', answered: true, answer: 'Focus 70% on Object-Oriented Design, schema design, and concurrency, with 30% on scaling bottlenecks.', askedAt: '18:35' },
                    ],
                    notes: 'Covered: Microservices vs Monoliths, Azure Cosmos DB, Rate Limiters, and Load Balancing algorithms.',
                    createdAt: '2026-08-10T10:00:00Z',
                },
            ];
            localStorage.setItem(STORAGE_KEYS.ALUMNI_SESSIONS, JSON.stringify(initial));
            return initial;
        }
        return JSON.parse(raw);
    }
    saveAlumniSessions(sessions) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.ALUMNI_SESSIONS, JSON.stringify(sessions));
    }
    createAlumniSession(session) {
        const list = this.getAlumniSessions();
        const newSession = {
            ...session,
            id: `ses_${Date.now()}`,
            participants: [],
            chatMessages: [],
            questions: [],
            createdAt: new Date().toISOString(),
        };
        list.unshift(newSession);
        this.saveAlumniSessions(list);
        return newSession;
    }
    updateAlumniSession(id, updates) {
        const list = this.getAlumniSessions();
        const idx = list.findIndex((s) => s.id === id);
        if (idx !== -1) {
            list[idx] = { ...list[idx], ...updates };
            this.saveAlumniSessions(list);
            return list[idx];
        }
        return undefined;
    }
    joinAlumniSession(sessionId, student) {
        const list = this.getAlumniSessions();
        const target = list.find((s) => s.id === sessionId);
        if (target) {
            if (!target.participants.some((p) => p.studentId === student.id)) {
                target.participants.push({
                    studentId: student.id,
                    studentName: student.name,
                    studentEmail: student.email,
                    joinedAt: new Date().toLocaleTimeString(),
                });
                this.saveAlumniSessions(list);
            }
        }
    }
    addAlumniChatMessage(sessionId, msg) {
        const list = this.getAlumniSessions();
        const target = list.find((s) => s.id === sessionId);
        if (target) {
            target.chatMessages.push({
                id: `chat_${Date.now()}`,
                senderId: msg.senderId,
                senderName: msg.senderName,
                message: msg.message,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            this.saveAlumniSessions(list);
        }
    }
    addAlumniQuestion(sessionId, q) {
        const list = this.getAlumniSessions();
        const target = list.find((s) => s.id === sessionId);
        if (target) {
            target.questions.push({
                id: `q_${Date.now()}`,
                studentId: q.studentId,
                studentName: q.studentName,
                question: q.question,
                answered: false,
                askedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            this.saveAlumniSessions(list);
        }
    }
    answerAlumniQuestion(sessionId, qId, answer) {
        const list = this.getAlumniSessions();
        const target = list.find((s) => s.id === sessionId);
        if (target) {
            const q = target.questions.find((item) => item.id === qId);
            if (q) {
                q.answered = true;
                q.answer = answer;
                this.saveAlumniSessions(list);
            }
        }
    }
    // ================= ALUMNI FEEDBACK =================
    getAlumniFeedback(alumniId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.ALUMNI_FEEDBACK);
        let list = raw ? JSON.parse(raw) : [];
        if (alumniId)
            list = list.filter((f) => f.alumniId === alumniId);
        return list;
    }
    submitAlumniFeedback(fb) {
        const list = this.getAlumniFeedback();
        const newFb = {
            ...fb,
            id: `afb_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newFb);
        if (this.isClient) {
            localStorage.setItem(STORAGE_KEYS.ALUMNI_FEEDBACK, JSON.stringify(list));
        }
        return newFb;
    }
    // ================= VISITOR / COMPANY REQUIREMENTS & INTERACTIONS =================
    getCompanyRequirements(visitorId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.COMPANY_REQUIREMENTS);
        if (!raw) {
            const initial = [
                {
                    id: 'req_zoho_01',
                    visitorId: 'usr_visitor_01',
                    visitorName: 'Venkatesh Raman',
                    organizationName: 'Zoho Corporation',
                    jobRole: 'Member Technical Staff (MTS)',
                    jobDescription: 'Software engineering profile focused on product development, robust data modeling, C/Java programming, and high-performance server components.',
                    requiredSkills: ['C', 'Java', 'Data Structures', 'Algorithms', 'OOPs'],
                    preferredSkills: ['System Architecture', 'Database Optimization'],
                    degree: 'B.E. / B.Tech',
                    branch: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication Engineering'],
                    graduationYear: 2027,
                    minCgpa: 7.5,
                    maxBacklogs: 0,
                    vacancies: 25,
                    workLocation: 'Chennai / Tenkasi',
                    salaryPackage: '8.5 - 12.0 LPA',
                    employmentType: 'Full-Time',
                    requiredDocuments: ['Updated Resume', '10th & 12th Marksheets', 'College ID Card', 'Semester Marksheets'],
                    recruitmentDate: '2026-10-15',
                    applicationDeadline: '2026-10-10',
                    status: 'APPROVED',
                    recruitmentRounds: [
                        { roundNumber: 1, roundName: 'Basic Problem Solving', description: 'Flowcharts, loops, basic recursion, pointers, logic building', mode: 'Offline' },
                        { roundNumber: 2, roundName: 'Advanced Programming', description: 'Complex data structures, matrix operations, game simulation logic', mode: 'Offline' },
                        { roundNumber: 3, roundName: 'Technical Interview 1', description: 'Deep code walkthrough, OOP design, database concepts', mode: 'Offline' },
                        { roundNumber: 4, roundName: 'HR & Culture Fit', description: 'Discussion on mindset, learning aptitude, teamwork', mode: 'Offline' },
                    ],
                    createdAt: '2026-08-01T10:00:00Z',
                },
            ];
            localStorage.setItem(STORAGE_KEYS.COMPANY_REQUIREMENTS, JSON.stringify(initial));
            return initial;
        }
        let list = JSON.parse(raw);
        if (visitorId)
            list = list.filter((r) => r.visitorId === visitorId);
        return list;
    }
    saveCompanyRequirements(reqs) {
        if (!this.isClient)
            return;
        localStorage.setItem(STORAGE_KEYS.COMPANY_REQUIREMENTS, JSON.stringify(reqs));
    }
    createCompanyRequirement(req) {
        const list = this.getCompanyRequirements();
        const newReq = {
            ...req,
            id: `req_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newReq);
        this.saveCompanyRequirements(list);
        return newReq;
    }
    updateCompanyRequirement(id, updates) {
        const list = this.getCompanyRequirements();
        const idx = list.findIndex((r) => r.id === id);
        if (idx !== -1) {
            list[idx] = { ...list[idx], ...updates };
            this.saveCompanyRequirements(list);
            return list[idx];
        }
        return undefined;
    }
    getCompanyInteractions(visitorId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.COMPANY_INTERACTIONS);
        let list = raw ? JSON.parse(raw) : [];
        if (visitorId)
            list = list.filter((i) => i.visitorId === visitorId);
        return list;
    }
    createCompanyInteraction(interaction) {
        const list = this.getCompanyInteractions();
        const newInteraction = {
            ...interaction,
            id: `cint_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newInteraction);
        if (this.isClient) {
            localStorage.setItem(STORAGE_KEYS.COMPANY_INTERACTIONS, JSON.stringify(list));
        }
        return newInteraction;
    }
    getCompanyDriveFeedback(visitorId) {
        if (!this.isClient)
            return [];
        const raw = localStorage.getItem(STORAGE_KEYS.COMPANY_DRIVE_FEEDBACK);
        let list = raw ? JSON.parse(raw) : [];
        if (visitorId)
            list = list.filter((f) => f.visitorId === visitorId);
        return list;
    }
    submitCompanyDriveFeedback(fb) {
        const list = this.getCompanyDriveFeedback();
        const newFb = {
            ...fb,
            id: `cdfb_${Date.now()}`,
            createdAt: new Date().toISOString(),
        };
        list.unshift(newFb);
        if (this.isClient) {
            localStorage.setItem(STORAGE_KEYS.COMPANY_DRIVE_FEEDBACK, JSON.stringify(list));
        }
        return newFb;
    }
    // USER SETTINGS
    getUserSettings(userId) {
        if (!this.isClient)
            return DEFAULT_USER_SETTINGS;
        const raw = localStorage.getItem(`${STORAGE_KEYS.SETTINGS}${userId}`);
        return raw ? { ...DEFAULT_USER_SETTINGS, ...JSON.parse(raw) } : DEFAULT_USER_SETTINGS;
    }
    saveUserSettings(userId, settings) {
        if (!this.isClient)
            return;
        localStorage.setItem(`${STORAGE_KEYS.SETTINGS}${userId}`, JSON.stringify(settings));
    }
}
export const storageService = new StorageService();
