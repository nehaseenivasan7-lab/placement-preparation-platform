/**
 * Centralized API Client for National Engineering College Placement Platform
 * Connects React frontend (JSX) with Node.js Express backend (JS)
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const getAuthHeaders = () => {
  const token = typeof window !== 'undefined' ? localStorage.getItem('necpp_auth_token') : null;
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export const api = {
  // Authentication
  auth: {
    login: async (email, password, role, rememberMe) => {
      const res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role, rememberMe }),
      });
      return res.json();
    },
    googleLogin: async (email, role) => {
      const res = await fetch(`${API_BASE_URL}/auth/google`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, role }),
      });
      return res.json();
    },
    register: async (userData, password) => {
      const res = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...userData, password }),
      });
      return res.json();
    },
    getProfile: async () => {
      const res = await fetch(`${API_BASE_URL}/auth/me`, {
        headers: getAuthHeaders(),
      });
      return res.json();
    },
  },

  // Placement Drives
  drives: {
    getAll: async () => {
      const res = await fetch(`${API_BASE_URL}/drives`);
      return res.json();
    },
    create: async (driveData) => {
      const res = await fetch(`${API_BASE_URL}/drives`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(driveData),
      });
      return res.json();
    },
    apply: async (driveId) => {
      const res = await fetch(`${API_BASE_URL}/drives/${driveId}/apply`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      return res.json();
    },
  },

  // Organizations
  organizations: {
    getAll: async (params = {}) => {
      const query = new URLSearchParams(params).toString();
      const res = await fetch(`${API_BASE_URL}/organizations?${query}`);
      return res.json();
    },
    create: async (orgData) => {
      const res = await fetch(`${API_BASE_URL}/organizations`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(orgData),
      });
      return res.json();
    },
  },

  // Company Requirements
  requirements: {
    getAll: async () => {
      const res = await fetch(`${API_BASE_URL}/requirements`);
      return res.json();
    },
    create: async (reqData) => {
      const res = await fetch(`${API_BASE_URL}/requirements`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(reqData),
      });
      return res.json();
    },
    updateStatus: async (reqId, status) => {
      const res = await fetch(`${API_BASE_URL}/requirements/${reqId}/status`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status }),
      });
      return res.json();
    },
  },

  // Automatic Eligibility Check
  eligibility: {
    check: async (student, criteria) => {
      const res = await fetch(`${API_BASE_URL}/eligibility/check`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ student, criteria }),
      });
      return res.json();
    },
  },
};

export default api;
