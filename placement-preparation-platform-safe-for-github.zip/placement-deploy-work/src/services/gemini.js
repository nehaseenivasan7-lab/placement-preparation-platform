import { GoogleGenAI } from '@google/genai';
export async function askPlacementAssistant(prompt, history = [], userRole) {
    const apiKey = import.meta.env?.VITE_GEMINI_API_KEY || (typeof process !== 'undefined' ? process.env?.GEMINI_API_KEY : undefined);
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        try {
            const ai = new GoogleGenAI({ apiKey });
            const systemInstruction = `You are the specialized AI Placement Preparation Assistant for students at National Engineering College (NEC), Kovilpatti.
You guide Junior/Second Year students, Pre-Final Year students, and Seniors on:
- Company-specific hiring rounds (Zoho, TCS Ninja/Digital, Kaar Technologies, Bosch, Infosys SP, Amazon).
- Technical coding questions (DSA, dynamic programming, 2D arrays, recursion).
- Quantitative aptitude and logical reasoning tips.
- Group Discussion frameworks and communication strategies.
- Resume building, projects explanation, and STAR method for HR interviews.
Keep your answers structured, encouraging, crisp, and high-impact. Provide code snippets or bulleted steps whenever applicable.`;
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    { role: 'user', parts: [{ text: systemInstruction }] },
                    ...history.map((h) => ({
                        role: h.role === 'user' ? 'user' : 'model',
                        parts: [{ text: h.text }],
                    })),
                    { role: 'user', parts: [{ text: prompt }] },
                ],
            });
            if (response.text) {
                return response.text;
            }
        }
        catch (err) {
            console.warn('Gemini API call failed, falling back to local expert placement engine:', err);
        }
    }
    // Domain-specific intelligent fallback engine for NEC Placement Preparation
    const query = prompt.toLowerCase();
    if (query.includes('zoho')) {
        return `### Zoho Corporation Preparation Strategy for NEC Students
**Key Focus:** Pure logic and problem-solving without standard libraries.

1. **Round 1 (C MCQs & Aptitude):**
   - Practice pointer arithmetic: \`*p++\` vs \`(*p)++\`, double pointers, static variables in recursion.
   - Master basic percentages, speed-distance, and blood relations.

2. **Round 2 (Basic Programming):**
   - Pattern printing (concentric numbers, diamonds, spiral matrix).
   - String manipulation without \`string.h\` or Java \`split()\`: e.g., expand \`a1b10\` to \`abbbbbbbbbb\`.

3. **Round 3 (Advanced Application / Game Design):**
   - 3-hour pen-and-paper or raw editor round.
   - Typical tasks: Railway Reservation System with RAC/WL, Snake & Ladder, Lift Management, Call Taxi Booking.
   - Maintain clean modular classes and dry run test cases.

💡 *Tip from Senior Priya (SEN001): Check out our **Company Playbook** and **Practice Studio** modules to solve past Zoho problems!*`;
    }
    if (query.includes('tcs') || query.includes('nqt') || query.includes('digital') || query.includes('prime')) {
        return `### TCS NQT (Ninja / Digital / Prime) Preparation Guide
**Test Pattern & Scoring:**

- **Part A (Cognitive Skills - 75 Mins):**
  - Numerical Ability (20 Qs) - High cutoff! Focus on Ratios, Time & Work, Profit & Loss.
  - Reasoning Ability (20 Qs) - Data Arrangements, Syllogisms.
  - Verbal Ability (20 Qs) - Error spotting, sentence completion.
- **Part B (Advanced Coding - 90 Mins):**
  - Question 1 (Easy/Medium): String/Array logic.
  - Question 2 (Medium/Hard - Digital/Prime qualifier): Dynamic programming, graph traversal, or sliding window.

🎯 *Strategy:* Avoid wild guesses due to negative marking. Check the **Round Resources** tab for the TCS Formula Cheatsheet uploaded by Senior Karthik (SEN003).`;
    }
    if (query.includes('resume') || query.includes('cv')) {
        return `### High-Impact Placement Resume Checklist (Single Page)
1. **Header:** Full Name, Department (e.g., CSE / ECE, NEC Kovilpatti), Email, Phone, GitHub, LinkedIn, Portfolio.
2. **Education:** Degree, College, CGPA (explicitly highlight if >= 7.5 or 8.0), HSC & SSLC percentages.
3. **Technical Skills:** Group by Languages (C++, Java, Python), Web/Frameworks (React, Node), Databases (MySQL, PostgreSQL), Core (DSA, OS, DBMS).
4. **Key Projects (2-3):**
   - Use the **XYZ formula**: *"Accomplished [X], as measured by [Y], by doing [Z]"*.
   - Mention tech stack and live demo / GitHub link.
5. **Certifications & Achievements:** LeetCode rank, Hackathons (Smart India Hackathon, NEC coding events).

You can book a 1-on-1 session with our **Resume Guidance Seniors** under the **Mentorship** tab!`;
    }
    if (query.includes('gd') || query.includes('group discussion')) {
        return `### How to Ace Campus Group Discussions (GD)
Evaluators at companies like Kaar Tech and CTS observe:
1. **Initiation vs Summarization:** If you know the topic well, initiate with a clear definition. If not, listen to the first 2 speakers and build constructively.
2. **Body Language:** Maintain eye contact with peers, never with the moderator. Nod and acknowledge others' viewpoints.
3. **Avoid Aggression:** Never shout or interrupt rudely. Use polite transition phrases:
   - *"I agree with your point regarding AI adoption, and I'd like to supplement that with..."*
   - *"While that is a valid concern, from an economic standpoint we must consider..."*
4. **Conclusion:** Offer a balanced summary that covers both pros and cons rather than taking an extreme stance.

👉 Join our weekly **Mock GD** sessions in the Workspace to practice live!`;
    }
    if (query.includes('hr') || query.includes('tell me about yourself')) {
        return `### Answering "Tell Me About Yourself" in Placement Interviews
Structure your answer in 90 seconds using the **Present - Past - Future** framework:

1. **Present (30s):** Who you are now, your department at National Engineering College, current CGPA, and your primary technical identity (e.g., *"I am a pre-final year CSE student passionate about distributed systems and algorithmic problem solving."*).
2. **Past (30s):** Key project or hackathon experience that solidified your engineering skills and teamwork.
3. **Future (30s):** Why this specific company and role excites you, and how your skills directly solve problems for their engineering team.

Keep it conversational, confident, and professional!`;
    }
    return `### Placement Guidance Assistant
Here are key recommendations tailored for your preparation at National Engineering College:

1. **Daily Practice:** Solve at least 2 coding problems in **Coding Arena** and 5 aptitude questions in **Aptitude Practice** each day to keep problem-solving speed high.
2. **Company Targets:** Review company selection rounds and salary packages in **Company Explorer** and check tested topics in **Company Playbook**.
3. **Mock Evaluations:** Don't wait until the day before the drive! Book a **Mock Interview** or participate in a **Mock GD** with our placed seniors.
4. **Doubts:** Feel free to ask technical questions to our specialized Senior Mentors via the **Mentorship & Doubts** tab.

What specific company or topic would you like to prepare for today? (e.g., Zoho, TCS, Aptitude formulas, HR answers, or DSA roadmap)`;
}
