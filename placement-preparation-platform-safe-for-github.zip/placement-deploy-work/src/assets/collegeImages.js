import necFrontEntrance from './images/real/nec_front_entrance.jpg';
import necDroneCampus from './images/real/nec_drone_campus.jpg';
import necFirstYearBlock from './images/real/nec_first_year_block.jpg';
import necLibrary from './images/real/nec_library.jpg';
import necOfficialLogo from './images/real/nec_official_logo.png';
export const COLLEGE_IMAGES = {
    entranceGate: necFrontEntrance,
    mainBuilding: necDroneCampus,
    academicBlock: necFirstYearBlock,
    library: necLibrary,
    logo: necOfficialLogo,
};
// LocalStorage key for user's uploaded custom image
export const USER_CUSTOM_IMAGE_KEY = 'nec_user_uploaded_image';
export function getEffectiveHeroImage() {
    if (typeof window !== 'undefined') {
        const custom = localStorage.getItem(USER_CUSTOM_IMAGE_KEY);
        if (custom)
            return custom;
    }
    return COLLEGE_IMAGES.entranceGate;
}
export function setCustomHeroImage(dataUrl) {
    if (typeof window !== 'undefined') {
        localStorage.setItem(USER_CUSTOM_IMAGE_KEY, dataUrl);
        window.dispatchEvent(new Event('nec_hero_image_updated'));
    }
}
export function resetCustomHeroImage() {
    if (typeof window !== 'undefined') {
        localStorage.removeItem(USER_CUSTOM_IMAGE_KEY);
        window.dispatchEvent(new Event('nec_hero_image_updated'));
    }
}
