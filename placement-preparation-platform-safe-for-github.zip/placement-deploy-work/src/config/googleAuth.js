/**
 * Original Google OAuth 2.0 Configuration
 * Common Universal Google Identity Services (GIS) Client
 *
 * HOW TO EDIT / CONFIGURE YOUR GOOGLE CLIENT ID:
 * 1. Open Google Cloud Console: https://console.cloud.google.com/apis/credentials
 * 2. Click "Create Credentials" -> "OAuth client ID" -> Select "Web application"
 * 3. Add Authorized JavaScript origins:
 *    - http://localhost:3000
 *    - http://localhost:5173
 *    - Your custom production domain
 * 4. Copy your Client ID (e.g., "1234567890-abcdefg12345.apps.googleusercontent.com")
 * 5. Update VITE_GOOGLE_CLIENT_ID in .env or edit the default below!
 */
export const GOOGLE_CLIENT_ID = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GOOGLE_CLIENT_ID) ||
    'YOUR_GOOGLE_CLIENT_ID_HERE.apps.googleusercontent.com';
// Universal Common Google Accounts (Original Google Authentication - Image 2)
export const DEFAULT_GOOGLE_ACCOUNTS = [
    {
        name: 'Anand Kumar',
        email: 'anand.kumar@gmail.com',
        avatarColor: '#1a73e8', // Google Blue
        avatarLetter: 'A',
        role: 'pre_final',
    },
    {
        name: 'Priya Sharma',
        email: 'priya.sharma@gmail.com',
        avatarColor: '#e37400', // Google Amber/Orange
        avatarLetter: 'P',
        status: 'Signed out',
        role: 'senior',
    },
    {
        name: 'Candidate User',
        email: 'candidate.user@gmail.com',
        avatarColor: '#188038', // Google Green
        avatarLetter: 'C',
        status: 'Signed out',
        role: 'junior',
    },
];
/**
 * Builds the official Google OAuth 2.0 Authorization URL
 * Used to trigger real Google sign-in redirect / popup
 */
export function getGoogleOAuthUrl(clientId, redirectUri = window.location.origin) {
    const rootUrl = 'https://accounts.google.com/o/oauth2/v2/auth';
    const options = {
        redirect_uri: redirectUri,
        client_id: clientId,
        access_type: 'offline',
        response_type: 'token',
        prompt: 'select_account',
        scope: [
            'https://www.googleapis.com/auth/userinfo.profile',
            'https://www.googleapis.com/auth/userinfo.email',
        ].join(' '),
    };
    const qs = new URLSearchParams(options);
    return `${rootUrl}?${qs.toString()}`;
}
