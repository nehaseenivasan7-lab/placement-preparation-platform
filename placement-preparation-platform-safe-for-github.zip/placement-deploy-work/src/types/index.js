/**
 * JavaScript Type placeholders & runtime constants
 * Formerly TypeScript type definitions
 */

export const UserRole = {
  JUNIOR: 'junior',
  PRE_FINAL: 'pre_final',
  SENIOR: 'senior',
  ADMIN: 'admin',
};

export const SeniorSpecialization = {
  COMPANY_EXPLORER: 'Company Explorer',
  COMPANY_PLAYBOOK: 'Company Playbook',
  INTERVIEW_EXPERIENCE: 'Interview Experience',
  ROUND_RESOURCES: 'Round Resources',
  QUESTION_BANK: 'Question Bank',
  PRACTICE_STUDIO: 'Practice Studio',
  DAILY_CHALLENGES: 'Daily Challenges',
  CODING_ARENA: 'Coding Arena',
  APTITUDE_PRACTICE: 'Aptitude Practice',
  MOCK_INTERVIEW: 'Mock Interview',
  MOCK_GD: 'Mock GD',
  MENTORSHIP: 'Mentorship',
  RESUME_GUIDANCE: 'Resume Guidance',
  TECHNICAL_INTERVIEW: 'Technical Interview',
  HR_INTERVIEW: 'HR Interview',
};

export const User = {};
export const UserSettings = {};
export const UserProgress = {};
export const SeniorContribution = {};
export const Company = {};
export const CompanyPlaybook = {};
export const InterviewExperience = {};
export const RoundResource = {};
export const Question = {};
export const DailyChallenge = {};
export const MockInterviewSession = {};
export const MockGDSession = {};
export const MentorshipRequest = {};
export const DoubtQuestion = {};
export const PeerPost = {};
export const StudyGoal = {};
export const NotificationItem = {};
export const FeedbackJournalEntry = {};
export const RecentlyAccessedItem = {};
export const AlumniSession = {};
export const AlumniFeedback = {};
export const CompanyRequirement = {};
export const CompanyInteraction = {};
export const CompanyDriveFeedback = {};
export const Organization = {};
export const PlacementDrive = {};
export const DriveParticipation = {};
export const PlacementResult = {};

export default {
  UserRole,
  SeniorSpecialization,
};
