import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { HelpCenterModal } from './components/HelpCenterModal';
import { AIChatbotModal } from './components/AIChatbotModal';
// Views
import { NecHomePage } from './components/views/NecHomePage';
import { HubView } from './components/views/HubView';
import { JuniorWorkspaceView } from './components/views/JuniorWorkspaceView';
import { ReadinessDashboard } from './components/modules/ReadinessDashboard';
import { AdminWorkspaceView } from './components/views/AdminWorkspaceView';
import { SeniorWorkspaceView } from './components/views/SeniorWorkspaceView';
// Module Components: Discover
import { CompanyExplorer } from './components/modules/CompanyExplorer';
import { CompanyPlaybook } from './components/modules/CompanyPlaybook';
import { InterviewExperiences } from './components/modules/InterviewExperiences';
import { RoundResources } from './components/modules/RoundResources';
// Module Components: Connect
import { MockInterviews } from './components/modules/MockInterviews';
import { MockGD } from './components/modules/MockGD';
import { MentorshipView } from './components/modules/MentorshipView';
import { PeerCircle } from './components/modules/PeerCircle';
// Module Components: Practice
import { QuestionBank } from './components/modules/QuestionBank';
import { PracticeStudio } from './components/modules/PracticeStudio';
import { DailyChallenges } from './components/modules/DailyChallenges';
// Module Components: Track
import { PerformanceAnalytics } from './components/modules/PerformanceAnalytics';
import { Leaderboard } from './components/modules/Leaderboard';
import { UpcomingSessions } from './components/modules/UpcomingSessions';
import { FeedbackJournal } from './components/modules/FeedbackJournal';
import { StudyPlanner } from './components/modules/StudyPlanner';
import { ArrowLeft, Menu, Sparkles } from 'lucide-react';
const AppContent = () => {
    const { user, isAuthenticated } = useAuth();
    const { settings, t } = useTheme();
    const background = settings?.background;
    // Front Page vs Workspace View Mode
    const [viewMode, setViewMode] = useState('home');
    const [showAuthModal, setShowAuthModal] = useState(false);
    // Automatically navigate to home page when user logs out
    React.useEffect(() => {
        if (!isAuthenticated) {
            setViewMode('home');
            setActiveModule(null);
        }
    }, [isAuthenticated]);
    // Navigation State inside Workspace
    const [currentTab, setCurrentTab] = useState('workspace');
    const [activeModule, setActiveModule] = useState(null);
    const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    // Modals state
    const [showProfile, setShowProfile] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [settingsTab, setSettingsTab] = useState('appearance');
    const [showHelp, setShowHelp] = useState(false);
    const [showAIChatbot, setShowAIChatbot] = useState(false);
    // Handler when user clicks "Enter Workspace" on the NEC Home Page
    const handleEnterWorkspace = () => {
        if (!isAuthenticated || !user) {
            setShowAuthModal(true);
        }
        else {
            setViewMode('workspace');
            setCurrentTab('workspace');
            setActiveModule(null);
        }
    };
    const handleOpenModule = (moduleId) => {
        setActiveModule(moduleId);
        setCurrentTab(moduleId);
    };
    const handleBackToWorkspace = () => {
        setActiveModule(null);
        setCurrentTab('workspace');
    };
    // Determine Background CSS
    let bgClass = 'bg-college-pattern';
    if (background === 'mesh')
        bgClass = 'bg-mesh-pattern';
    else if (background === 'gradient')
        bgClass = 'bg-gradient-pattern';
    else if (background === 'abstract')
        bgClass = 'bg-abstract-pattern';
    else if (background === 'minimal')
        bgClass = 'bg-slate-50';
    // 1. FRONT PAGE: Official NEC Home Page with uploaded image
    if (viewMode === 'home') {
        return (<>
        <NecHomePage onEnterWorkspace={handleEnterWorkspace}/>
        {showAuthModal && (<AuthModal onSuccess={() => {
                    setShowAuthModal(false);
                    setViewMode('workspace');
                    setCurrentTab('workspace');
                }} onClose={() => setShowAuthModal(false)}/>)}
      </>);
    }
    // 2. WORKSPACE AREA
    const renderWorkspaceContent = () => {
        // Junior students receive their dedicated 10-module beginner workspace
        if (user?.role === 'junior') {
            return (<JuniorWorkspaceView activeSection={activeModule || currentTab || 'journey'} onOpenModule={handleOpenModule}/>);
        }
        if (activeModule) {
            return (<div className="space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <button onClick={handleBackToWorkspace} className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold border border-slate-200 dark:border-slate-700 shadow-2xs text-xs transition cursor-pointer">
              <ArrowLeft className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300"/>
              <span>{t('backToHub', 'Back to Workspace')}</span>
            </button>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-slate-500 bg-slate-100 dark:bg-slate-800 dark:text-slate-400 px-2.5 py-0.5 rounded-full font-semibold">
                NEC Platform • {activeModule.replace(/([A-Z])/g, ' $1').trim()}
              </span>
            </div>
          </div>

          {/* Junior Specific Modules */}
          {['journey', 'careers', 'companies', 'skills', 'coding_basics', 'aptitude_starter', 'challenges', 'ask_senior', 'progress', 'planner'].includes(activeModule) && (<JuniorWorkspaceView onOpenModule={handleOpenModule} activeSection={activeModule}/>)}

          {/* 1. Discover */}
          {activeModule === 'companyExplorer' && <CompanyExplorer />}
          {activeModule === 'companyPlaybook' && <CompanyPlaybook />}
          {activeModule === 'interviewExperiences' && <InterviewExperiences />}
          {activeModule === 'roundResources' && <RoundResources />}

          {/* 2. Connect */}
          {activeModule === 'mockInterviews' && <MockInterviews />}
          {activeModule === 'mockGD' && <MockGD />}
          {activeModule === 'mentorship' && <MentorshipView />}
          {activeModule === 'peerCircle' && <PeerCircle />}

          {/* 3. Practice */}
          {activeModule === 'questionBank' && <QuestionBank />}
          {activeModule === 'practiceStudio' && <PracticeStudio />}
          {activeModule === 'dailyChallenges' && <DailyChallenges />}

          {/* 4. Track */}
          {activeModule === 'performanceAnalytics' && <PerformanceAnalytics />}
          {activeModule === 'readinessDashboard' && <ReadinessDashboard />}
          {activeModule === 'studyPlanner' && <StudyPlanner />}
          {activeModule === 'leaderboard' && <Leaderboard />}
          {activeModule === 'upcomingSessions' && <UpcomingSessions />}
          {activeModule === 'feedbackJournal' && <FeedbackJournal />}
        </div>);
        }
        if (currentTab === 'workspace') {
            if (user?.role === 'senior') {
                return <SeniorWorkspaceView onOpenModule={handleOpenModule}/>;
            }
            if (user?.role === 'admin') {
                return <AdminWorkspaceView />;
            }
            return (<HubView onOpenModule={handleOpenModule} onOpenSettings={() => {
                    setSettingsTab('appearance');
                    setShowSettings(true);
                }}/>);
        }
        switch (currentTab) {
            case 'readinessDashboard':
                return <ReadinessDashboard />;
            case 'admin':
                return <AdminWorkspaceView />;
            case 'senior':
                return <SeniorWorkspaceView onOpenModule={handleOpenModule}/>;
            default:
                return (<HubView onOpenModule={handleOpenModule} onOpenSettings={() => {
                        setSettingsTab('appearance');
                        setShowSettings(true);
                    }}/>);
        }
    };
    return (<div className={`min-h-screen flex ${bgClass} text-slate-800`}>
      {/* Sidebar with Categorized Headings: Discover, Connect, Practice, Track, Readiness Dashboard */}
      <Sidebar currentTab={currentTab} activeModule={activeModule} onSelectTab={(tab) => {
            setCurrentTab(tab);
            setActiveModule(null);
        }} onOpenModule={handleOpenModule} onGoToNecHome={() => setViewMode('home')} isMobileOpen={isMobileSidebarOpen} setIsMobileOpen={setIsMobileSidebarOpen}/>

      {/* Main Container */}
      <div className="flex-1 flex flex-col lg:pl-64 min-w-0">
        <div className="relative">
          {/* Mobile hamburger button */}
          <button onClick={() => setIsMobileSidebarOpen(true)} className="lg:hidden fixed bottom-20 left-4 z-40 p-3 bg-blue-900 text-white rounded-full shadow-lg cursor-pointer">
            <Menu className="w-5 h-5"/>
          </button>

          <Header onOpenProfile={() => setShowProfile(true)} onOpenSettings={(tab) => {
            if (tab)
                setSettingsTab(tab);
            setShowSettings(true);
        }} onOpenHelp={() => setShowHelp(true)} searchQuery={searchQuery} setSearchQuery={setSearchQuery}/>
        </div>

        {/* Workspace Body */}
        <main className="flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto pb-24">
          {renderWorkspaceContent()}
        </main>
      </div>

      {/* AI ASSISTANT IN RIGHT DOWN SIDE */}
      <div className="fixed bottom-5 right-5 z-40">
        <button onClick={() => setShowAIChatbot(!showAIChatbot)} title="Open AI Placement Assistant" className="flex items-center gap-2.5 px-4 py-3 bg-linear-to-r from-blue-700 via-indigo-700 to-blue-950 hover:from-blue-800 hover:to-indigo-800 text-white rounded-2xl shadow-xl shadow-blue-950/30 border border-white/20 transition-all transform hover:scale-105 active:scale-95 cursor-pointer group">
          <div className="relative">
            <Sparkles className="w-5 h-5 text-amber-300 animate-pulse"/>
          </div>
          <div className="text-left hidden sm:block">
            <p className="text-xs font-black tracking-tight leading-none text-white">
              {t('aiAssistant')}
            </p>
            <p className="text-[10px] text-amber-200/90 font-medium">NEC 24/7 Placement Advisor</p>
          </div>
          <span className="relative flex h-2.5 w-2.5 ml-0.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
        </button>
      </div>

      {/* Foreground Modals */}
      <ProfileModal isOpen={showProfile} onClose={() => setShowProfile(false)}/>

      <SettingsModal isOpen={showSettings} initialTab={settingsTab} onClose={() => setShowSettings(false)} onOpenProfile={() => {
            setShowSettings(false);
            setShowProfile(true);
        }}/>

      <HelpCenterModal isOpen={showHelp} onClose={() => setShowHelp(false)}/>

      <AIChatbotModal isOpen={showAIChatbot} onClose={() => setShowAIChatbot(false)}/>

      {/* Sign In / Sign Up Modal */}
      {showAuthModal && (<AuthModal onSuccess={() => {
                setShowAuthModal(false);
                setViewMode('workspace');
            }} onClose={() => setShowAuthModal(false)}/>)}
    </div>);
};
export default function App() {
    return (<AuthProvider>
      <ThemeProvider>
        <AppContent />
      </ThemeProvider>
    </AuthProvider>);
}
