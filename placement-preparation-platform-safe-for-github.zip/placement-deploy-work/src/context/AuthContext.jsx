import React, { createContext, useContext, useState, useEffect } from 'react';
import { storageService } from '../services/storage';
const AuthContext = createContext(undefined);
export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    useEffect(() => {
        // Check existing stored user session
        const stored = storageService.getCurrentUser();
        if (stored) {
            setUser(stored);
        }
    }, []);
    const login = async (identifier, passwordPlain, role, remember = true) => {
        try {
            const authenticated = storageService.verifyCredentials(identifier, passwordPlain, role);
            storageService.setCurrentUser(authenticated, remember);
            setUser(authenticated);
            return { success: true };
        }
        catch (err) {
            return { success: false, error: err.message || 'Login failed' };
        }
    };
    const register = async (userData, passwordPlain) => {
        try {
            const newUser = storageService.registerUser(userData, passwordPlain);
            storageService.setCurrentUser(newUser, true);
            setUser(newUser);
            return { success: true };
        }
        catch (err) {
            return { success: false, error: err.message || 'Registration failed' };
        }
    };
    const loginWithGoogle = async (role, email, password) => {
        // Automatically accept any email on first attempt (defaults to student email 24104009@nec.edu.in)
        const targetEmail = (email && email.trim()) || '24104009@nec.edu.in';
        const effectiveRole = role || 'pre_final';
        let existing = storageService.getUserByEmail(targetEmail);
        if (!existing) {
            const emailLower = targetEmail.toLowerCase();
            const localPart = emailLower.includes('@') ? emailLower.split('@')[0] : emailLower;
            const displayName = localPart.includes('.')
                ? localPart.split('.').map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join(' ')
                : localPart.match(/^\d+$/)
                    ? `Member (${localPart})`
                    : localPart.charAt(0).toUpperCase() + localPart.slice(1);
            const gradYear = effectiveRole === 'junior'
                ? 2028
                : effectiveRole === 'pre_final'
                    ? 2027
                    : effectiveRole === 'senior'
                        ? 2026
                        : undefined;
            const userPayload = {
                name: displayName,
                email: targetEmail.includes('@') ? targetEmail : `${targetEmail}@nec.edu.in`,
                role: effectiveRole,
                college: 'National Engineering College, Kovilpatti',
                department: effectiveRole === 'admin' ? 'Training and Placement Cell' : 'Computer Science & Engineering',
                graduationYear: gradYear,
                degree: 'B.E.',
                skills: ['Problem Solving', 'Data Structures', 'Communication', 'Industry Practices'],
            };
            if (effectiveRole === 'senior') {
                userPayload.seniorId = `SEN${Date.now().toString().slice(-3)}`;
                userPayload.specialization = 'Interview Experience';
            }
            else if (effectiveRole === 'admin') {
                userPayload.adminId = `ADM${Date.now().toString().slice(-3)}`;
            }
            existing = storageService.registerUser(userPayload, password || '123');
        }
        else if (password) {
            // Update saved password if provided
            storageService.savePassword(targetEmail, password);
        }
        storageService.setCurrentUser(existing, true);
        setUser(existing);
        return { success: true };
    };
    const logout = () => {
        storageService.setCurrentUser(null, false);
        setUser(null);
    };
    const updateProfile = async (updates) => {
        if (!user)
            throw new Error('No user logged in');
        const updated = storageService.updateUserProfile(user.id, updates);
        setUser({ ...updated });
        return updated;
    };
    const reloadUser = () => {
        if (user) {
            const fresh = storageService.getUserById(user.id);
            if (fresh)
                setUser({ ...fresh });
        }
    };
    return (<AuthContext.Provider value={{
            user,
            role: user ? user.role : null,
            isAuthenticated: !!user,
            login,
            register,
            loginWithGoogle,
            logout,
            updateProfile,
            reloadUser,
        }}>
      {children}
    </AuthContext.Provider>);
};
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
