import React, { createContext, useContext, useState, useEffect } from 'react';
import { storageService, DEFAULT_USER_SETTINGS } from '../services/storage';
import { useAuth } from './AuthContext';
export const PRESET_THEME_COLORS = [
    { id: 'blue', name: 'Royal Blue', hex: '#1e40af', desc: 'Official Campus Navy' },
    { id: 'green', name: 'Emerald Green', hex: '#15803d', desc: 'Fresh Nature Green' },
    { id: 'orange', name: 'Amber Orange', hex: '#ea580c', desc: 'Energetic Vibrant Amber' },
    { id: 'red', name: 'Crimson Red', hex: '#dc2626', desc: 'Bold Dynamic Crimson' },
    { id: 'gray', name: 'Slate Gray', hex: '#4b5563', desc: 'Minimal Professional Slate' },
    { id: 'purple', name: 'Royal Purple', hex: '#7e22ce', desc: 'Academic Deep Violet' },
    { id: 'maroon', name: 'Deep Maroon', hex: '#881337', desc: 'Classic University Maroon' },
    { id: 'pink', name: 'Hot Pink', hex: '#db2777', desc: 'Modern Vibrant Rose' },
];
export const SPECIAL_HEX_PALETTE = [
    { id: '#B08401', name: 'Gold Mustard', hex: '#B08401', isSpecial: true },
    { id: '#D49E8D', name: 'Dusty Peach', hex: '#D49E8D', isSpecial: true },
    { id: '#683B2B', name: 'Deep Terracotta', hex: '#683B2B', isSpecial: true },
    { id: '#4A6163', name: 'Slate Teal', hex: '#4A6163', isSpecial: true },
    { id: '#F17A7E', name: 'Coral Rose', hex: '#F17A7E', isSpecial: true },
    { id: '#E43D12', name: 'Fiery Crimson', hex: '#E43D12', isSpecial: true },
    { id: '#00CEC8', name: 'Vibrant Cyan', hex: '#00CEC8', isSpecial: true },
    { id: '#A1CCA6', name: 'Sage Mint', hex: '#A1CCA6', isSpecial: true },
    { id: '#097C87', name: 'Ocean Teal', hex: '#097C87', isSpecial: true },
    { id: '#FFCFD2', name: 'Pastel Blossom', hex: '#FFCFD2', isSpecial: true },
];
const ThemeContext = createContext(undefined);
// Comprehensive Multilingual Translation Map
const TRANSLATIONS = {
    // Navigation & Core Sections
    workspace: { en: 'Workspace', ta: 'பணியிடம்', hi: 'कार्यक्षेत्र' },
    readinessDashboard: { en: 'Readiness Dashboard', ta: 'தயார்நிலை தகவல் பலகை', hi: 'तैयारी डैशबोर्ड' },
    necHome: { en: 'NEC Home', ta: 'என்.இ.சி முகப்பு', hi: 'एनईसी मुख्य पृष्ठ' },
    enterWorkspace: { en: 'Enter Workspace', ta: 'பணியிடத்திற்குள் செல்க', hi: 'कार्यक्षेत्र में प्रवेश करें' },
    discover: { en: 'Discover', ta: 'கண்டுபிடி', hi: 'खोजें' },
    connect: { en: 'Connect', ta: 'இணைக்க', hi: 'जुड़ें' },
    practice: { en: 'Practice', ta: 'பயிற்சி', hi: 'अभ्यास' },
    track: { en: 'Track', ta: 'கண்காணிக்க', hi: 'ट्रैक करें' },
    adminCenter: { en: 'Admin Control Center', ta: 'நிர்வாக கட்டுப்பாட்டு மையம்', hi: 'व्यवस्थापक नियंत्रण केंद्र' },
    admin: { en: 'Placement Admin', ta: 'வேலைவாய்ப்பு நிர்வாகி', hi: 'व्यवस्थापक' },
    junior: { en: 'Junior Student (2nd Year)', ta: 'இளநிலை மாணவர் (2ஆம் ஆண்டு)', hi: 'कनिष्ठ छात्र' },
    pre_final: { en: 'Pre-Final Year Student', ta: 'முந்தைய இறுதி ஆண்டு மாணவர்', hi: 'पूर्व-अंतिम वर्ष' },
    senior: { en: 'Placed Senior Mentor', ta: 'தேர்வுபெற்ற மூத்த வழிகாட்டி', hi: 'वरिष्ठ संरक्षक' },
    // Junior Workspace Tabs & Features
    journey: { en: 'Placement Journey', ta: 'வேலைவாய்ப்புப் பயணம்', hi: 'प्लेसमेंट यात्रा' },
    careers: { en: 'Career Explorer', ta: 'தொழில் வழிகாட்டி', hi: 'करियर एक्सप्लोरर' },
    companies: { en: 'Company Explorer', ta: 'நிறுவனத் தேடல்', hi: 'कंपनी एक्सप्लोरर' },
    skills: { en: 'Skill Builder', ta: 'திறன் வளர்ப்பகம்', hi: 'कौशल विकास' },
    coding_basics: { en: 'Coding Basics', ta: 'அடிப்படை நிரலாக்கம்', hi: 'कोडिंग बुनियादी बातें' },
    aptitude_starter: { en: 'Aptitude Starter', ta: 'திறனறி தொடக்கம்', hi: 'एप्टीट्यूड स्टार्टर' },
    challenges: { en: 'Daily Challenges', ta: 'தினசரி சவால்கள்', hi: 'दैनिक चुनौतियां' },
    ask_senior: { en: 'Ask a Senior', ta: 'மூத்தவரிடம் கேளுங்கள்', hi: 'सीनियर से पूछें' },
    progress: { en: 'My Learning Progress', ta: 'எனது கற்றல் முன்னேற்றம்', hi: 'मेरी प्रगति' },
    planner: { en: 'Learning Planner', ta: 'கற்றல் திட்டமிடுபவர்', hi: 'अध्ययन योजना' },
    // Admin Hub Features
    cohortMonitor: { en: 'Student Cohort Monitor', ta: 'மாணவர் குழு கண்காணிப்பு', hi: 'छात्र समूह मॉनिटर' },
    sendBroadcast: { en: 'Send Broadcast Email', ta: 'அறிவிப்பு மின்னஞ்சல் அனுப்பு', hi: 'प्रसारण ईमेल भेजें' },
    scheduleSession: { en: 'Schedule Live Session', ta: 'நேரலை அமர்வைத் திட்டமிடு', hi: 'लाइव सत्र शेड्यूल करें' },
    addDrive: { en: 'Post Placement Drive', ta: 'வேலைவாய்ப்பு முகாமைப் பதிவிடு', hi: 'प्लेसमेंट ड्राइव पोस्ट करें' },
    exportData: { en: 'Export Analytics', ta: 'தரவுகளை ஏற்றுமதி செய்', hi: 'डेटा निर्यात करें' },
    broadcastSubject: { en: 'Subject / Title', ta: 'தலைப்பு / விஷயம்', hi: 'विषय' },
    broadcastMessage: { en: 'Message Content', ta: 'செய்தி உள்ளடக்கம்', hi: 'संदेश' },
    sendNow: { en: 'Send to Students Now', ta: 'மாணவர்களுக்கு உடனே அனுப்பு', hi: 'अभी भेजें' },
    selectCohort: { en: 'Target Cohort', ta: 'இலக்கு மாணவர்கள்', hi: 'लक्षित समूह' },
    allStudents: { en: 'All Registered Students', ta: 'அனைத்து பதிவு செய்த மாணவர்கள்', hi: 'सभी छात्र' },
    onlyJuniors: { en: '2nd Year Juniors Only', ta: '2ஆம் ஆண்டு இளநிலை மாணவர்கள் மட்டும்', hi: 'केवल कनिष्ठ' },
    onlyPreFinal: { en: '3rd Year Pre-Final Only', ta: '3ஆம் ஆண்டு மாணவர்கள் மட்டும்', hi: 'केवल प्री-फाइनल' },
    onlySeniors: { en: 'Senior Mentors Only', ta: 'மூத்த வழிகாட்டிகள் மட்டும்', hi: 'केवल सीनियर्स' },
    // Themes & Settings
    light: { en: 'Light Mode', ta: 'பகல் முறைமை', hi: 'लाइट मोड' },
    dark: { en: 'Dark Mode', ta: 'இரவு முறைமை', hi: 'डार्क मोड' },
    themeColor: { en: 'Color Theme', ta: 'வண்ண தீம்', hi: 'रंग थीम' },
    mode: { en: 'Appearance Mode', ta: 'தோற்ற முறை', hi: 'दिखावट मोड' },
    settings: { en: 'Settings', ta: 'அமைப்புகள்', hi: 'सेटिंग्स' },
    language: { en: 'Language', ta: 'மொழி', hi: 'भाषा' },
    notifications: { en: 'Notifications', ta: 'அறிவிப்புகள்', hi: 'सूचनाएं' },
    profile: { en: 'Profile', ta: 'சுயவிவரம்', hi: 'प्रोफ़ाइल' },
    logout: { en: 'Logout', ta: 'வெளியேறு', hi: 'लॉग आउट' },
    help: { en: 'Help Center', ta: 'உதவி மையம்', hi: 'सहायता केंद्र' },
    search: { en: 'Search modules, companies, questions...', ta: 'தொகுதிகள், நிறுவனங்கள், கேள்விகளைத் தேடவும்...', hi: 'खोजें...' },
    save: { en: 'Save Changes', ta: 'மாற்றங்களைச் சேமிக்க', hi: 'सहेजें' },
    cancel: { en: 'Cancel', ta: 'ரத்து செய்', hi: 'रद्द करें' },
    close: { en: 'Close', ta: 'மூடு', hi: 'बंद करें' },
    submit: { en: 'Submit', ta: 'சமர்ப்பி', hi: 'जमा करें' },
    solve: { en: 'Solve Now', ta: 'இப்போது தீர்க்கவும்', hi: 'हल करें' },
    runCode: { en: 'Run Code', ta: 'நிரலை இயக்கு', hi: 'कोड चलाएं' },
    testCases: { en: 'Test Cases', ta: 'சோதனை நிகழ்வுகள்', hi: 'परीक्षण मामले' },
    output: { en: 'Terminal Output', ta: 'முனைய வெளியீடு', hi: 'आउटपुट' },
    passed: { en: 'Passed', ta: 'வெற்றி பெற்றது', hi: 'उत्तीर्ण' },
    failed: { en: 'Failed', ta: 'தோல்வி அடைந்தது', hi: 'विफल' },
    hint: { en: 'Hint', ta: 'குறிப்பு', hi: 'संकेत' },
    solution: { en: 'Solution', ta: 'தீர்வு', hi: 'समाधान' },
    checkAnswer: { en: 'Check Answer', ta: 'பதிலைச் சரிபார்', hi: 'उत्तर जांचें' },
    explanation: { en: 'Explanation', ta: 'விளக்கம்', hi: 'स्पष्टीकरण' },
    points: { en: 'Points', ta: 'மதிப்பெண்கள்', hi: 'अंक' },
    level: { en: 'Level', ta: 'நிலை', hi: 'स्तर' },
    streak: { en: 'Daily Streak', ta: 'தொடர் கற்றல் நாட்கள்', hi: 'दैनिक स्ट्रीक' },
    activeNow: { en: 'Active Now', ta: 'தற்போது செயல்படுகிறது', hi: 'अभी सक्रिय' },
    upcoming: { en: 'Upcoming', ta: 'வரவிருப்பது', hi: 'आगामी' },
    completed: { en: 'Completed', ta: 'முடிவடைந்தது', hi: 'पूर्ण' },
    inProgress: { en: 'In Progress', ta: 'நடைபெறுகிறது', hi: 'प्रगति पर' },
    // Modules (18 Pre-Final)
    companyExplorer: { en: 'Company Explorer', ta: 'நிறுவனத் தேடல்', hi: 'कंपनी एक्सप्लोरर' },
    companyPlaybook: { en: 'Company Playbook', ta: 'நிறுவன வழிகாட்டி புத்தகம்', hi: 'कंपनी प्लेबुक' },
    interviewExperiences: { en: 'Interview Experiences', ta: 'நேர்காணல் அனுபவங்கள்', hi: 'साक्षात्कार अनुभव' },
    roundResources: { en: 'Round Resources', ta: 'சுற்று வளங்கள்', hi: 'दौर संसाधन' },
    questionBank: { en: 'Question Bank', ta: 'வினா வங்கி', hi: 'प्रश्न बैंक' },
    practiceStudio: { en: 'Practice Studio', ta: 'பயிற்சி அரங்கம்', hi: 'अभ्यास स्टूडियो' },
    dailyChallenges: { en: 'Daily Challenges', ta: 'தினசரி சவால்கள்', hi: 'दैनिक चुनौतियां' },
    codingArena: { en: 'Coding Arena', ta: 'நிரலாக்க களம்', hi: 'कोडिंग एरिना' },
    aptitudePractice: { en: 'Aptitude Practice', ta: 'திறனறி தேர்வு பயிற்சி', hi: 'एप्टीट्यूड अभ्यास' },
    mockInterviewsMod: { en: 'Mock Interviews', ta: 'மாதிரி நேர்காணல்கள்', hi: 'मॉक साक्षात्कार' },
    mockGD: { en: 'Mock Group Discussion (GD)', ta: 'மாதிரி குழு விவாதம் (GD)', hi: 'मॉक समूह चर्चा (जीडी)' },
    mentorship: { en: 'Mentorship Hub', ta: 'வழிகாட்டி மையம்', hi: 'मेंटरशिप हब' },
    peerCircle: { en: 'Peer Circle Forum', ta: 'மாணவர் வட்டம் மன்றம்', hi: 'सहकर्मी चर्चा मंच' },
    studyPlanner: { en: 'Study Planner & Goals', ta: 'படிப்புத் திட்டம் & இலக்குகள்', hi: 'अध्ययन योजना' },
    performanceAnalytics: { en: 'Performance Analytics', ta: 'செயல்திறன் பகுப்பாய்வு', hi: 'प्रदर्शन विश्लेषण' },
    leaderboard: { en: 'Student Leaderboard', ta: 'மாணவர் தரவரிசைப் பட்டியல்', hi: 'छात्र लीडरबोर्ड' },
    upcomingSessions: { en: 'Upcoming Sessions', ta: 'வரவிருக்கும் அமர்வுகள்', hi: 'आगामी सत्र' },
    feedbackJournal: { en: 'Feedback Journal', ta: 'கருத்து இதழ் & மீள்பார்வை', hi: 'फीडबैक जर्नल' },
    // General Placement Terms
    eligibility: { en: 'Eligibility', ta: 'தகுதி வரம்பு', hi: 'पात्रता' },
    ctc: { en: 'CTC Package', ta: 'வருடாந்திர ஊதியத் தொகுப்பு', hi: 'वेतन पैकेज' },
    roles: { en: 'Job Roles', ta: 'பணிப் பொறுப்புகள்', hi: 'नौकरी भूमिकाएं' },
    backlogs: { en: 'Active Backlogs', ta: 'நிலுவையில் உள்ள தாள்கள்', hi: 'बैकलॉग' },
    cgpa: { en: 'CGPA Cutoff', ta: 'மதிப்பெண் புள்ளி (CGPA)', hi: 'सीजीपीए' },
    department: { en: 'Department', ta: 'துறை', hi: 'विभाग' },
    rollNumber: { en: 'Roll Number', ta: 'பதிவு எண்', hi: 'रोल नंबर' },
    email: { en: 'Email Address', ta: 'மின்னஞ்சல் முகவரி', hi: 'ईमेल' },
    phone: { en: 'Phone Number', ta: 'தொலைபேசி எண்', hi: 'फ़ोन नंबर' },
    collegeName: { en: 'National Engineering College, Kovilpatti', ta: 'தேசிய பொறியியல் கல்லூரி, கோவில்பட்டி', hi: 'नेशनल इंजीनियरिंग कॉलेज' },
    platformTitle: { en: 'Placement Preparation Platform', ta: 'வளாக வேலைவாய்ப்பு பயிற்சி தளம்', hi: 'प्लेसमेंट तैयारी मंच' },
    tagline: { en: 'Empowering Engineers for Global Tech Careers', ta: 'பொறியியல் மாணவர்களை உலகளாவிய தொழில்வாய்ப்புகளுக்கு தயார்படுத்துதல்', hi: 'सशक्त इंजीनियर' },
};
// Comprehensive English-to-Tamil Word & Phrase Dictionary
const TAMIL_DICTIONARY = {
    // Navigation & Actions
    'Dashboard': 'தகவல் பலகை',
    'Workspace': 'பணியிடம்',
    'Home': 'முகப்பு',
    'Settings': 'அமைப்புகள்',
    'Notifications': 'அறிவிப்புகள்',
    'Profile': 'சுயவிவரம்',
    'Logout': 'வெளியேறு',
    'Log in': 'உள்நுழைய',
    'Sign In': 'உள்நுழைக',
    'Save': 'சேமிக்க',
    'Save Changes': 'மாற்றங்களைச் சேமிக்க',
    'Cancel': 'ரத்து செய்',
    'Close': 'மூடு',
    'Back': 'பின்செல்க',
    'Back to Workspace': 'பணியிடத்திற்குத் திரும்பு',
    'Next': 'அடுத்து',
    'Submit': 'சமர்ப்பி',
    'Search': 'தேடுக',
    'Filter': 'வடிகட்டுக',
    'Download': 'பதிவிறக்கம்',
    'View Details': 'விவரங்களைக் காண்க',
    'Explore': 'ஆராய்க',
    'Practice': 'பயிற்சி செய்',
    'Learn': 'கற்க',
    'Solve': 'தீர்க்கவும்',
    'Mark as Solved': 'தீர்க்கப்பட்டதாகக் குறிக்கவும்',
    'Run Code': 'நிரலை இயக்கு',
    'Check Answer': 'பதிலைச் சரிபார்',
    'Show Hint': 'குறிப்பைக் காட்டு',
    'Explanation': 'விளக்கம்',
    'Clear': 'அழிக்க',
    'Reset': 'மீட்டமை',
    // Roles & Users
    'Student': 'மாணவர்',
    'Junior': 'இளநிலை மாணவர் (2ஆம் ஆண்டு)',
    'Juniors': 'இளநிலை மாணவர்கள்',
    'Pre-Final': 'முந்தைய இறுதி ஆண்டு',
    'Pre-Final Year': 'முந்தைய இறுதி ஆண்டு',
    'Senior': 'மூத்த வழிகாட்டி',
    'Seniors': 'மூத்த வழிகாட்டிகள்',
    'Senior Mentor': 'மூத்த வழிகாட்டி',
    'Mentor': 'வழிகாட்டி',
    'Admin': 'நிர்வாகி',
    'Placement Admin': 'வேலைவாய்ப்பு நிர்வாகி',
    'Faculty': 'பேராசிரியர்',
    'Alumni': 'முன்னாள் மாணவர்',
    // Statuses
    'Placed': 'தேர்வு செய்யப்பட்டவர்',
    'Active': 'செயலில் உள்ளது',
    'Active Now': 'தற்போது செயலில் உள்ளது',
    'Pending': 'நிலுவையில் உள்ளது',
    'Approved': 'அங்கீகரிக்கப்பட்டது',
    'Rejected': 'நிராகரிக்கப்பட்டது',
    'Eligible': 'தகுதியுடையவர்',
    'Not Eligible': 'தகுதியற்றவர்',
    'Completed': 'முடிவடைந்தது',
    'In Progress': 'நடைபெறுகிறது',
    'Upcoming': 'வரவிருப்பது',
    'Shortlisted': 'பரிசீலனைப் பட்டியலில் உள்ளார்',
    'Passed': 'வெற்றி பெற்றது',
    'Failed': 'தோல்வி அடைந்தது',
    // College & Academics
    'National Engineering College': 'தேசிய பொறியியல் கல்லூரி',
    'Kovilpatti': 'கோவில்பட்டி',
    'Computer Science & Engineering': 'கணினி அறிவியல் மற்றும் பொறியியல்',
    'Information Technology': 'தகவல் தொழில்நுட்பம்',
    'Electronics & Communication': 'மின்னணு மற்றும் தகவல் தொடர்பு பொறியியல்',
    'Electrical & Electronics': 'மின் மற்றும் மின்னணுவியல் பொறியியல்',
    'Mechanical Engineering': 'இயந்திரவியல் பொறியியல்',
    'Civil Engineering': 'குடிசார் பொறியியல்',
    'Artificial Intelligence & Data Science': 'செயற்கை நுண்ணறிவு மற்றும் தரவு அறிவியல்',
    'Roll Number': 'பதிவு எண்',
    'Degree': 'பட்டப்படிப்பு',
    'Department': 'துறை',
    'Semester': 'பருவம்',
    'CGPA': 'மதிப்பெண் புள்ளி (CGPA)',
    'Backlogs': 'நிலுவையில் உள்ள தாள்கள்',
    'Year': 'ஆண்டு',
    '2nd Year': '2ஆம் ஆண்டு',
    '3rd Year': '3ஆம் ஆண்டு',
    'Final Year': 'இறுதி ஆண்டு',
    // Placement & Recruiting
    'Placement Preparation Platform': 'வளாக வேலைவாய்ப்பு பயிற்சி தளம்',
    'Placement Drives': 'வேலைவாய்ப்பு முகாம்கள்',
    'Placement Drive': 'வேலைவாய்ப்பு முகாம்',
    'Placement Journey': 'வேலைவாய்ப்புப் பயணம்',
    'Company Explorer': 'நிறுவனத் தேடல்',
    'Company Playbook': 'நிறுவன வழிகாட்டி புத்தகம்',
    'Interview Experiences': 'நேர்காணல் அனுபவங்கள்',
    'Round Resources': 'சுற்று வளங்கள்',
    'Question Bank': 'வினா வங்கி',
    'Practice Studio': 'பயிற்சி அரங்கம்',
    'Daily Challenges': 'தினசரி சவால்கள்',
    'Coding Basics': 'அடிப்படை நிரலாக்கம்',
    'Coding Arena': 'நிரலாக்க களம்',
    'Aptitude Starter': 'திறனறி தொடக்கம்',
    'Aptitude Practice': 'திறனறி பயிற்சி',
    'Mock Interview': 'மாதிரி நேர்காணல்',
    'Mock Interviews': 'மாதிரி நேர்காணல்கள்',
    'Mock GD': 'மாதிரி குழு விவாதம்',
    'Mentorship Hub': 'வழிகாட்டி மையம்',
    'Ask a Senior': 'மூத்தவரிடம் கேளுங்கள்',
    'Peer Circle': 'மாணவர் வட்டம்',
    'Study Planner': 'படிப்புத் திட்டமிடுபவர்',
    'Learning Planner': 'கற்றல் திட்டமிடுபவர்',
    'Performance Analytics': 'செயல்திறன் பகுப்பாய்வு',
    'Student Leaderboard': 'மாணவர் தரவரிசைப் பட்டியல்',
    'Upcoming Sessions': 'வரவிருக்கும் அமர்வுகள்',
    'Feedback Journal': 'கருத்து இதழ்',
    'Online Assessment': 'ஆன்லைன் மதிப்பீட்டுத் தேர்வு',
    'Technical Interview': 'தொழில்நுட்ப நேர்காணல்',
    'HR Interview': 'மனிதவள நேர்காணல்',
    'Group Discussion': 'குழு விவாதம்',
    'Package': 'வருடாந்திர ஊதியம்',
    'Salary': 'ஊதியம்',
    'Eligibility': 'தகுதி வரம்பு',
    'Deadline': 'கடைசி தேதி',
    'Register': 'பதிவு செய்',
    'Apply Now': 'இப்போதே விண்ணப்பி',
    // Tech & Coding
    'Variables': 'மாறிகள் (Variables)',
    'Conditions': 'நிபந்தனைகள் (Conditions)',
    'Loops': 'சுழற்சிகள் (Loops)',
    'Functions': 'செயல்பாடுகள் (Functions)',
    'Arrays': 'அணிகள் (Arrays)',
    'Strings': 'சரங்கள் (Strings)',
    'Data Structures': 'தரவு கட்டமைப்புகள் (DSA)',
    'Algorithms': 'வழிமுறைகள் (Algorithms)',
    'Database': 'தரவுத்தளம் (Database)',
    'Python': 'பைதான் (Python)',
    'Java': 'ஜாவா (Java)',
    'C++': 'சி++ (C++)',
    'JavaScript': 'ஜாவாஸ்கிரிப்ட் (JavaScript)',
    'HTML & CSS': 'வலைப்பக்க வடிவமைப்பு (HTML & CSS)',
    'React': 'ரியாக்ட் (React)',
    'Node.js': 'நோட் ஜேஎஸ் (Node.js)',
    'SQL': 'எஸ்கியூஎல் (SQL)',
    'Git & GitHub': 'கிட் மற்றும் கிட்ஹப்',
    // Admin Tools
    'Student Cohort Monitor': 'மாணவர் குழு கண்காணிப்பாளர்',
    'Send Broadcast Email': 'அறிவிப்பு மின்னஞ்சல் அனுப்பு',
    'Schedule Live Session': 'நேரலை அமர்வை திட்டமிடு',
    'Post Placement Drive': 'வேலைவாய்ப்பு முகாமைப் பதிவிடு',
    'Export Analytics': 'தரவுகளை ஏற்றுமதி செய்',
    'Subject': 'தலைப்பு',
    'Message': 'செய்தி',
    'Send to All': 'அனைவருக்கும் அனுப்பு',
    'Outbox': 'அனுப்பப்பட்டவை',
    'Meeting Link': 'சந்திப்பு இணைப்பு',
    'Date & Time': 'தேதி & நேரம்',
    'Speaker': 'வழங்குநர் / பேச்சாளர்',
    'Capacity': 'அதிகபட்ச பங்கேற்பாளர்கள்',
    // Theme & Mode
    'Light Mode': 'பகல் முறைமை (Light)',
    'Dark Mode': 'இரவு முறைமை (Dark)',
    'Display Mode': 'காட்சி முறைமை',
    'Color Theme': 'வண்ண தீம்',
    'Standard Theme Colors': 'நிலையான வண்ண தீம்கள்',
    'Custom Extended Palette': 'விருப்ப விரிவாக்கப்பட்ட வண்ணங்கள்',
    'Requested Hex Codes': 'கோரப்பட்ட ஹெக்ஸ் வண்ணக் குறியீடுகள்',
    'Appearance': 'தோற்றம்',
    'Language': 'மொழி',
    'Tamil': 'தமிழ்',
    'English': 'ஆங்கிலம்',
    'Royal Blue': 'ராஜ நீலம்',
    'Emerald Green': 'மரகத பச்சை',
    'Amber Orange': 'அம்பர் ஆரஞ்சு',
    'Crimson Red': 'கருஞ்சிவப்பு',
    'Slate Gray': 'சாம்பல் சாம்பல்',
    'Royal Purple': 'அரசு ஊதா',
    'Deep Maroon': 'அடர்ந்த மெரூன்',
    'Hot Pink': 'இளஞ்சிவப்பு',
    'Gold Mustard': 'தங்கக் கடுகு',
    'Dusty Peach': 'தூசி பீச்',
    'Deep Terracotta': 'அடர்ந்த சுடுமண்',
    'Slate Teal': 'பலகை டீல்',
    'Coral Rose': 'பவள ரோஜா',
    'Fiery Crimson': 'எரியும் சிவப்பு',
    'Vibrant Cyan': 'துடிப்பான நீலப்பச்சை',
    'Sage Mint': 'முனிவர் புதினா',
    'Ocean Teal': 'பெருங்கடல் டீல்',
    'Pastel Blossom': 'மென்மையான மலர் இளஞ்சிவப்பு',
    // Junior Dashboard & Practice Arena
    'Junior Foundation Hub • 2nd Year (Batch 2028)': 'இளநிலை அடித்தள மையம் • 2ஆம் ஆண்டு (தொகுதி 2028)',
    'Junior Placement Roadmap & Practice Studio': 'இளநிலை வேலைவாய்ப்பு வழிகாட்டி & பயிற்சி அரங்கம்',
    'Learn coding fundamentals, speed aptitude, interactive Git, SQL, and connect with placed seniors.': 'அடிப்படை நிரலாக்கம், திறனறி வேகம், கிட், எஸ்கியூஎல் கற்றுக்கொண்டு மூத்தவர்களுடன் இணையுங்கள்.',
    'Coding Solved': 'தீர்க்கப்பட்ட நிரல்கள்',
    'Aptitude Correct': 'சரியான திறனறி விடைகள்',
    'Tasks Completed': 'முடிக்கப்பட்ட பணிகள்',
    'Beginner Coding Problems': 'தொடக்க நிலை நிரலாக்க வினாக்கள்',
    'JavaScript / Python Interactive Editor': 'ஜாவாஸ்கிரிப்ட் / பைதான் ஊடாடும் தொகுப்பான்',
    'Reset Template': 'வார்ப்புருவை மீட்டமை',
    'Run Code & Verify Test Cases': 'நிரலை இயக்கி சோதனை வழக்குகளைச் சரிபார்',
    'Terminal Execution Console': 'முனைய இயக்கக் கட்டுப்பாட்டுப் பலகை',
    'PASSED ✓': 'வெற்றி பெற்றது ✓',
    'FAILED ✕': 'தோல்வி அடைந்தது ✕',
    '💡 Hint:': '💡 குறிப்பு:',
    'Variables & Logic: Check Even or Odd': 'மாறிகள் & தர்க்கம்: இரட்டை அல்லது ஒற்றை எண் சரிபார்ப்பு',
    'Loops: FizzBuzz Classic': 'மடக்குகள்: ஃபிஸ்பஸ் கிளாசிக்',
    'Functions: Prime Number Checker': 'செயல்பாடுகள்: பகா எண் சரிபார்ப்பு',
    'Arrays: Reverse Array In-Place': 'வரிசைகள்: தலைகீழ் வரிசை மாற்றம்',
    'Strings: Palindrome Validator': 'சரங்கள்: சமச்சீர் சொல் சரிபார்ப்பு',
    'Math: Sum of Digits': 'கணிதம்: இலக்கங்களின் கூடுதல்',
    'Welcome to NEC Junior Git Terminal Simulator!': 'என்.இ.சி இளநிலை கிட் முனையப் போலிக்கு நல்வரவு!',
    'Try typing: git init, git add ., or git commit -m "First commit"': 'தட்டச்சு செய்க: git init, git add ., அல்லது git commit -m "முதல் பதிவு"',
    'Interactive SQL Query Studio': 'ஊடாடும் எஸ்கியூஎல் வினவல் கூடம்',
    'Execute SQL Query': 'எஸ்கியூஎல் வினவலை இயக்கு',
    'Count Vowels & Consonants': 'உயிரெழுத்துக்கள் மற்றும் மெய்யெழுத்துக்களை எண்ணுக',
    'Train Crossing Platform Problem': 'ரயில் நடைமேடை கடக்கும் கணக்கு',
    'Record 60-Second Elevator Pitch': '60 வினாடி சுய அறிமுகத்தை பதிவு செய்',
    'My Progress': 'எனது முன்னேற்றம்',
    'Post Question': 'கேள்வியைப் பதிவிடு',
    'Recent Answers from Placed Seniors': 'வேலைபெற்ற மூத்தவர்களின் சமீபத்திய பதில்கள்',
    // Admin Center & Controls
    'Training & Placement Cell Admin Command Center': 'பயிற்சி & வேலைவாய்ப்புப் பிரிவு நிர்வாக கட்டுப்பாட்டு மையம்',
    'Admin Placement Control & Operations Center': 'நிர்வாக வேலைவாய்ப்பு கட்டுப்பாடு & செயல்பாட்டு மையம்',
    'Send Email Broadcast': 'அறிவிப்பு மின்னஞ்சல் அனுப்பு',
    'Export Cohort CSV': 'மாணவர் பட்டியல் கோப்பைப் பதிவிறக்கு',
    'Compose Broadcast Email to Students': 'மாணவர்களுக்கான பொது மின்னஞ்சலை எழுதுங்கள்',
    'Target Student Cohort': 'இலக்கு மாணவர் குழு',
    'Subject Header': 'மின்னஞ்சல் தலைப்பு',
    'Email Body Message': 'செய்தி விவரம்',
    'Send Broadcast Email to Cohort': 'அனைத்து மாணவர்களுக்கும் மின்னஞ்சல் அனுப்புக',
    'Broadcast Outbox History': 'அனுப்பப்பட்ட மின்னஞ்சல்கள் வரலாறு',
    'Book Live Sessions': 'நேரலை அமர்வுகளை முன்பதிவு செய்',
    'Manage Drives': 'வேலைவாய்ப்பு முகாம்களை நிர்வகி',
    'Post New Campus Placement Drive': 'புதிய வளாக வேலைவாய்ப்பு முகாமைப் பதிவிடு',
    'Company Name': 'நிறுவனத்தின் பெயர்',
    'Job Role': 'பணிப் பொறுப்பு',
    'CTC Package (LPA)': 'வருடாந்திர ஊதியம் (LPA)',
    'Eligibility Criteria': 'தகுதி வரம்புகள்',
    'Post Drive for Campus': 'முகாமை மாணவர்களுக்காக வெளியிடு',
    'Active On-Campus Drives': 'செயலில் உள்ள வளாக முகாம்கள்',
    'Search students by name, roll number, or department...': 'பெயர், பதிவு எண் அல்லது துறை மூலம் மாணவர்களைத் தேடுங்கள்...',
    'Student Name': 'மாணவர் பெயர்',
    'Roll / ID': 'பதிவு எண்',
    'Admin Actions': 'நிர்வாக நடவடிக்கைகள்',
    'Manage': 'நிர்வகி',
    'Approve': 'அங்கீகரி',
    'Student Placement Profile & Controls': 'மாணவர் சுயவிவரம் & கட்டுப்பாடுகள்',
    'Change Placement Eligibility Status:': 'வேலைவாய்ப்பு தகுதி நிலையை மாற்றுக:',
    'Day-1 Approved': 'முதல் நாள் அங்கீகரிக்கப்பட்டது',
    'Needs Remedial': 'கூடுதல் பயிற்சி தேவை',
    'Mark Placed': 'வேலைபெற்றவராகக் குறிக்கவும்',
    'Under Review': 'பரிசீலனையில் உள்ளது',
    'Send Direct Message': 'நேரடி தனிப்பட்ட செய்தி அனுப்பு',
    'Direct Message': 'நேரடி செய்தி',
    'Student Activity Monitor': 'மாணவர் பயிற்சி கண்காணிப்பாளர்',
    'Monitor live student practice sessions, test scores, and mock interviews': 'நேரலை மாணவர் பயிற்சி அமர்வுகள், தேர்வு மதிப்பெண்களைக் கண்காணிக்கவும்',
    // Home Page & Global Branding
    'Placement Preparation & Career Acceleration Ecosystem': 'வேலைவாய்ப்பு பயிற்சி & தொழில் முன்னேற்ற களம்',
    'National Engineering College · Click the campus image below to access your student workspace.': 'தேசிய பொறியியல் கல்லூரி · உங்கள் மாணவர் பணியிடத்திற்குள் நுழைய வளாகப் புகைப்படத்தைக் கிளிக் செய்க.',
    'Autonomous · Estd. 1984': 'தன்னாட்சி பெற்ற கல்லூரி · நிறுவப்பட்டது 1984',
    'Training & Placement Cell · Kovilpatti': 'பயிற்சி & வேலைவாய்ப்பு பிரிவு · கோவில்பட்டி',
    'Affiliated to Anna University, Chennai · Accredited by NAAC \'A+\' Grade & NBA': 'அண்ணா பல்கலைக்கழக இணைப்பு, சென்னை · NAAC \'A+\' தரம் & NBA அங்கீகாரம் பெற்றது',
    'DST - FIST Sponsored Institution': 'DST - FIST நிதி உதவி பெற்ற கல்வி நிறுவனம்',
    'Estd. 1984 · K.R. Nagar, Kovilpatti': 'நிறுவப்பட்டது 1984 · கே.ஆர். நகர், கோவில்பட்டி',
    'Click anywhere to enter workspace': 'பணியிடத்திற்குள் செல்ல எங்கு வேண்டுமானாலும் கிளிக் செய்க',
    'Active Session': 'செயலில் உள்ள அமர்வு',
    'Full View': 'முழுத் தோற்றம்',
    'Preferences & Controls': 'விருப்பத்தேர்வுகள் & கட்டுப்பாடுகள்',
    'System Preferences': 'கணினி அமைப்புகள்',
    'Standard crisp high-contrast daylight': 'தெளிவான பகல் முறைமை',
    'Gentle midnight dark theme': 'கண்களுக்கு இதமான இரவு முறைமை',
};
export const ThemeProvider = ({ children }) => {
    const { user } = useAuth();
    const [settings, setSettings] = useState(() => {
        const savedLang = typeof window !== 'undefined' ? localStorage.getItem('necpp_global_language') : null;
        const savedMode = typeof window !== 'undefined' ? localStorage.getItem('necpp_global_mode') : null;
        const savedTheme = typeof window !== 'undefined' ? localStorage.getItem('necpp_global_theme') : null;
        const savedColor = typeof window !== 'undefined' ? localStorage.getItem('necpp_global_color') : null;
        let baseSettings = DEFAULT_USER_SETTINGS;
        if (user) {
            baseSettings = storageService.getUserSettings(user.id);
        }
        return {
            ...baseSettings,
            mode: savedMode || baseSettings.mode || 'light',
            theme: savedTheme || baseSettings.theme || 'blue',
            themeColor: savedColor || baseSettings.themeColor || '#1e40af',
            language: savedLang || baseSettings.language || 'en',
        };
    });
    // Calculate RGB/Hex Variations for Active Theme
    const getThemeHex = (themeName, themeColor) => {
        if (themeColor && themeColor.startsWith('#'))
            return themeColor;
        const preset = PRESET_THEME_COLORS.find((p) => p.id === themeName);
        if (preset)
            return preset.hex;
        const special = SPECIAL_HEX_PALETTE.find((s) => s.id === themeName || s.hex === themeName);
        if (special)
            return special.hex;
        return '#1e40af';
    };
    // Apply real DOM theme, dark mode, and dynamic CSS custom properties
    useEffect(() => {
        const root = document.documentElement;
        const mode = settings.mode || 'light';
        const activeColor = getThemeHex(settings.theme, settings.themeColor);
        // Apply data-mode and dark class for light/dark
        root.setAttribute('data-mode', mode);
        root.setAttribute('data-theme', settings.theme || 'blue');
        if (mode === 'dark') {
            root.classList.add('dark');
            document.body.classList.add('dark');
        }
        else {
            root.classList.remove('dark');
            document.body.classList.remove('dark');
        }
        // Dynamic CSS Custom Properties for theme color across all components
        root.style.setProperty('--theme-color', activeColor);
        root.style.setProperty('--primary', activeColor);
        root.style.setProperty('--primary-hover', activeColor);
        root.style.setProperty('--theme-hover', activeColor);
        root.style.setProperty('--theme-light', activeColor + '1f');
        // High contrast
        if (settings.accessibility?.highContrast) {
            root.classList.add('high-contrast');
        }
        else {
            root.classList.remove('high-contrast');
        }
        // Font size
        root.classList.remove('font-size-small', 'font-size-medium', 'font-size-large');
        if (settings.fontSize === 'small') {
            root.classList.add('font-size-small');
            root.style.fontSize = '14px';
        }
        else if (settings.fontSize === 'large') {
            root.classList.add('font-size-large');
            root.style.fontSize = '18px';
        }
        else {
            root.classList.add('font-size-medium');
            root.style.fontSize = '16px';
        }
    }, [settings]);
    // Pervasive Full-Website Tamil Translation DOM Engine
    // Guarantees that when Tamil is chosen, not even a single English word remains visible
    useEffect(() => {
        if (settings.language !== 'ta' || typeof document === 'undefined')
            return;
        const translateNode = (node) => {
            if (node.nodeType === Node.TEXT_NODE && node.nodeValue) {
                const raw = node.nodeValue.trim();
                if (raw && /[a-zA-Z]/.test(raw)) {
                    // 1. Direct dictionary match
                    if (TAMIL_DICTIONARY[raw]) {
                        node.nodeValue = node.nodeValue.replace(raw, TAMIL_DICTIONARY[raw]);
                        return;
                    }
                    // 2. Partial dictionary phrase substitutions
                    let replaced = node.nodeValue;
                    let changed = false;
                    for (const [eng, tam] of Object.entries(TAMIL_DICTIONARY)) {
                        if (replaced.includes(eng)) {
                            replaced = replaced.split(eng).join(tam);
                            changed = true;
                        }
                    }
                    if (changed) {
                        node.nodeValue = replaced;
                    }
                }
            }
            else if (node.nodeType === Node.ELEMENT_NODE) {
                const el = node;
                if (['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE'].includes(el.tagName))
                    return;
                node.childNodes.forEach(translateNode);
            }
        };
        // Initial translation pass
        translateNode(document.body);
        // Dynamic mutation observer for async content
        const observer = new MutationObserver((mutations) => {
            for (const m of mutations) {
                m.addedNodes.forEach(translateNode);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
        return () => observer.disconnect();
    }, [settings.language]);
    const updateSettings = (newSettings) => {
        setSettings((prev) => {
            const updated = {
                ...prev,
                ...newSettings,
                notifications: {
                    ...prev.notifications,
                    ...(newSettings.notifications || {}),
                },
                accessibility: {
                    ...prev.accessibility,
                    ...(newSettings.accessibility || {}),
                },
                privacy: {
                    ...prev.privacy,
                    ...(newSettings.privacy || {}),
                },
            };
            if (typeof window !== 'undefined') {
                if (updated.language)
                    localStorage.setItem('necpp_global_language', updated.language);
                if (updated.mode)
                    localStorage.setItem('necpp_global_mode', updated.mode);
                if (updated.theme)
                    localStorage.setItem('necpp_global_theme', updated.theme);
                if (updated.themeColor)
                    localStorage.setItem('necpp_global_color', updated.themeColor);
            }
            if (user) {
                storageService.saveUserSettings(user.id, updated);
            }
            return updated;
        });
    };
    const toggleMode = () => {
        updateSettings({ mode: settings.mode === 'dark' ? 'light' : 'dark' });
    };
    const setThemeColor = (color) => {
        updateSettings({ themeColor: color, theme: color });
    };
    const toggleLanguage = () => {
        updateSettings({ language: settings.language === 'ta' ? 'en' : 'ta' });
    };
    /**
     * Pervasive Translation Function
     * If Tamil is active, guarantees pure Tamil output by checking translations map,
     * dictionary lookup, and phrase substitution so not even a single English word remains.
     */
    const t = (keyOrText, fallback) => {
        if (!keyOrText)
            return '';
        const lang = settings.language || 'en';
        // 1. Direct TRANSLATIONS lookup
        if (TRANSLATIONS[keyOrText] && TRANSLATIONS[keyOrText][lang]) {
            return TRANSLATIONS[keyOrText][lang];
        }
        // 2. If English mode, return key's english translation or key itself
        if (lang === 'en') {
            if (TRANSLATIONS[keyOrText] && TRANSLATIONS[keyOrText]['en']) {
                return TRANSLATIONS[keyOrText]['en'];
            }
            return fallback || keyOrText;
        }
        // 3. If Tamil mode: check TAMIL_DICTIONARY exact match
        const trimmed = keyOrText.trim();
        if (TAMIL_DICTIONARY[trimmed]) {
            return TAMIL_DICTIONARY[trimmed];
        }
        // 4. Case-insensitive dictionary check
        const lower = trimmed.toLowerCase();
        for (const [eng, tam] of Object.entries(TAMIL_DICTIONARY)) {
            if (eng.toLowerCase() === lower) {
                return tam;
            }
        }
        // 5. Token/phrase substitution if text contains multiple known English words
        let translated = trimmed;
        let foundMatch = false;
        for (const [eng, tam] of Object.entries(TAMIL_DICTIONARY)) {
            if (translated.includes(eng)) {
                translated = translated.split(eng).join(tam);
                foundMatch = true;
            }
        }
        if (foundMatch) {
            return translated;
        }
        return fallback || keyOrText;
    };
    return (<ThemeContext.Provider value={{
            settings,
            updateSettings,
            mode: settings.mode || 'light',
            toggleMode,
            themeColor: settings.themeColor || '#1e40af',
            setThemeColor,
            language: settings.language || 'en',
            toggleLanguage,
            isTamil: settings.language === 'ta',
            t,
        }}>
      {children}
    </ThemeContext.Provider>);
};
export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
};
